/**
 * AutoNegotiator AI — Decluttered Multi-Dealer Command Center & Direct ADK Agent Client (ZIP 07724)
 * Features:
 * - Select up to 3 competing vehicles across dealers & trims (`SX X-Line`, `SX Prestige`, `SX Prestige X-Line`)
 * - Side-by-Side-by-Side 3-Column Cross-Trim & Color-Parity OTD Comparison Deck
 * - 1-Click Autonomous Multi-Dealer Negotiation (`FULL_AUTOPILOT` / `SEMI_AUTO` / `COPILOT_STEALTH`)
 * - Zero-Buzzword Natural Buyer Default + Reactive Accounting Mirror Exception
 * - Two-Checkbox Affirmative Trade-In & NJ 6.625% Sales Tax Credit Workflow + Shell-Game Detector
 * - Non-Deterministic ADK Chat Console (`Creative Strategist` temp=0.65 vs. `Strict Deal Auditor` temp=0.1)
 */

(function () {
  'use strict';

  let currentDashboard = null;
  let selectedDealerId = null;
  let comparedDealerIds = []; // Up to 3 dealer IDs for side-by-side-by-side comparison & auto-negotiation
  let activeAgentMode = 'strategist'; // 'strategist' (temp=0.65) or 'auditor' (temp=0.1)
  let firestoreDb = null;
  let firestoreConnected = false;

  const elFirestoreStatus = document.getElementById('firestore-status');
  const elKpiBestPrice = document.getElementById('kpi-best-price');
  const elKpiBestDealer = document.getElementById('kpi-best-dealer');
  const elKpiBestImpliedMonthly = document.getElementById('kpi-best-implied-monthly');
  const elKpiBestImpliedSub = document.getElementById('kpi-best-implied-sub');
  const elKpiQueueCounts = document.getElementById('kpi-queue-counts');
  const elKpiLeverageScript = document.getElementById('kpi-leverage-script');
  const elComparisonBody = document.getElementById('dealer-comparison-body');
  const elCopilotQueueList = document.getElementById('copilot-queue-list');
  const elInboxTimelineList = document.getElementById('inbox-timeline-list');

  function formatMoney(val, decimals = 0) {
    const num = Number(val || 0);
    return '$' + num.toLocaleString('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function channelBadgeHtml(channel) {
    const ch = (channel || 'SMS_PERSONAL').toUpperCase();
    if (ch === 'SMS_PERSONAL') {
      return '<span class="px-2 py-0.5 text-[10px] font-semibold rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">📱 Personal Mobile SMS</span>';
    }
    if (ch === 'SMS_TWILIO') {
      return '<span class="px-2 py-0.5 text-[10px] font-semibold rounded-md bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">💬 Twilio SMS</span>';
    }
    return '<span class="px-2 py-0.5 text-[10px] font-semibold rounded-md bg-purple-500/15 text-purple-300 border border-purple-500/30">✉️ Email</span>';
  }

  function inventoryBadgeHtml(status, eta) {
    const st = (status || 'IN_TRANSIT').toUpperCase();
    if (st === 'IN_TRANSIT') {
      return `<div class="mt-1 text-[10px] text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 rounded px-2 py-0.5">🚢 IN_TRANSIT (Dec Lock • $0 Add-Ons)<br><span class="font-mono text-[10px] text-slate-400">ETA: ${eta || 'Late Dec 2026'}</span></div>`;
    }
    return `<div class="mt-1 text-[10px] text-amber-300 bg-amber-500/10 border border-amber-500/20 rounded px-2 py-0.5">🅿️ ON-LOT UNIT<br><span class="font-mono text-[10px] text-slate-400">${eta || 'On Lot Now'}</span></div>`;
  }

  // View Tab Switching (Screen 1: Herbie & HUD vs Screen 2: Inventory Browser vs Utility: OTD Calculator)
  window.switchViewTab = function (tabName) {
    const viewDash = document.getElementById('view-dashboard');
    const viewInv = document.getElementById('view-inventory');
    const viewCalc = document.getElementById('view-calculator');
    const btnDash = document.getElementById('tab-btn-dashboard');
    const btnInv = document.getElementById('tab-btn-inventory');
    const btnCalc = document.getElementById('tab-btn-calculator');

    const allViews = [viewDash, viewInv, viewCalc];
    allViews.forEach((v) => v?.classList.add('hidden'));

    const allBtns = [btnDash, btnInv, btnCalc];
    allBtns.forEach((b) => {
      b?.classList.remove('bg-emerald-600', 'text-white');
      b?.classList.add('bg-slate-900', 'text-slate-300');
    });

    if (tabName === 'inventory') {
      viewInv?.classList.remove('hidden');
      btnInv?.classList.remove('bg-slate-900', 'text-slate-300');
      btnInv?.classList.add('bg-emerald-600', 'text-white');
      if (currentDashboard) renderDashboard(currentDashboard);
    } else if (tabName === 'calculator') {
      viewCalc?.classList.remove('hidden');
      btnCalc?.classList.remove('bg-slate-900', 'text-slate-300');
      btnCalc?.classList.add('bg-emerald-600', 'text-white');
      runReverseOtdCalculator();
    } else {
      viewDash?.classList.remove('hidden');
      btnDash?.classList.remove('bg-slate-900', 'text-slate-300');
      btnDash?.classList.add('bg-emerald-600', 'text-white');
    }
  };

  window.selectAndDiscussWithHerbie = function (dealerId) {
    window.selectCarByDealerId(dealerId);
    window.switchViewTab('dashboard');
    const chatEl = document.getElementById('mobile-sec-chat');
    if (chatEl) {
      chatEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  function initFirestoreSync() {
    try {
      if (typeof firebase !== 'undefined' && firebase.app) {
        const app = firebase.app();
        firestoreDb = app.firestore();
        const auth = app.auth();
        auth.signInAnonymously().catch(() => {});

        firestoreDb.collection('dealer_leads').onSnapshot(
          (snap) => {
            if (!snap.empty) {
              firestoreConnected = true;
              updateSyncBadge();
            }
          },
          () => {
            firestoreConnected = false;
            updateSyncBadge();
          }
        );
      }
    } catch (e) {
      firestoreConnected = false;
    }
  }

  function updateSyncBadge() {
    if (!elFirestoreStatus) return;
    elFirestoreStatus.textContent = firestoreConnected
      ? '🟢 Firestore + Herbie Live'
      : '🟢 Herbie ADK Live';
  }

  async function mirrorToClientFirestore(dash) {
    if (!firestoreDb || !dash) return;
    try {
      if (dash.campaign && dash.campaign.id) {
        await firestoreDb
          .collection('negotiation_campaigns')
          .doc(dash.campaign.id)
          .set(dash.campaign, { merge: true });
      }
      if (Array.isArray(dash.dealers_ranked)) {
        for (const d of dash.dealers_ranked) {
          if (d.id) {
            await firestoreDb.collection('dealer_leads').doc(d.id).set(d, { merge: true });
          }
        }
      }
      firestoreConnected = true;
      updateSyncBadge();
    } catch (err) {
      // Non-fatal
    }
  }

  let inventoryDealerFilter = 'ALL';
  let inventoryTrimFilter = 'ALL';
  let inventoryInteriorFilter = 'ALL';
  let inventoryStatusFilter = 'ALL';
  let inventorySortBy = 'deal_score_asc';

  function normalizeDealerGroupName(rawName) {
    const low = String(rawName || '').toLowerCase();
    if (low.includes('raceway') || low.includes('freehold')) {
      return 'Raceway Kia of Freehold';
    }
    if (low.includes('sansone') || low.includes('66 automall') || low.includes('neptune') || low.includes('keyport')) {
      return "Sansone Jr's 66 Automall Kia";
    }
    if (low.includes('matt blatt') || low.includes('toms river')) {
      return 'Matt Blatt Kia of Toms River';
    }
    if (low.includes('difeo') || low.includes('lakewood')) {
      return 'DiFeo Kia of Lakewood';
    }
    if (low.includes('manahawkin')) {
      return 'Manahawkin Kia';
    }
    return String(rawName || '').split('(')[0].trim() || 'Monmouth County Kia';
  }

  function inferTrimPriorityRank(trimStr) {
    const low = String(trimStr || '').toLowerCase();
    if (low.includes('prestige') && low.includes('x-line')) return 3;
    if (low.includes('prestige')) return 2;
    return 1;
  }

  function shortTrimLabel(trimStr) {
    return String(trimStr || '2027 Kia Telluride Hybrid SX X-Line')
      .replace(/^2027\s+Kia\s+Telluride\s+/i, '')
      .trim();
  }

  function isVehiclePriorityNonBlack(v) {
    if (typeof v.is_priority_non_black === 'boolean') return v.is_priority_non_black;
    if (typeof v.is_non_black_interior === 'boolean') return v.is_non_black_interior;
    const low = String(v.interior_color || '').toLowerCase();
    return (
      low.includes('saddle') ||
      low.includes('brown') ||
      low.includes('terracotta') ||
      low.includes('navy') ||
      low.includes('tuscan') ||
      low.includes('umber') ||
      low.includes('millstone')
    );
  }

  function computeVehicleTrueDealScore(v) {
    if (Number.isFinite(Number(v.true_deal_score))) {
      return Number(v.true_deal_score);
    }
    const msrp = Number(v.msrp || 56035);
    const selling = Number(v.selling_price || 54535);
    const docFee = Number(v.doc_fee || 689);
    const addons = Number(v.dealer_addons_total || 0);
    return Number((selling - msrp + docFee + addons).toFixed(2));
  }

  function getAllInventoryVehicles(data) {
    const d = data || currentDashboard || window.__INITIAL_DASHBOARD_SNAPSHOT__ || {};
    const inv = Array.isArray(d.dealer_inventory) ? d.dealer_inventory : [];
    const ranked = Array.isArray(d.dealers_ranked) ? d.dealers_ranked : [];
    if (inv.length === 0) {
      return ranked.map((item) => ({
        ...item,
        dealer_name: normalizeDealerGroupName(item.base_dealer_name || item.dealer_name),
        base_dealer_name: normalizeDealerGroupName(item.base_dealer_name || item.dealer_name),
      }));
    }
    const byId = new Map();
    const byVin = new Map();
    for (const r of ranked) {
      const normName = normalizeDealerGroupName(r.base_dealer_name || r.dealer_name);
      const enriched = {
        ...r,
        dealer_name: normName,
        base_dealer_name: normName,
      };
      if (enriched.id) byId.set(enriched.id, enriched);
      if (enriched.vin) byVin.set(enriched.vin, enriched);
    }
    const merged = [];
    const seenIds = new Set();
    const seenVins = new Set();
    for (const item of inv) {
      const liveLead =
        (item.id && byId.get(item.id)) ||
        (item.vin && byVin.get(item.vin)) ||
        null;
      const combined = liveLead ? { ...item, ...liveLead } : { ...item };
      const normName = normalizeDealerGroupName(combined.base_dealer_name || combined.dealer_name);
      combined.dealer_name = normName;
      combined.base_dealer_name = normName;
      merged.push(combined);
      if (combined.id) seenIds.add(combined.id);
      if (combined.vin) seenVins.add(combined.vin);
    }
    for (const r of ranked) {
      if ((r.id && seenIds.has(r.id)) || (r.vin && seenVins.has(r.vin))) continue;
      const normName = normalizeDealerGroupName(r.base_dealer_name || r.dealer_name);
      merged.push({
        ...r,
        dealer_name: normName,
        base_dealer_name: normName,
      });
    }
    return merged;
  }

  function matchesTrimFilter(vehicleTrim, filterTrim) {
    if (!filterTrim || filterTrim === 'ALL') return true;
    const vt = String(vehicleTrim || '').toLowerCase().trim();
    const ft = String(filterTrim || '').toLowerCase().trim();
    if (vt === ft) return true;
    const ftHasPrestige = ft.includes('prestige');
    const ftHasXline = ft.includes('x-line');
    const vtHasPrestige = vt.includes('prestige');
    const vtHasXline = vt.includes('x-line');
    if (ftHasPrestige && ftHasXline) {
      return vtHasPrestige && vtHasXline;
    }
    if (ftHasPrestige && !ftHasXline) {
      return vtHasPrestige && !vtHasXline;
    }
    if (!ftHasPrestige && ftHasXline) {
      return !vtHasPrestige && vtHasXline;
    }
    return vt.includes(ft);
  }

  function matchesDealerFilter(vehicle, filterDealer) {
    if (!filterDealer || filterDealer === 'ALL') return true;
    const fd = String(filterDealer || '').toLowerCase().trim();
    const dName = normalizeDealerGroupName(vehicle.base_dealer_name || vehicle.dealer_name).toLowerCase();
    const rawName = String(vehicle.dealer_name || '').toLowerCase();
    const dId = String(vehicle.id || '').toLowerCase();
    return dName === fd || dName.includes(fd) || rawName.includes(fd) || dId.includes(fd);
  }

  function matchesInteriorFilter(vehicle, filterInterior) {
    if (!filterInterior || filterInterior === 'ALL') return true;
    const f = String(filterInterior).toUpperCase();
    const nonBlack = isVehiclePriorityNonBlack(vehicle);
    if (f === 'NON_BLACK' || f === 'PRIORITY') return nonBlack;
    if (f === 'BLACK' || f === 'ALL_BLACK') return !nonBlack;
    return true;
  }

  function matchesStatusFilter(vehicle, filterStatus) {
    if (!filterStatus || filterStatus === 'ALL') return true;
    const st = String(vehicle.inventory_status || vehicle.stock_status || 'IN_TRANSIT').toUpperCase();
    return st === String(filterStatus).toUpperCase();
  }

  function getFilteredAndSortedInventory(data) {
    const allVehicles = getAllInventoryVehicles(data);
    const filtered = allVehicles.filter(
      (v) =>
        matchesDealerFilter(v, inventoryDealerFilter) &&
        matchesTrimFilter(v.trim_level, inventoryTrimFilter) &&
        matchesInteriorFilter(v, inventoryInteriorFilter) &&
        matchesStatusFilter(v, inventoryStatusFilter)
    );

    const sortKey = (inventorySortBy || 'deal_score_asc').toLowerCase();
    const sorted = [...filtered];
    sorted.sort((a, b) => {
      const scoreA = computeVehicleTrueDealScore(a);
      const scoreB = computeVehicleTrueDealScore(b);
      const nonBlackRankA = isVehiclePriorityNonBlack(a) ? 0 : 1;
      const nonBlackRankB = isVehiclePriorityNonBlack(b) ? 0 : 1;
      const otdA = Number(a.otd_total || 999999);
      const otdB = Number(b.otd_total || 999999);
      const trimRankA = Number(a.trim_priority_rank || inferTrimPriorityRank(a.trim_level));
      const trimRankB = Number(b.trim_priority_rank || inferTrimPriorityRank(b.trim_level));
      const dealerA = normalizeDealerGroupName(a.base_dealer_name || a.dealer_name);
      const dealerB = normalizeDealerGroupName(b.base_dealer_name || b.dealer_name);
      const discA = Number(a.discount_pct || a.discount_off_msrp_pct || 0);
      const discB = Number(b.discount_pct || b.discount_off_msrp_pct || 0);
      const leaseA = Number(a.lease_3k_down_monthly || a.implied_lease_36mo || a.lease_monthly_36m || 9999);
      const leaseB = Number(b.lease_3k_down_monthly || b.implied_lease_36mo || b.lease_monthly_36m || 9999);
      const msrpA = Number(a.msrp || 0);
      const msrpB = Number(b.msrp || 0);
      const statusRankA = String(a.inventory_status || a.stock_status || '').toUpperCase() === 'IN_TRANSIT' ? 0 : 1;
      const statusRankB = String(b.inventory_status || b.stock_status || '').toUpperCase() === 'IN_TRANSIT' ? 0 : 1;

      if (sortKey === 'deal_score_asc') {
        return scoreA - scoreB || nonBlackRankA - nonBlackRankB || otdA - otdB;
      }
      if (sortKey === 'priority_non_black') {
        return nonBlackRankA - nonBlackRankB || scoreA - scoreB || otdA - otdB;
      }
      if (sortKey === 'otd_desc') {
        return otdB - otdA || dealerA.localeCompare(dealerB);
      }
      if (sortKey === 'trim_asc') {
        return trimRankA - trimRankB || scoreA - scoreB || otdA - otdB;
      }
      if (sortKey === 'trim_desc') {
        return trimRankB - trimRankA || scoreA - scoreB || otdA - otdB;
      }
      if (sortKey === 'dealer_asc') {
        return dealerA.localeCompare(dealerB) || trimRankA - trimRankB || scoreA - scoreB;
      }
      if (sortKey === 'dealer_desc') {
        return dealerB.localeCompare(dealerA) || trimRankA - trimRankB || scoreA - scoreB;
      }
      if (sortKey === 'discount_desc') {
        return discB - discA || scoreA - scoreB;
      }
      if (sortKey === 'lease_asc') {
        return leaseA - leaseB || scoreA - scoreB;
      }
      if (sortKey === 'msrp_asc') {
        return msrpA - msrpB || scoreA - scoreB;
      }
      if (sortKey === 'status') {
        return statusRankA - statusRankB || nonBlackRankA - nonBlackRankB || scoreA - scoreB;
      }
      return otdA - otdB || trimRankA - trimRankB;
    });

    return sorted.map((v, idx) => ({
      ...v,
      filtered_rank: idx + 1,
    }));
  }

  window.handleInventoryFilterChange = function () {
    const dealerSel = document.getElementById('inventory-dealer-filter');
    const trimSel = document.getElementById('inventory-trim-filter');
    const intSel = document.getElementById('inventory-interior-filter');
    const statusSel = document.getElementById('inventory-status-filter');
    const sortSel = document.getElementById('inventory-sort-select');
    if (dealerSel) inventoryDealerFilter = dealerSel.value || 'ALL';
    if (trimSel) inventoryTrimFilter = trimSel.value || 'ALL';
    if (intSel) inventoryInteriorFilter = intSel.value || 'ALL';
    if (statusSel) inventoryStatusFilter = statusSel.value || 'ALL';
    if (sortSel) inventorySortBy = sortSel.value || 'deal_score_asc';

    if (currentDashboard) {
      const filtered = getFilteredAndSortedInventory(currentDashboard);
      if (filtered.length > 0 && !filtered.some((v) => v.id === selectedDealerId)) {
        selectedDealerId = filtered[0].id;
      }
      renderDashboard(currentDashboard);
    }
  };

  window.resetInventoryFilters = function () {
    inventoryDealerFilter = 'ALL';
    inventoryTrimFilter = 'ALL';
    inventoryInteriorFilter = 'ALL';
    inventoryStatusFilter = 'ALL';
    inventorySortBy = 'deal_score_asc';
    const dealerSel = document.getElementById('inventory-dealer-filter');
    const trimSel = document.getElementById('inventory-trim-filter');
    const intSel = document.getElementById('inventory-interior-filter');
    const statusSel = document.getElementById('inventory-status-filter');
    const sortSel = document.getElementById('inventory-sort-select');
    if (dealerSel) dealerSel.value = 'ALL';
    if (trimSel) trimSel.value = 'ALL';
    if (intSel) intSel.value = 'ALL';
    if (statusSel) statusSel.value = 'ALL';
    if (sortSel) sortSel.value = 'deal_score_asc';
    if (currentDashboard) {
      renderDashboard(currentDashboard);
    }
  };

  window.sortInventoryByColumn = function (colName) {
    const col = String(colName || '').toLowerCase();
    if (col === 'deal_score') {
      inventorySortBy = 'deal_score_asc';
    } else if (col === 'dealer') {
      inventorySortBy = inventorySortBy === 'dealer_asc' ? 'dealer_desc' : 'dealer_asc';
    } else if (col === 'trim') {
      inventorySortBy = inventorySortBy === 'trim_asc' ? 'trim_desc' : 'trim_asc';
    } else if (col === 'discount') {
      inventorySortBy = 'discount_desc';
    } else if (col === 'otd') {
      inventorySortBy = inventorySortBy === 'otd_asc' ? 'otd_desc' : 'otd_asc';
    } else if (col === 'lease') {
      inventorySortBy = 'lease_asc';
    } else if (col === 'status') {
      inventorySortBy = 'status';
    }
    const sortSel = document.getElementById('inventory-sort-select');
    if (sortSel) sortSel.value = inventorySortBy;
    if (currentDashboard) {
      renderDashboard(currentDashboard);
    }
  };

  function applyDashboardPayload(data) {
    if (!data) return;
    currentDashboard = data;
    const allVehicles = getAllInventoryVehicles(data);
    if (!selectedDealerId && allVehicles.length > 0) {
      selectedDealerId = allVehicles[0].id;
    }
    if (comparedDealerIds.length === 0 && allVehicles.length > 0) {
      comparedDealerIds = allVehicles.slice(0, 3).map((d) => d.id);
    }
    renderDashboard(data);
    mirrorToClientFirestore(data);
  }

  async function fetchDashboard() {
    try {
      const res = await fetch('/api/dashboard');
      if (res.ok) {
        const data = await res.json();
        applyDashboardPayload(data);
        return;
      }
    } catch (e) {
      // Fallback for file:// or offline mode
    }
    if (!currentDashboard && window.__INITIAL_DASHBOARD_SNAPSHOT__) {
      applyDashboardPayload(window.__INITIAL_DASHBOARD_SNAPSHOT__);
    }
  }

  function getSelectedDealer() {
    const allVehicles = getAllInventoryVehicles(currentDashboard);
    if (allVehicles.length === 0) return null;
    return allVehicles.find((d) => d.id === selectedDealerId) || allVehicles[0];
  }

  // ===========================================================================
  // UP TO 3 VEHICLES SELECTION & AUTONOMOUS MULTI-DEALER NEGOTIATION
  // ===========================================================================
  window.toggleCompareVehicle = function (dealerId, event) {
    if (event) event.stopPropagation();
    const idx = comparedDealerIds.indexOf(dealerId);
    if (idx >= 0) {
      if (comparedDealerIds.length > 1) {
        comparedDealerIds.splice(idx, 1);
      }
    } else {
      if (comparedDealerIds.length >= 3) {
        comparedDealerIds.shift();
      }
      comparedDealerIds.push(dealerId);
    }
    selectedDealerId = dealerId;
    if (currentDashboard) {
      renderDashboard(currentDashboard);
    }
  };

  window.selectCarByDealerId = function (dealerId) {
    if (!dealerId) return;
    selectedDealerId = dealerId;
    if (!comparedDealerIds.includes(dealerId)) {
      if (comparedDealerIds.length >= 3) {
        comparedDealerIds[comparedDealerIds.length - 1] = dealerId;
      } else {
        comparedDealerIds.push(dealerId);
      }
    }
    const allVehicles = getAllInventoryVehicles(currentDashboard);
    const found = allVehicles.find((d) => d.id === dealerId);
    if (found) {
      syncCalculatorInputsFromDealer(found);
      runReverseOtdCalculator();
    }
    if (currentDashboard) {
      renderDashboard(currentDashboard);
    }
    // Materialize inventory vehicle in backend state asynchronously if not already in dealers_ranked
    const ranked = (currentDashboard && currentDashboard.dealers_ranked) || [];
    if (!ranked.some((d) => d.id === dealerId)) {
      fetch('/api/select_inventory_vehicle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dealer_id: dealerId }),
      })
        .then((r) => (r.ok ? r.json() : null))
        .then((dash) => {
          if (dash && dash.dealers_ranked) {
            currentDashboard = dash;
            renderDashboard(dash);
          }
        })
        .catch(() => {});
    }
  };

  window.runAutoNegotiationForSelected = async function () {
    const btn = document.getElementById('auto-negotiate-btn');
    const banner = document.getElementById('auto-negotiate-summary-banner');
    const modeSelect = document.getElementById('autonomy-mode-select');
    const autonomyMode = modeSelect ? modeSelect.value : 'FULL_AUTOPILOT';
    const targetIds = comparedDealerIds.slice(0, 3);

    if (btn) {
      btn.disabled = true;
      btn.textContent = '⚡ Running Multi-Dealer Autonomous Negotiation...';
    }
    if (banner) {
      banner.classList.remove('hidden');
      banner.innerHTML = '<div class="text-emerald-300 font-mono animate-pulse">🚀 Dispatching Round 1 IN_TRANSIT December outreach &amp; executing multi-round Beat-It loops across your selected vehicles...</div>';
    }

    try {
      const res = await fetch('/api/auto_negotiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dealer_ids: targetIds,
          autonomy_mode: autonomyMode,
          max_rounds: 3,
          auto_simulate_replies: true,
        }),
      });
      if (res.ok) {
        const dash = await res.json();
        currentDashboard = dash;
        renderDashboard(dash);
        const runRes = dash.action_result || {};
        const summaries = runRes.dealer_run_summaries || [];
        if (banner) {
          banner.innerHTML = `
            <div class="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-emerald-500/30">
              <span class="font-bold text-emerald-300">✅ Autonomous Multi-Dealer Negotiation Completed (${escapeHtml(runRes.autonomy_mode || autonomyMode)} • ${runRes.rounds_executed || 0} Rounds)</span>
              <span class="font-mono text-white font-bold">Best Offer: ${escapeHtml(runRes.best_offer_after_run?.best_dealer_name || '--')} @ ${formatMoney(runRes.best_offer_after_run?.best_otd_total || 0, 2)} OTD</span>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-2.5 pt-1">
              ${summaries
                .map(
                  (s) => `
                <div class="p-2.5 rounded-lg bg-slate-950/90 border border-slate-800 font-mono text-[11px] space-y-1">
                  <div class="flex items-center justify-between">
                    <strong class="text-white">${escapeHtml(s.dealer_name)}</strong>
                    <span class="px-1.5 py-0.5 text-[10px] rounded ${
                      s.negotiation_status === 'DEAL_SECURED'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    }">${escapeHtml(s.negotiation_status)}</span>
                  </div>
                  <div class="text-slate-400 truncate">${escapeHtml(s.trim_level)} • VIN ${escapeHtml(s.vin)}</div>
                  <div class="text-emerald-300">OTD: ${formatMoney(s.starting_otd, 0)} → <strong>${formatMoney(s.ending_otd, 2)}</strong> (Saved <strong>${formatMoney(s.total_otd_saved, 0)}</strong>)</div>
                  <div class="text-[10px] text-cyan-300">Tone: ${escapeHtml(s.tone_modes_used || 'ZERO_BUZZWORD_NATURAL')}</div>
                </div>
              `
                )
                .join('')}
            </div>
          `;
        }
      }
    } catch (e) {
      if (banner) {
        banner.innerHTML = '<div class="text-rose-400">Error calling /api/auto_negotiate.</div>';
      }
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = '🚀 Kick Off & Auto-Negotiate Selected (Up to 3)';
      }
    }
  };

  window.syncLiveDealerInventory = async function () {
    const btn = document.getElementById('sync-live-inventory-btn');
    const panel = document.getElementById('live-scraper-status-panel');
    if (btn) {
      btn.disabled = true;
      btn.textContent = '📡 Scraping NJ Dealers...';
    }
    if (panel) {
      panel.classList.remove('hidden');
      panel.innerHTML = '<div class="text-cyan-300 font-mono animate-pulse">🔍 Querying Monmouth &amp; Ocean County Kia dealer inventory...</div>';
    }
    try {
      const res = await fetch('/api/sync_live_inventory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (res.ok) {
        const dash = await res.json();
        currentDashboard = dash;
        renderDashboard(dash);
        const sr = dash.scrape_result || {};
        const logs = sr.scrape_logs || [];
        if (panel) {
          panel.innerHTML = `
            <div class="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
              <span class="font-bold text-cyan-300">📡 Live Monmouth &amp; Ocean County Kia Dealer Scraper (${sr.live_vehicles_discovered_count || 0} Vehicles)</span>
              <button onclick="document.getElementById('live-scraper-status-panel').classList.add('hidden')" class="text-slate-400 hover:text-white">✕</button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-2 pt-1">
              ${logs
                .map(
                  (l) => `
                <div class="p-2 rounded-lg bg-slate-900 border border-slate-800 font-mono text-[11px]">
                  <div class="text-white font-semibold">${escapeHtml(l.dealer_name)}</div>
                  <div class="text-emerald-400">Status: ${escapeHtml(l.status)}</div>
                </div>
              `
                )
                .join('')}
            </div>
          `;
        }
      }
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = '📡 Scrape NJ Dealers';
      }
    }
  };

  // ===========================================================================
  // SIDE-BY-SIDE-BY-SIDE (UP TO 3 VEHICLES) CROSS-TRIM & COLOR-PARITY DECK
  // ===========================================================================
  function renderSideBySide3ColDeck(dealers) {
    const deck = document.getElementById('side-by-side-3col-deck');
    const badge = document.getElementById('compared-count-badge');
    if (!deck) return;

    const selectedList = dealers.filter((d) => comparedDealerIds.includes(d.id)).slice(0, 3);
    if (selectedList.length === 0 && dealers.length > 0) {
      selectedList.push(...dealers.slice(0, 3));
    }
    if (badge) {
      badge.textContent = `${selectedList.length} / 3 Vehicles Selected`;
    }

    deck.innerHTML = selectedList
      .map((d, idx) => {
        const isFocused = d.id === selectedDealerId;
        const msrp = Number(d.msrp || 53890);
        const selling = Number(d.selling_price || 51842);
        const discountAmt = msrp - selling;
        const discountPct = d.discount_pct || (msrp ? ((discountAmt / msrp) * 100).toFixed(2) : '0.00');
        const otd = Number(d.otd_total || 55303.11);
        const colorParityOtd = Number(d.color_parity_otd || otd);
        const colorDelta = Number(d.otd_color_delta || 0);
        const vsInv = Number(d.price_vs_trim_invoice || 0);
        const vsInvLabel =
          vsInv <= 0
            ? `${formatMoney(Math.abs(vsInv), 0)} Below Trim Invoice`
            : `+${formatMoney(vsInv, 0)} Above Trim Invoice`;
        const leaseMo = Number(d.implied_lease_36mo || d.lease_monthly_36m || 663);
        const leaseZero = Number(d.implied_sign_and_drive_lease_36mo || 724);
        const loan60 = Number(d.implied_finance_60mo || d.finance_monthly_60m || 1041);
        const addons = Number(d.dealer_addons_total || 0);
        const savedRounds = Number(d.total_otd_savings || 0);
        const negStatus = d.negotiation_status || 'ACTIVE';

        return `
          <div
            onclick="window.selectCarByDealerId('${d.id}')"
            class="rounded-xl border p-4 transition cursor-pointer flex flex-col justify-between ${
              isFocused
                ? 'border-emerald-400 bg-emerald-950/20 ring-2 ring-emerald-500/30'
                : 'border-slate-800 bg-slate-950/80 hover:border-slate-700'
            }"
          >
            <div>
              <div class="flex items-center justify-between gap-2">
                <span class="px-2 py-0.5 text-[10px] font-bold uppercase rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Slot #${idx + 1} • Priority #${d.trim_priority_rank || idx + 1} Trim
                </span>
                <span class="px-2 py-0.5 text-[10px] font-mono rounded ${
                  negStatus === 'DEAL_SECURED'
                    ? 'bg-emerald-500/25 text-emerald-200 border border-emerald-400/50'
                    : 'bg-slate-800 text-cyan-300 border border-slate-700'
                }">
                  ${escapeHtml(negStatus)} • R${d.round_Number || 1}
                </span>
              </div>

              <div class="font-extrabold text-sm text-white mt-2">${escapeHtml(d.trim_level)}</div>
              <div class="text-xs text-cyan-300 font-semibold mt-0.5">📍 ${escapeHtml(d.dealer_name)} (${escapeHtml(d.county || 'Monmouth County')})</div>
              <div class="flex flex-wrap items-center justify-between gap-1 text-[11px] text-slate-400 mt-1">
                <span class="font-mono text-slate-300">VIN: ${escapeHtml(d.vin)}</span>
                <span class="text-emerald-300">🎨 ${escapeHtml(d.interior_color)}</span>
              </div>

              <!-- Normalized Cross-Trim & Color-Parity Metrics -->
              <div class="mt-3 pt-3 border-t border-slate-800/90 space-y-1.5 font-mono text-xs">
                <div class="flex justify-between">
                  <span class="text-slate-400">Sticker MSRP:</span>
                  <span class="text-white font-semibold">${formatMoney(msrp)}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Selling (% Off Trim):</span>
                  <span class="text-emerald-400 font-bold">${formatMoney(selling)} (-${discountPct}%)</span>
                </div>
                <div class="flex justify-between text-[11px]">
                  <span class="text-slate-400">vs. Trim Invoice (-3.8%):</span>
                  <span class="${vsInv <= 0 ? 'text-emerald-300' : 'text-amber-300'}">${vsInvLabel}</span>
                </div>
                <div class="flex justify-between pt-1 border-t border-slate-800/60">
                  <span class="text-slate-300 font-semibold">Actual OTD (6.625%):</span>
                  <span class="text-white font-extrabold">${formatMoney(otd, 2)}</span>
                </div>
                <div class="flex justify-between text-[11px]">
                  <span class="text-purple-300">Color-Parity OTD:</span>
                  <span class="text-purple-200 font-bold">${formatMoney(colorParityOtd, 2)} ${colorDelta > 0 ? '(-$' + Math.round(colorDelta) + ' color opt)' : ''}</span>
                </div>
                <div class="flex justify-between pt-1 border-t border-slate-800/60">
                  <span class="text-cyan-300">60m Loan / 36m Lease:</span>
                  <span class="text-cyan-200 font-bold">${formatMoney(loan60, 0)}/m • ${formatMoney(leaseMo, 0)}/m</span>
                </div>
                <div class="flex justify-between text-[11px]">
                  <span class="text-slate-400">$0 Due Sign &amp; Drive:</span>
                  <span class="text-slate-300">${formatMoney(leaseZero, 0)}/mo</span>
                </div>
                <div class="flex justify-between text-[11px]">
                  <span class="text-slate-400">Add-Ons / Multi-Round Drop:</span>
                  <span class="${addons > 0 ? 'text-rose-400' : 'text-emerald-300'}">${addons > 0 ? '+' + formatMoney(addons) + ' Add-Ons' : '$0 Add-Ons'} • ${savedRounds > 0 ? 'Saved ' + formatMoney(savedRounds, 0) : 'Initial Quote'}</span>
                </div>
              </div>
            </div>

            <div class="flex gap-1.5 mt-3 pt-2.5 border-t border-slate-800/80">
              <button
                type="button"
                onclick="event.stopPropagation(); window.openDealerInCalculator('${d.id}')"
                class="flex-1 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer"
              >
                🧮 Calculator
              </button>
              <button
                type="button"
                onclick="event.stopPropagation(); window.selectCarByDealerId('${d.id}'); window.simulateReplyForSelectedVin()"
                class="flex-1 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 cursor-pointer"
              >
                🎲 Next Round
              </button>
            </div>
          </div>
        `;
      })
      .join('');
  }

  window.setQuickCashDown = function (amount) {
    const downEl = document.getElementById('v3-budget-down-input');
    const btn3k = document.getElementById('btn-down-3000');
    const btn0 = document.getElementById('btn-down-0');
    const num = Number(amount || 0);
    if (downEl) downEl.value = num;
    if (num === 3000) {
      btn3k?.classList.add('bg-emerald-600', 'text-white', 'font-bold');
      btn3k?.classList.remove('bg-slate-900', 'text-slate-300');
      btn0?.classList.remove('bg-emerald-600', 'text-white', 'font-bold');
      btn0?.classList.add('bg-slate-900', 'text-slate-300');
    } else if (num === 0) {
      btn0?.classList.add('bg-emerald-600', 'text-white', 'font-bold');
      btn0?.classList.remove('bg-slate-900', 'text-slate-300');
      btn3k?.classList.remove('bg-emerald-600', 'text-white', 'font-bold');
      btn3k?.classList.add('bg-slate-900', 'text-slate-300');
    }
    window.handleV3BudgetChange();
  };

  window.handleV3BudgetChange = function () {
    const stageSel = document.getElementById('v3-negotiation-stage-select');
    const gagBadge = document.getElementById('header-trade-gag-badge');
    const gate2 = document.getElementById('trade-gate-2-checkbox');
    if (stageSel && gagBadge) {
      if (stageSel.value === 'STAGE_2') {
        gagBadge.textContent = '🔓 Stage 2 Active: 36/12k Lease (0.00185 MF) & NJ Trade Credit';
        gagBadge.className = 'hidden lg:inline-block px-2 py-0.5 text-[10px] font-mono rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40';
        if (gate2) gate2.checked = true;
      } else {
        gagBadge.textContent = '🔒 Outbound Lease & Trade Gag Active';
        gagBadge.className = 'hidden lg:inline-block px-2 py-0.5 text-[10px] font-mono rounded bg-amber-500/15 text-amber-300 border border-amber-500/30';
        if (gate2) gate2.checked = false;
      }
    }
    renderSelectedVinInspector();
    window.updateTradeInWorkflow();
  };

  window.toggleWorksheetAuditDrawer = function (forceState) {
    const drawer = document.getElementById('mode4-worksheet-drawer');
    if (!drawer) return;
    if (typeof forceState === 'boolean') {
      drawer.classList.toggle('hidden', !forceState);
    } else {
      drawer.classList.toggle('hidden');
    }
  };

  window.handleWorksheetFileSelected = function (inputEl) {
    if (!inputEl || !inputEl.files || !inputEl.files[0]) return;
    const f = inputEl.files[0];
    const box = document.getElementById('mode4-audit-result-box');
    if (box) {
      box.classList.remove('hidden');
      box.innerHTML = `<div class="text-cyan-300">📎 Attached worksheet file: <strong>${escapeHtml(f.name)}</strong> (${Math.round(f.size / 1024)} KB). Click <strong>🔬 Audit Lease Sheet</strong> to reverse-engineer the Money Factor &amp; draft Herbie's buy-rate counter.</div>`;
    }
  };

  window.runMode4WorksheetAudit = async function () {
    const d = getSelectedDealer() || {};
    const quotedMonthly = parseFloat(document.getElementById('audit-quoted-monthly')?.value || '739');
    const dueSigning = parseFloat(document.getElementById('audit-due-signing')?.value || '3000');
    const sellingPrice = parseFloat(document.getElementById('audit-selling-price')?.value || String(d.selling_price || 53500));
    const addons = parseFloat(document.getElementById('audit-addons')?.value || '0');
    const msrp = Number(d.msrp || 56035);
    const docFee = Number(d.doc_fee || 689);
    const rvPct = Number(d.residual_percent || 64);
    const rebate = parseFloat(document.getElementById('v3-budget-rebate-input')?.value || '750');
    const box = document.getElementById('mode4-audit-result-box');
    const modePill = document.getElementById('herbie-active-mode-pill');
    if (modePill) {
      modePill.textContent = 'Mode 4: Lease Sheet Audit';
      modePill.className = 'px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-purple-500/20 text-purple-300 border border-purple-500/40';
    }

    const renderAuditResult = (audit) => {
      if (!audit || !box) return;
      box.classList.remove('hidden');
      const over36 = Number(audit.total_36mo_overcharge || 0);
      const buyMo = Number(audit.buy_rate_monthly_payment || 679);
      const impMf = Number(audit.implied_dealer_money_factor || 0.00245).toFixed(5);
      const impApr = Number(audit.implied_dealer_apr_percent || 5.88).toFixed(2);
      box.innerHTML = `
        <div class="flex flex-wrap items-center justify-between gap-2 pb-1.5 border-b border-slate-800">
          <span class="font-bold ${over36 > 100 ? 'text-rose-400' : 'text-emerald-400'}">
            ${over36 > 100 ? '🚨 HIDDEN MF / RESERVE MARKUP DETECTED' : '✅ CLEAN BUY-RATE LEASE SHEET'}
          </span>
          <span class="text-white font-bold">36-Mo Overcharge: ${formatMoney(over36, 0)}</span>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 text-[11px]">
          <div><span class="text-slate-400 block">Implied Dealer MF:</span><strong class="text-rose-300">${impMf} (${impApr}% APR)</strong></div>
          <div><span class="text-slate-400 block">KMF Tier-1 Buy Rate:</span><strong class="text-emerald-300">0.00185 (4.44% APR)</strong></div>
          <div><span class="text-slate-400 block">True Buy-Rate Payment:</span><strong class="text-cyan-300">${formatMoney(buyMo, 2)}/mo (vs ${formatMoney(quotedMonthly, 0)}/mo)</strong></div>
        </div>
      `;
      const counterReply = `I reviewed your 36/12k lease worksheet on ${d.trim_level || 'the 2027 Telluride Hybrid'} (VIN ${d.vin || '5XYPDESA9VG055148'}). At $${sellingPrice.toLocaleString()} selling price with $${dueSigning.toLocaleString()} total out-of-pocket, KMF Tier-1 buy-rate Money Factor (0.00185) and ${rvPct}% residual yield $${buyMo.toFixed(2)}/mo including NJ 6.625% tax—meaning the $${quotedMonthly.toFixed(0)}/mo quote reflects a marked-up ${impMf} Money Factor (+$${over36.toFixed(0)} over 36 months). Strip the rate markup to 0.00185 base buy rate with $0 add-ons and send the revised buyer's order.`;
      const scriptEl = document.getElementById('kpi-leverage-script');
      if (scriptEl) scriptEl.textContent = counterReply;
      appendAgentChatBubble(
        'agent',
        `### 🔬 Mode 4 Lease Worksheet Forensic Audit\n* **Implied Dealer Money Factor**: \`${impMf}\` (\`${impApr}% APR\`) vs. KMF Buy Rate \`0.00185\` (\`4.44% APR\`)\n* **True Buy-Rate Monthly Payment**: **$${buyMo.toFixed(2)}/mo** (Dealer quoted **$${quotedMonthly.toFixed(2)}/mo** — overcharging **$${over36.toFixed(2)}** over 36 months)\n* **Ready-to-Send Reply Updated Below**:\n> ${counterReply}`,
        'HERBIE_MODE_4_AUDIT',
        { model_routing: { selected_model: 'calculate_nj_payments', task_complexity: 'forensic_audit' }, self_evaluation: { passed_all_checks: true } }
      );
    };

    try {
      const res = await fetch('/api/audit_worksheet_upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          msrp,
          selling_price: sellingPrice,
          quoted_monthly_payment: quotedMonthly,
          quoted_Total_due_at_signing: dueSigning,
          doc_fee: docFee,
          dealer_addons: addons,
          rebates: rebate,
          residual_percent: rvPct,
          term_months: 36,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        renderAuditResult(data.audit || data);
        return;
      }
    } catch (_e) {
      // Fallback deterministic local calculation
    }
    const residualVal = msrp * (rvPct / 100);
    const netCap = sellingPrice + docFee + 400 + 650 + addons - rebate - Math.max(0, dueSigning - quotedMonthly);
    const depMo = (netCap - residualVal) / 36;
    const buyRentMo = (netCap + residualVal) * 0.00185;
    const buyRateMo = Number(((depMo + buyRentMo) * 1.06625).toFixed(2));
    const preTaxQuoted = quotedMonthly / 1.06625;
    const impliedRent = Math.max(0, preTaxQuoted - depMo);
    const impliedMf = (netCap + residualVal) > 0 ? impliedRent / (netCap + residualVal) : 0.00185;
    renderAuditResult({
      implied_dealer_money_factor: impliedMf,
      implied_dealer_apr_percent: impliedMf * 2400,
      buy_rate_monthly_payment: buyRateMo,
      total_36mo_overcharge: Math.max(0, (quotedMonthly - buyRateMo) * 36),
    });
  };

  function renderFiveDealerTracker(data, allVehicles) {
    const container = document.getElementById('five-dealer-tracker-cards');
    if (!container) return;

    const trackerRows =
      (data && Array.isArray(data.five_dealer_tracker) && data.five_dealer_tracker.length > 0)
        ? data.five_dealer_tracker
        : [];

    // If five_dealer_tracker is not pre-populated in snapshot, build it from the 5 canonical dealers
    const canonicalList =
      trackerRows.length > 0
        ? trackerRows
        : [
            { dealer_name: 'Matt Blatt Kia of Toms River', county: 'Ocean County', doc_fee: 689, quirk_note: 'Lowest Doc Fee Anchor ($689); strip protection pack' },
            { dealer_name: 'DiFeo Kia of Lakewood', county: 'Ocean County', doc_fee: 749, quirk_note: 'Straightforward family store ($749 doc)' },
            { dealer_name: 'Manahawkin Kia', county: 'Ocean County', doc_fee: 749, quirk_note: 'Aggressive volume matcher ($749 doc)' },
            { dealer_name: 'Raceway Kia of Freehold', county: 'Monmouth County', doc_fee: 799, quirk_note: 'High volume ($799 doc); watch mandatory Etch/LoJack' },
            { dealer_name: "Sansone Jr's 66 Automall Kia", county: 'Monmouth County', doc_fee: 895, quirk_note: 'Unified Neptune & Keyport Group ($895 highest doc fee)' },
          ].map((meta) => {
            const matches = allVehicles.filter(
              (v) => normalizeDealerGroupName(v.base_dealer_name || v.dealer_name) === meta.dealer_name
            );
            matches.sort((a, b) => computeVehicleTrueDealScore(a) - computeVehicleTrueDealScore(b));
            const bestV = matches[0] || {};
            return {
              dealer_id: bestV.id || 'dlr-matt-blatt-kia-of-toms-river-vg055148',
              dealer_name: meta.dealer_name,
              county: meta.county,
              doc_fee: Number(bestV.doc_fee || meta.doc_fee),
              quirk_note: meta.quirk_note,
              active_vin: bestV.vin || '--',
              trim_level: bestV.trim_level || '2027 Kia Telluride Hybrid SX X-Line',
              interior_color: bestV.interior_color || 'Saddle Brown & Millstone',
              is_priority_non_black: isVehiclePriorityNonBlack(bestV),
              inventory_status: bestV.inventory_status || 'IN_TRANSIT',
              msrp: Number(bestV.msrp || 56035),
              selling_price: Number(bestV.selling_price || 54535),
              dealer_addons_total: Number(bestV.dealer_addons_total || 0),
              true_deal_score: computeVehicleTrueDealScore(bestV),
              otd_total: Number(bestV.otd_total || 58488),
              lease_3k_down_monthly: Number(bestV.lease_3k_down_monthly || bestV.implied_lease_36mo || 679),
              lease_zero_down_monthly: Number(bestV.lease_zero_down_monthly || bestV.implied_sign_and_drive_lease_36mo || 768),
              deflection_strikes: Number(bestV.deflection_strikes || 0),
              total_inventory_count: matches.length || 3,
              non_black_inventory_count: matches.filter((m) => isVehiclePriorityNonBlack(m)).length || 2,
            };
          });

    canonicalList.sort((a, b) => Number(a.true_deal_score || 0) - Number(b.true_deal_score || 0));

    container.innerHTML = canonicalList
      .map((row, idx) => {
        const rank = idx + 1;
        const vehId = row.dealer_id || row.id || '';
        const isFocused =
          vehId === selectedDealerId ||
          normalizeDealerGroupName(getSelectedDealer()?.dealer_name) === normalizeDealerGroupName(row.dealer_name);
        const score = Number(row.true_deal_score || 0);
        const scoreStr = score <= 0 ? `-$${Math.abs(Math.round(score)).toLocaleString()}` : `+$${Math.round(score).toLocaleString()}`;
        const isNonBlack = row.is_priority_non_black !== false;
        const strikes = Number(row.deflection_strikes || 0);
        const strikeBadge =
          strikes >= 2
            ? '<span class="px-1.5 py-0.5 text-[10px] font-mono font-bold rounded bg-rose-500/20 text-rose-300 border border-rose-500/40">💀 DEAD (2/2)</span>'
            : `<span class="px-1.5 py-0.5 text-[10px] font-mono rounded bg-slate-900 text-slate-300 border border-slate-800">Strikes: ${strikes}/2</span>`;

        return `
          <div
            onclick="window.selectCarByDealerId('${escapeHtml(vehId)}')"
            class="p-3 rounded-xl border transition cursor-pointer space-y-2 ${
              isFocused
                ? 'border-emerald-400 bg-emerald-950/20 ring-1 ring-emerald-500/30'
                : 'border-slate-800 bg-slate-950/90 hover:border-slate-700'
            }"
          >
            <div class="flex items-center justify-between gap-2">
              <div class="flex items-center gap-1.5">
                <span class="px-2 py-0.5 text-[10px] font-mono font-bold rounded ${
                  rank === 1
                    ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/40'
                    : 'bg-slate-800 text-slate-300'
                }">
                  #${rank} ${rank === 1 ? 'BEST SCORE' : ''}
                </span>
                <strong class="text-xs sm:text-sm text-white">${escapeHtml(row.dealer_name)}</strong>
              </div>
              <div class="flex items-center gap-1">
                <span class="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30" title="True Deal Score = (Selling - MSRP) + Doc Fee + Add-Ons">
                  Score: ${scoreStr}
                </span>
                ${strikeBadge}
              </div>
            </div>

            <div class="flex flex-wrap items-center justify-between gap-1 text-[11px]">
              <span class="text-slate-300 font-semibold">${escapeHtml(shortTrimLabel(row.trim_level))} • <span class="font-mono text-cyan-300">${escapeHtml(row.active_vin)}</span></span>
              <span class="${isNonBlack ? 'text-emerald-300 font-semibold' : 'text-slate-400'}">
                ${isNonBlack ? '★ ' : ''}${escapeHtml(row.interior_color || 'Non-Black')}
              </span>
            </div>

            <div class="grid grid-cols-3 gap-1.5 p-2 rounded-lg bg-slate-900/90 border border-slate-800/90 font-mono text-[11px]">
              <div>
                <span class="block text-[9px] text-slate-400">Selling / Doc</span>
                <strong class="text-emerald-400">${formatMoney(row.selling_price, 0)}</strong>
                <span class="text-slate-400 text-[10px]"> ($${Math.round(row.doc_fee || 689)})</span>
              </div>
              <div>
                <span class="block text-[9px] text-slate-400">True NJ OTD</span>
                <strong class="text-white">${formatMoney(row.otd_total, 0)}</strong>
              </div>
              <div>
                <span class="block text-[9px] text-slate-400">36m ($3k / $0)</span>
                <strong class="text-cyan-300">${formatMoney(row.lease_3k_down_monthly || 679, 0)}</strong>
                <span class="text-purple-300 text-[10px]"> / ${formatMoney(row.lease_zero_down_monthly || 768, 0)}</span>
              </div>
            </div>

            <div class="flex items-center justify-between gap-2 text-[10px] text-slate-400">
              <span class="truncate" title="${escapeHtml(row.quirk_note || '')}">💡 ${escapeHtml(row.quirk_note || 'NJ Dealer')}</span>
              <span class="font-mono text-cyan-300 shrink-0">${row.total_inventory_count || 3} VINs (${row.non_black_inventory_count || 2} ★)</span>
            </div>
          </div>
        `;
      })
      .join('');
  }

  function renderSelectedVinInspector() {
    const d = getSelectedDealer();
    if (!d) return;

    const msrp = Number(d.msrp || 56035);
    const selling = Number(d.selling_price || 54535);
    const docFee = Number(d.doc_fee || 689);
    const govFees = Number(d.gov_fees || 400);
    const addons = Number(d.dealer_addons_total || 0);
    const rebateInput = parseFloat(document.getElementById('v3-budget-rebate-input')?.value || String(d.rebates || 750));
    const rebates = Number.isFinite(rebateInput) ? rebateInput : 750;
    const targetMonthlyGoal = parseFloat(document.getElementById('v3-budget-monthly-input')?.value || '750');
    const rvPct = Number(d.residual_percent || (msrp >= 59000 ? 62 : msrp >= 58000 ? 63 : 64));
    const mf = Number(d.money_factor || 0.00185);

    const pureDiscount = msrp - selling;
    const discountPct = msrp > 0 ? ((pureDiscount / msrp) * 100).toFixed(2) : '0.00';
    const trueDealScore = computeVehicleTrueDealScore(d);
    const taxableBase = Math.max(0, selling + docFee + addons - rebates);
    const njSalesTax = Number((taxableBase * 0.06625).toFixed(2));
    const otd = Number(d.otd_total || (taxableBase + njSalesTax + govFees).toFixed(2));

    // Calculate both $3,000 Out-of-Pocket and $0 Down (True Sign & Drive) for the HUD
    const calc3k = calculateMonthlyFromOtdLocal({
      otdPrice: otd,
      msrp,
      docFee,
      govFees,
      taxRate: 6.625,
      rebates,
      cashDown: 3000,
      apr: 5.25,
      loanTerm: 60,
      rvPct,
      mf,
      leaseTerm: 36,
      acqFee: 650,
    });
    const calc0 = calculateMonthlyFromOtdLocal({
      otdPrice: otd,
      msrp,
      docFee,
      govFees,
      taxRate: 6.625,
      rebates,
      cashDown: 0,
      apr: 5.25,
      loanTerm: 60,
      rvPct,
      mf,
      leaseTerm: 36,
      acqFee: 650,
    });

    const lease3k = Number(d.lease_3k_down_monthly || calc3k.lease_from_otd_cap_cost.total_monthly_payment || 679);
    const lease0 = Number(d.lease_zero_down_monthly || calc0.lease_from_otd_cap_cost.sign_and_drive_zero_due_monthly || 768);
    const loan3k = Number(d.loan_3k_down_monthly_60m || calc3k.finance_purchase_from_otd.monthly_60mo || 999);
    const loan0 = Number(d.loan_zero_down_monthly_60m || calc0.finance_purchase_from_otd.monthly_60mo || 1056);

    const setTxt = (id, text) => {
      const el = document.getElementById(id);
      if (el) el.textContent = text;
    };

    const isNonBlack = isVehiclePriorityNonBlack(d);
    const intBadge = document.getElementById('hud-interior-badge');
    if (intBadge) {
      intBadge.textContent = isNonBlack
        ? `★ Priority Non-Black (${d.interior_color || 'Saddle Brown'})`
        : `⬛ All-Black (${d.interior_color || 'All-Black'})`;
      intBadge.className = isNonBlack
        ? 'px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
        : 'px-2 py-0.5 text-[10px] font-bold rounded bg-slate-800 text-slate-300 border border-slate-700';
    }

    setTxt('sel-vin-code', `VIN: ${d.vin || '5XYPDESA9VG055148'}`);
    setTxt('sel-vin-title', d.trim_level || '2027 Kia Telluride Hybrid SX X-Line');
    setTxt(
      'sel-vin-subtitle',
      `${d.dealer_name}${d.store_location ? ' (' + d.store_location + ')' : ''} • ${d.exterior_color || 'Wolf Gray'} / ${d.interior_color || 'Saddle Brown'} • ${d.inventory_status || 'IN_TRANSIT'}`
    );

    const scoreFormatted =
      trueDealScore <= 0
        ? `-${formatMoney(Math.abs(trueDealScore), 0)}`
        : `+${formatMoney(trueDealScore, 0)}`;
    setTxt('hud-true-deal-score', scoreFormatted);
    setTxt(
      'hud-deal-score-formula',
      `(${formatMoney(selling, 0)} - ${formatMoney(msrp, 0)}) + ${formatMoney(docFee, 0)} Doc + ${formatMoney(addons, 0)} Add-Ons`
    );

    const targetRange =
      msrp >= 59000
        ? '$55,300–$55,800'
        : msrp >= 58000
        ? '$54,400–$54,900'
        : '$52,500–$53,000';
    setTxt('sel-metric-msrp', formatMoney(msrp, 0));
    setTxt('hud-target-range-sub', `Stage 1 Target: ${targetRange}`);
    setTxt('sel-metric-selling', formatMoney(selling, 0));
    setTxt('sel-metric-discount', `-${discountPct}%`);
    setTxt('hud-pure-discount', `Pure Disc: ${formatMoney(pureDiscount, 0)} + ${formatMoney(rebates, 0)} Rebate`);
    setTxt('sel-metric-otd', formatMoney(otd, 2));
    setTxt('hud-otd-fee-sub', `6.625% Tax + ${formatMoney(docFee, 0)} Doc + ${formatMoney(govFees, 0)} MVC`);

    setTxt('hud-lease-rv-badge', `${rvPct}% RV • ${(mf * 2400).toFixed(2)}% APR`);
    setTxt('hud-lease-3k', `${formatMoney(lease3k, 2)}/mo`);
    setTxt('hud-lease-0down', `${formatMoney(lease0, 2)}/mo`);
    setTxt('hud-loan-3k', `${formatMoney(loan3k, 2)}/mo`);
    setTxt('hud-loan-0down', `${formatMoney(loan0, 2)}/mo`);
    setTxt('sel-metric-lease-mo', `${formatMoney(lease3k, 0)}/mo`);
    setTxt('sel-metric-loan-60', `${formatMoney(loan3k, 0)}/mo`);

    const overBudgetPerMo = Math.max(0, lease3k - targetMonthlyGoal);
    const extraOtdNeeded = overBudgetPerMo > 0 ? Math.round(overBudgetPerMo * 33.8) : 0;
    setTxt(
      'hud-extra-discount-needed',
      extraOtdNeeded > 0 ? `-${formatMoney(extraOtdNeeded, 0)} More Needed` : `$0 (Beats $${Math.round(targetMonthlyGoal)}/mo!)`
    );
    setTxt(
      'hud-budget-status-sub',
      extraOtdNeeded > 0
        ? `$3k Lease is +${formatMoney(overBudgetPerMo, 0)}/mo over $${Math.round(targetMonthlyGoal)} goal`
        : `$3k Lease is ${formatMoney(targetMonthlyGoal - lease3k, 0)}/mo under $${Math.round(targetMonthlyGoal)} goal`
    );

    const flagsEl = document.getElementById('hud-forensic-flags');
    if (flagsEl) {
      const flags = [];
      if (addons > 0) flags.push(`🚨 Mandatory Add-Ons (+${formatMoney(addons, 0)}) — demand removal`);
      if (mf > 0.00186) flags.push(`🚨 Marked-Up MF (${mf.toFixed(5)} vs 0.00185 buy rate)`);
      if (docFee >= 850) flags.push(`⚠️ High NJ Doc Fee (${formatMoney(docFee, 0)} at Sansone Jr's) — demand extra cap cost drop`);
      if (flags.length > 0) {
        flagsEl.className = 'p-2.5 rounded-xl bg-rose-950/30 border border-rose-500/40 text-xs font-mono text-rose-200';
        flagsEl.innerHTML = flags.map((f) => escapeHtml(f)).join(' • ');
      } else {
        flagsEl.className = 'p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-emerald-300';
        flagsEl.textContent = `✅ CLEAN SPEC: $0 mandatory add-ons • Buy-rate 0.00185 MF baseline • $${Math.round(rebates)} Kia Rebate separated from pure dealer discount.`;
      }
    }

    const slider = document.getElementById('quick-otd-slider');
    if (slider) {
      slider.value = Math.round(otd);
      window.handleQuickOtdSlider(Math.round(otd));
    }
  }

  window.handleQuickOtdSlider = async function (otdVal) {
    const d = getSelectedDealer() || {};
    const otdPrice = parseFloat(otdVal || '56300');
    const badge = document.getElementById('slider-otd-Badge');
    if (badge) badge.textContent = `${formatMoney(otdPrice, 0)} OTD`;

    const msrp = Number(d.msrp || 56035);
    const docFee = Number(d.doc_fee || 689);
    const govFees = Number(d.gov_fees || 400);
    const rebates = parseFloat(document.getElementById('v3-budget-rebate-input')?.value || String(d.rebates || 750));
    const rvPct = Number(d.residual_percent || (msrp >= 59000 ? 62 : msrp >= 58000 ? 63 : 64));
    const mf = Number(d.money_factor || 0.00185);
    const cashDown = parseFloat(document.getElementById('v3-budget-down-input')?.value || '3000');

    const applySliderCalc = (calc) => {
      if (!calc) return;
      const b = calc.reverse_otd_breakdown || {};
      const fin = calc.finance_purchase_from_otd || {};
      const lse = calc.lease_from_otd_cap_cost || {};

      const elSell = document.getElementById('slider-implied-selling');
      const elLoan = document.getElementById('slider-implied-loan60');
      const elLease = document.getElementById('slider-implied-lease');
      const elSign = document.getElementById('slider-implied-signdrive');

      if (elSell) {
        elSell.textContent = `${formatMoney(b.implied_selling_price_cap_cost, 0)} (${b.implied_discount_pct}% off)`;
      }
      if (elLoan) {
        elLoan.textContent = `${formatMoney(fin.monthly_60mo, 2)}/mo`;
      }
      if (elLease) {
        elLease.textContent = `${formatMoney(lse.total_monthly_payment, 2)}/mo`;
      }
      if (elSign) {
        elSign.textContent = `${formatMoney(lse.sign_and_drive_zero_due_monthly, 2)}/mo`;
      }
    };

    const localCalc = calculateMonthlyFromOtdLocal({
      otdPrice,
      msrp,
      docFee,
      govFees,
      taxRate: 6.625,
      rebates,
      cashDown,
      apr: 5.25,
      loanTerm: 60,
      rvPct,
      mf,
      leaseTerm: 36,
      acqFee: 650,
    });
    applySliderCalc(localCalc);
  };

  // ===========================================================================
  // TWO-CHECKBOX AFFIRMATIVE TRADE-IN WORKFLOW
  // ===========================================================================
  window.updateTradeInWorkflow = async function () {
    const d = getSelectedDealer() || {};
    const gate1 = Boolean(document.getElementById('trade-gate-1-checkbox')?.checked);
    const gate2 = Boolean(document.getElementById('trade-gate-2-checkbox')?.checked);
    const tradeVal = parseFloat(document.getElementById('trade-val-input')?.value || '18000');
    const payoffVal = parseFloat(document.getElementById('trade-payoff-input')?.value || '0');
    const carmaxFloor = parseFloat(document.getElementById('trade-carmax-input')?.value || '18500');
    const postTradeSelling = parseFloat(document.getElementById('trade-post-selling-input')?.value || '0');

    const pill = document.getElementById('trade-gate-status-pill');
    const headerGag = document.getElementById('header-trade-gag-badge');
    const panel = document.getElementById('trade-in-impact-panel');

    const renderTradeImpactUi = (t) => {
      if (pill) {
        pill.textContent = t.stage_label || 'STAGE 0';
        pill.className = gate2
          ? 'text-[11px] font-mono px-2.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
          : gate1
          ? 'text-[11px] font-mono px-2.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
          : 'text-[11px] font-mono px-2.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30';
      }
      if (headerGag) {
        headerGag.textContent = gate2
          ? '🔓 Phase 2 Trade Unlocked (Lease Gag Active)'
          : '🔒 Lease & Trade Gag Active';
      }
      if (panel) {
        const shellHtml =
          t.shell_game_detected && (t.shell_game_warnings || []).length > 0
            ? `<div class="p-2 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 font-semibold">${t.shell_game_warnings.map((w) => escapeHtml(w)).join('<br>')}</div>`
            : '';
        const scriptHtml =
          gate2 && t.phase_2_outbound_trade_script
            ? `<div class="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-emerald-200">
                 <div class="text-[10px] font-bold uppercase text-emerald-400 mb-1">🔓 Phase 2 Post-OTD Lock Trade-In Script Unlocked:</div>
                 <div class="italic">&ldquo;${escapeHtml(t.phase_2_outbound_trade_script)}&rdquo;</div>
               </div>`
            : '';

        panel.innerHTML = `
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px]">
            <div class="p-2 rounded bg-slate-950 border border-slate-800">
              <span class="text-slate-400 block text-[10px]">NJ 6.625% Tax Savings</span>
              <span class="text-emerald-400 font-bold">+${formatMoney(t.nj_sales_tax_credit_savings, 2)}</span>
            </div>
            <div class="p-2 rounded bg-slate-950 border border-slate-800">
              <span class="text-slate-400 block text-[10px]">CarMax Tax-Equiv Floor</span>
              <span class="text-cyan-300 font-bold">${formatMoney(t.carmax_tax_equivalent_dealer_floor, 0)}</span>
            </div>
            <div class="p-2 rounded bg-slate-950 border border-slate-800">
              <span class="text-slate-400 block text-[10px]">Net OTD After Trade</span>
              <span class="text-white font-extrabold">${formatMoney(t.adjusted_otd_after_trade_and_tax_credit, 2)}</span>
            </div>
            <div class="p-2 rounded bg-slate-950 border border-slate-800">
              <span class="text-slate-400 block text-[10px]">60m Loan / 36m Lease</span>
              <span class="text-purple-300 font-bold">${formatMoney(t.monthly_60mo_with_trade, 0)}/m • ${formatMoney(t.lease_36mo_with_trade, 0)}/m</span>
            </div>
          </div>
          <div class="text-[11px] text-slate-300">${escapeHtml(t.carmax_comparison_verdict || '')}</div>
          ${shellHtml}
          ${scriptHtml}
        `;
      }
    };

    // Instant client-side trade-in & NJ 6.625% sales tax credit calculation
    const lockedOtd = Number(d.otd_total || 55303.11);
    const msrp = Number(d.msrp || 53890);
    const docFee = Number(d.doc_fee || 499);
    const govFees = Number(d.gov_fees || 385);
    const rebates = Number(d.rebates || 500);
    const lockedSelling = Number(d.selling_price || 51842);
    const taxSaved = Number((Math.max(0, tradeVal) * 0.06625).toFixed(2));
    const netTradeEquity = tradeVal - payoffVal;
    const carmaxEquivFloor = Math.round(carmaxFloor / 1.06625);
    const adjustedOtd = Math.max(0, Number((lockedOtd - netTradeEquity - taxSaved).toFixed(2)));
    const localWithTrade = calculateMonthlyFromOtdLocal({
      otdPrice: adjustedOtd,
      msrp,
      docFee,
      govFees,
      taxRate: 6.625,
      rebates,
      cashDown: 0,
      apr: 4.9,
      loanTerm: 60,
      rvPct: Number(d.residual_percent || 62),
      mf: Number(d.money_factor || 0.00190),
      leaseTerm: 36,
      acqFee: 650,
    });
    const shellWarnings = [];
    if (postTradeSelling > 0 && postTradeSelling > lockedSelling + 10) {
      shellWarnings.push(
        `🚨 SHELL-GAME ALERT: Dealer raised new-car selling price from ${formatMoney(lockedSelling, 0)} to ${formatMoney(postTradeSelling, 0)} (+${formatMoney(postTradeSelling - lockedSelling, 0)}) after you mentioned your trade-in!`
      );
    }
    renderTradeImpactUi({
      stage_label: gate2
        ? 'STAGE 2: OTD Locked • Phase 2 Trade Active'
        : gate1
        ? 'STAGE 1: Private Preview (Dealer Gag Active)'
        : 'STAGE 0: Outbound Trade-In & Lease Gag Active',
      nj_sales_tax_credit_savings: taxSaved,
      carmax_tax_equivalent_dealer_floor: carmaxEquivFloor,
      adjusted_otd_after_trade_and_tax_credit: adjustedOtd,
      monthly_60mo_with_trade: localWithTrade.finance_purchase_from_otd.monthly_60mo,
      lease_36mo_with_trade: localWithTrade.lease_from_otd_cap_cost.total_monthly_payment,
      carmax_comparison_verdict:
        tradeVal + taxSaved >= carmaxFloor
          ? `✅ Dealer trade (${formatMoney(tradeVal, 0)}) + NJ 6.625% tax credit (+${formatMoney(taxSaved, 0)}) = ${formatMoney(tradeVal + taxSaved, 0)} effective value (beats ${formatMoney(carmaxFloor, 0)} CarMax offer by ${formatMoney(tradeVal + taxSaved - carmaxFloor, 0)}).`
          : `⚠️ Dealer trade (${formatMoney(tradeVal, 0)}) + NJ tax credit (+${formatMoney(taxSaved, 0)}) = ${formatMoney(tradeVal + taxSaved, 0)} is BELOW your ${formatMoney(carmaxFloor, 0)} CarMax floor. Demand at least ${formatMoney(carmaxEquivFloor, 0)} trade allowance.`,
      shell_game_detected: shellWarnings.length > 0,
      shell_game_warnings: shellWarnings,
      phase_2_outbound_trade_script: `Now that we have the ${formatMoney(lockedOtd, 0)} Out-The-Door price locked in writing on VIN ${d.vin || '5XYP5DGC8VG041822'}, I also have a written ${formatMoney(carmaxFloor, 0)} CarMax offer on my current vehicle. With NJ's 6.625% sales tax credit, if you match ${formatMoney(carmaxEquivFloor, 0)} on the trade while keeping our ${formatMoney(lockedSelling, 0)} selling price untouched, we can wrap both up together.`,
    });

    try {
      const res = await fetch('/api/trade_in_impact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dealer_id: d.id || 'dlr-raceway-kia-of-freehold',
          locked_vehicle_otd: lockedOtd,
          msrp,
          doc_fee: docFee,
          gov_fees: govFees,
          rebates,
          trade_in_value: tradeVal,
          trade_in_payoff: payoffVal,
          carmax_offer_floor: carmaxFloor,
          private_preview_confirmed: gate1,
          otd_locked_confirmed: gate2,
          locked_pre_trade_selling_price: lockedSelling,
          post_trade_dealer_selling_price: postTradeSelling,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.trade_in_impact) {
          renderTradeImpactUi(data.trade_in_impact);
        }
      }
    } catch (e) {
      // Already rendered via deterministic client-side engine
    }
  };

  // ===========================================================================
  // PRACTICAL "LOG DEALER REPLY & INSTANT 2-3 SENTENCE COUNTER" WORKSPACE
  // ===========================================================================
  window.loadSampleDealerReply = function (sampleType) {
    const box = document.getElementById('raw-dealer-reply-input');
    if (!box) return;
    if (sampleType === 'jargon') {
      box.value =
        'We are already at invoice at $52,400 selling price ($55,950 OTD) and losing money on this 2027 Telluride Hybrid. Come into the showroom this evening if you want to talk numbers.';
    } else {
      box.value =
        'Hi! We can offer $51,950 selling price ($55,418 OTD including $499 doc fee and NJ tax/tags) with $0 dealer add-ons on the IN_TRANSIT 2027 Telluride Hybrid arriving late December.';
    }
  };

  window.submitLogDealerReply = async function (autoDispatch) {
    const dealerSelect = document.getElementById('reply-dealer-select');
    const rawBox = document.getElementById('raw-dealer-reply-input');
    const parseBtn = document.getElementById('parse-dealer-reply-btn');
    const dealerId = dealerSelect?.value || selectedDealerId || 'dlr-raceway-kia-of-freehold';
    const dealersList = getAllInventoryVehicles(currentDashboard);
    const targetDealer = dealersList.find((d) => d.id === dealerId) || dealersList[0] || {};

    let rawText = rawBox?.value?.trim() || '';
    if (!rawText) {
      // Auto-populate from the selected dealer's latest reply (or realistic quote) so clicking the button always works immediately
      rawText =
        targetDealer.last_dealer_message ||
        `Hi! We can offer $${Number(targetDealer.selling_price || 51842).toLocaleString()} selling price ($${Number(
          targetDealer.otd_total || 55418
        ).toLocaleString()} OTD including $${Number(targetDealer.doc_fee || 499)} doc fee and NJ tax/tags) with $0 dealer add-ons on the 2027 Kia Telluride Hybrid (VIN ${
          targetDealer.vin || '5XYP5DGC8VG041822'
        }).`;
      if (rawBox) {
        rawBox.value = rawText;
      }
    }

    if (parseBtn) {
      parseBtn.textContent = '⏳ Parsing & Drafting Counter...';
      parseBtn.disabled = true;
    }

    const applyCounterToUi = (dashData, bodyText, toneMode) => {
      const toneBadge = document.getElementById('counter-tone-badge');
      const scriptEl = document.getElementById('kpi-leverage-script');
      const resultBox = document.getElementById('parsed-counter-result-box');
      if (toneBadge) {
        if (toneMode === 'REACTIVE_ACCOUNTING_MIRROR') {
          toneBadge.className = 'text-[10px] font-bold uppercase tracking-wider text-purple-300';
          toneBadge.textContent = '🔥 REACTIVE MIRROR TRIGGERED (Dealer Used Accounting Jargon First)';
        } else {
          toneBadge.className = 'text-[10px] font-bold uppercase tracking-wider text-emerald-400';
          toneBadge.textContent = '🤫 ZERO-BUZZWORD NATURAL BUYER COUNTER (2–3 Sentences)';
        }
      }
      if (scriptEl && bodyText) {
        scriptEl.textContent = bodyText;
        const dList = (dashData && dashData.dealers_ranked) || dealersList;
        const actDealer = dList.find((d) => d.id === dealerId) || dList[0] || {};
        const actEmail = actDealer.contact_email || 'sales@dealer.example.com';
        const actPhone = actDealer.contact_phone || '+17325550142';
        const elEmail = document.getElementById('active-script-email-link');
        if (elEmail) {
          elEmail.href = `mailto:${actEmail}?subject=${encodeURIComponent(
            '2027 Kia Telluride Hybrid'
          )}&body=${encodeURIComponent(bodyText)}`;
        }
        const elSms = document.getElementById('active-script-sms-link');
        if (elSms) {
          elSms.href = `sms:${actPhone}?body=${encodeURIComponent(bodyText)}`;
        }
      }
      if (resultBox) {
        resultBox.classList.add('ring-2', 'ring-emerald-400');
        setTimeout(() => resultBox.classList.remove('ring-2', 'ring-emerald-400'), 1800);
      }
    };

    try {
      const res = await fetch('/api/log_dealer_reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dealer_id: dealerId,
          raw_reply_text: rawText,
          auto_draft_counter: true,
          auto_dispatch: Boolean(autoDispatch),
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const dash = await res.json();
      currentDashboard = dash;
      selectedDealerId = dealerId;
      renderDashboard(dash);

      const act = dash.action_result || {};
      const gen = act.generated_counter || {};
      const counterBody = gen.body || gen.script || act.natural_counter_script || '';
      applyCounterToUi(dash, counterBody, gen.tone_mode);
      if (parseBtn) {
        parseBtn.textContent = '✅ Counter Drafted & Queued!';
      }
    } catch (err) {
      console.warn('Fallback local reply parser triggered:', err);
      const jargon = /\b(invoice|holdback|floorplan|money\s*factor)\b/i.test(rawText);
      const priceMatches = rawText.match(/\$?\s*([456][0-9],?[0-9]{3}(?:\.[0-9]{1,2})?)/g) || [];
      const parsedPrices = priceMatches.map((m) => Number(m.replace(/[^0-9.]/g, ''))).filter((v) => v >= 45000 && v <= 70000);
      const detectedOtd = parsedPrices.length ? Math.max(...parsedPrices) : Number(targetDealer.otd_total || 55800);
      const counterOtd = Math.round(Math.min(Number(targetDealer.recommended_counter_otd || 54971), detectedOtd - 400));
      const salesperson = (targetDealer.contact_name || 'there').split(' ')[0];
      const vinStr = targetDealer.vin || '5XYP5DGC8VG041822';
      const fallbackBody = jargon
        ? `Hi ${salesperson}, since you mentioned invoice, with Kia's factory holdback and volume bonus on this incoming 2027 Telluride Hybrid (VIN ${vinStr}), if we can lock $${counterOtd.toLocaleString()} Out-The-Door with $0 dealer add-ons I will place a deposit right now. -Alex`
        : `Hi ${salesperson}, thanks for sending the numbers on the incoming 2027 Kia Telluride Hybrid (VIN ${vinStr}). If we can lock $${counterOtd.toLocaleString()} all-in Out-The-Door including NJ 6.625% tax and MVC fees with zero dealer add-ons, I'm ready to put a deposit down today. -Alex`;

      if (currentDashboard) {
        const newDraft = {
          id: 'msg-local-' + Date.now(),
          dealer_id: dealerId,
          dealer_name: targetDealer.dealer_name || dealerId,
          to_contact: targetDealer.contact_email || 'sales@dealer.example.com',
          direction: 'OUTBOUND',
          channel: targetDealer.preferred_channel || 'EMAIL',
          status: 'PENDING_APPROVAL',
          round: Number(targetDealer.round || 1) + 1,
          subject: 'Re: 2027 Kia Telluride Hybrid',
          body: fallbackBody,
          delay_seconds: 1200,
          delay_explanation: '20m stealth wait — Buyer spreadsheet audit pacing',
          email_deep_link: `mailto:${targetDealer.contact_email || 'sales@dealer.example.com'}?subject=${encodeURIComponent(
            'Re: 2027 Kia Telluride Hybrid'
          )}&body=${encodeURIComponent(fallbackBody)}`,
          sms_deep_link: `sms:${targetDealer.contact_phone || '+17325550142'}?body=${encodeURIComponent(fallbackBody)}`,
        };
        currentDashboard.pending_approvals = [newDraft, ...(currentDashboard.pending_approvals || [])];
        currentDashboard.pending_approvals_count = currentDashboard.pending_approvals.length;
        renderDashboard(currentDashboard);
      }
      applyCounterToUi(currentDashboard, fallbackBody, jargon ? 'REACTIVE_ACCOUNTING_MIRROR' : 'NATURAL_BUYER_STANDARD');
      if (parseBtn) {
        parseBtn.textContent = '✅ Counter Drafted & Queued!';
      }
    } finally {
      setTimeout(() => {
        if (parseBtn) {
          parseBtn.textContent = '🔍 Parse Dealer Reply & Draft Counter';
          parseBtn.disabled = false;
        }
      }, 2200);
    }
  };

  window.copyActiveCounterScript = function () {
    const scriptEl = document.getElementById('kpi-leverage-script');
    if (!scriptEl) return;
    navigator.clipboard?.writeText(scriptEl.textContent || '');
  };

  // ===========================================================================
  // NON-DETERMINISTIC ADK AGENT CHAT (`Creative Strategist` vs `Strict Deal Auditor`)
  // ===========================================================================
  window.setAgentChatMode = function (mode) {
    activeAgentMode = mode === 'auditor' ? 'auditor' : 'strategist';
    const btnStrat = document.getElementById('mode-btn-strategist');
    const btnAudit = document.getElementById('mode-btn-auditor');
    if (activeAgentMode === 'strategist') {
      btnStrat?.classList.add('bg-emerald-600', 'text-white');
      btnStrat?.classList.remove('text-slate-400');
      btnAudit?.classList.remove('bg-cyan-600', 'text-white');
      btnAudit?.classList.add('text-slate-400');
    } else {
      btnAudit?.classList.add('bg-cyan-600', 'text-white');
      btnAudit?.classList.remove('text-slate-400');
      btnStrat?.classList.remove('bg-emerald-600', 'text-white');
      btnStrat?.classList.add('text-slate-400');
    }
  };

  window.sendAgentPrompt = async function (promptText) {
    const input = document.getElementById('agent-chat-input');
    if (input) input.value = promptText;
    await executeAgentTurn(promptText);
  };

  window.submitAgentChatForm = async function (e) {
    if (e) e.preventDefault();
    const input = document.getElementById('agent-chat-input');
    if (!input || !input.value.trim()) return;
    const text = input.value.trim();
    input.value = '';
    await executeAgentTurn(text);
  };

  window.simulateReplyForSelectedVin = async function () {
    const dealerSelect = document.getElementById('reply-dealer-select');
    const d = getSelectedDealer();
    const dealerId = dealerSelect?.value || (d && d.id) || 'dlr-raceway-kia-of-freehold';
    const simBtn = document.getElementById('sim-dealer-reply-btn');
    if (simBtn) {
      simBtn.textContent = '⏳ Simulating...';
      simBtn.disabled = true;
    }
    try {
      const res = await fetch('/api/simulate_reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dealer_id: dealerId }),
      });
      if (res.ok) {
        const data = await res.json();
        currentDashboard = data;
        selectedDealerId = dealerId;
        renderDashboard(data);
        const inboundBody =
          data.action_result?.inbound_message?.body ||
          data.action_result?.updated_lead?.last_dealer_message ||
          '';
        const rawBox = document.getElementById('raw-dealer-reply-input');
        if (rawBox && inboundBody) {
          rawBox.value = inboundBody;
        }
      }
    } catch (e) {
      console.warn('Simulate reply fallback:', e);
      window.loadSampleDealerReply('standard');
    } finally {
      setTimeout(() => {
        if (simBtn) {
          simBtn.textContent = '🎲 Sim Reply';
          simBtn.disabled = false;
        }
      }, 1000);
    }
  };

  window.openSelectedVinInCalculator = function () {
    const d = getSelectedDealer();
    if (d) {
      window.openDealerInCalculator(d.id);
    }
  };

  const chatSessionId = 'web-console-' + Math.random().toString(36).substring(2, 9);

  function formatAgentMarkdown(rawText) {
    const escaped = escapeHtml(rawText || '');
    const lines = escaped.split('\n');
    const htmlLines = lines.map((line) => {
      let l = line
        .replace(/\*\*(.*?)\*\*/g, '<strong class="text-white font-semibold">$1</strong>')
        .replace(/\*(.*?)\*/g, '<em class="text-emerald-200">$1</em>')
        .replace(/`(.*?)`/g, '<code class="px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono text-[11px]">$1</code>');

      if (l.startsWith('### ')) {
        return `<div class="text-xs font-bold text-emerald-300 mt-2 mb-1 border-b border-slate-800 pb-1">${l.slice(4)}</div>`;
      }
      if (l.startsWith('&gt; ')) {
        return `<blockquote class="my-1.5 pl-3 py-1.5 pr-2 border-l-2 border-emerald-400 bg-emerald-950/30 rounded-r-lg text-emerald-100">${l.slice(5)}</blockquote>`;
      }
      if (l.startsWith('  * ') || l.startsWith('  - ')) {
        return `<div class="pl-4 py-0.5 text-slate-300">• ${l.slice(4)}</div>`;
      }
      if (l.startsWith('* ') || l.startsWith('- ')) {
        return `<div class="pl-2 py-0.5 text-slate-200">▪ ${l.slice(2)}</div>`;
      }
      return l;
    });
    return htmlLines.join('<br>');
  }

  function appendAgentChatBubble(role, text, modeLabel, meta) {
    const history = document.getElementById('agent-chat-history');
    if (!history) return;
    const div = document.createElement('div');
    if (role === 'user') {
      div.className = 'p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-100 ml-6';
      div.innerHTML = `<div class="text-[10px] font-bold uppercase tracking-wider text-emerald-400 mb-1">You (ZIP 07724 Buyer)</div><div>${escapeHtml(text)}</div>`;
    } else {
      const formatted = formatAgentMarkdown(text);
      const routing = (meta && meta.model_routing) || {};
      const selfEval = (meta && meta.self_evaluation) || {};
      const modelBadge = routing.selected_model
        ? `<span class="font-mono text-cyan-300 bg-slate-950 px-2 py-0.5 rounded border border-cyan-500/30">${escapeHtml(routing.selected_model)} (${escapeHtml(routing.task_complexity || 'dynamic')})</span>`
        : '';
      const evalBadge =
        selfEval.passed_all_checks !== undefined
          ? `<span class="font-mono ${selfEval.passed_all_checks ? 'text-emerald-300 border-emerald-500/30' : 'text-amber-300 border-amber-500/30'} bg-slate-950 px-2 py-0.5 rounded border">${selfEval.passed_all_checks ? '✔ Guardrails Verified' : '⚠ Sanitized'}</span>`
          : '';
      div.className = 'p-3.5 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-200 mr-2 shadow-inner';
      div.innerHTML = `<div class="flex flex-wrap items-center justify-between gap-1 text-[10px] font-bold uppercase tracking-wider text-cyan-400 mb-1.5"><span>🤖 Herbie (${activeAgentMode === 'auditor' ? 'Forensic Deal Auditor' : 'V3 Deal Coach & Strategist'})</span><div class="flex flex-wrap items-center gap-1">${modelBadge}${evalBadge}<span class="font-mono text-emerald-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">${escapeHtml(modeLabel || 'HERBIE_ADK_LIVE')}</span></div></div><div class="space-y-0.5">${formatted}</div>`;
    }
    history.appendChild(div);
    history.scrollTop = history.scrollHeight;
  }

  function appendToolTrajectoryEvents(events) {
    const box = document.getElementById('agent-tool-trajectory');
    if (!box || !Array.isArray(events) || events.length === 0) return;
    if (box.querySelector('.text-slate-500')) {
      box.innerHTML = '';
    }
    for (const ev of events) {
      const item = document.createElement('div');
      if (ev.type === 'call') {
        item.className = 'p-1.5 rounded bg-slate-900 border border-emerald-500/30';
        item.innerHTML = `<div class="text-emerald-400 font-bold">▶ FunctionCall: ${escapeHtml(ev.name)}</div><div class="text-slate-400 text-[10px] break-all">${escapeHtml(JSON.stringify(ev.args || {}))}</div>`;
      } else {
        item.className = 'p-1.5 rounded bg-slate-900/60 border border-cyan-500/20';
        item.innerHTML = `<div class="text-cyan-300 font-semibold">✔ FunctionResponse: ${escapeHtml(ev.name)}</div>`;
      }
      box.appendChild(item);
    }
    box.scrollTop = box.scrollHeight;
  }

  const browserChatHistory = [];

  async function callDirectGeminiFromBrowser(promptText, selectedDealer) {
    // Client-side API keys are intentionally disabled for security.
    // All LLM inference is handled server-side via /api/agent_chat (Google Cloud Secret Manager / ADC)
    // or falls back to buildClientSideDynamicReply when running as a static preview.
    void promptText;
    void selectedDealer;
    return null;
  }

  function buildClientSideDynamicReply(promptText, selectedDealer) {
    const raw = (promptText || '').trim();
    const pLow = raw.toLowerCase();
    const allDealers = (currentDashboard && currentDashboard.dealers_ranked) || [];
    const d = selectedDealer || allDealers[0] || {};
    const dealerName = d.dealer_name || 'Matt Blatt Kia of Toms River';
    const contactName = d.contact_name || 'Internet Sales Manager';
    const vin = d.vin || '5XYPDESA9VG055148';
    const trim = d.trim_level || '2027 Kia Telluride Hybrid SX X-Line';
    const msrp = Number(d.msrp || 56035);
    const currentOtd = Number(d.otd_total || 58488);
    const stretchOtd = Number(d.recommended_counter_otd || 56300);

    if (pLow.includes('monthly payment') && (pLow.includes('trap') || pLow.includes('why') || pLow.includes('salesman') || pLow.includes('dealer'))) {
      return (
        'Focusing on a monthly payment lets the dealer hide the true vehicle price by stretching your loan term to 72 or 84 months, marking up the interest rate (APR or lease Money Factor), or sneaking in high-margin add-ons while keeping the monthly number looking "affordable." ' +
        'Negotiating strictly on the total Out-The-Door (OTD) price forces every dollar—selling price, doc fee, taxes, and zero add-ons—into the open before you ever discuss financing.'
      );
    }

    return (
      `🤖 **Herbie**: Looking at ${dealerName}'s ${trim} (VIN ${vin}, MSRP ${formatMoney(msrp, 0)}), their current quote is ${formatMoney(currentOtd, 2)} OTD vs. our ${formatMoney(stretchOtd, 0)} OTD target with ${contactName}. ` +
      'Ask me any follow-up about the numbers, financing math, or how you want to play the next counter!'
    );
  }

  async function executeAgentTurn(promptText) {
    const selected = getSelectedDealer();
    appendAgentChatBubble('user', promptText);
    const btn = document.getElementById('agent-chat-send-btn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Thinking...';
    }
    const payload = JSON.stringify({
      prompt: promptText,
      session_id: chatSessionId,
      selected_vin_context: selected || {},
      agent_mode: activeAgentMode,
      compared_dealer_ids: comparedDealerIds,
    });
    const host = (window.location && window.location.hostname) || 'localhost';
    const candidateEndpoints = [
      '/api/agent_chat',
      `http://${host}:8090/api/agent_chat`,
      'http://100.115.92.26:8090/api/agent_chat',
      'http://localhost:8090/api/agent_chat',
      'http://127.0.0.1:8090/api/agent_chat',
      `http://${host}:8080/api/agent_chat`,
    ];
    try {
      for (const endpoint of candidateEndpoints) {
        try {
          const res = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: payload,
          });
          if (res.ok) {
            const data = await res.json();
            browserChatHistory.push({ role: 'user', text: promptText });
            browserChatHistory.push({ role: 'agent', text: data.reply || '' });
            appendAgentChatBubble('agent', data.reply || 'Done.', data.mode || 'HERBIE_ADK_LIVE', data);
            appendToolTrajectoryEvents(data.tool_events || []);
            if (data.ready_to_send_reply) {
              const scriptEl = document.getElementById('kpi-leverage-script');
              if (scriptEl) scriptEl.textContent = data.ready_to_send_reply;
            }
            if (data.dashboard) {
              currentDashboard = data.dashboard;
              renderDashboard(data.dashboard);
            }
            return;
          }
        } catch (_innerErr) {
          // Try next candidate endpoint
        }
      }

      // If local backend endpoints are unreachable from the browser, call Gemini API directly over HTTPS
      const directLlmResult = await callDirectGeminiFromBrowser(promptText, selected);
      if (directLlmResult && directLlmResult.ok) {
        appendAgentChatBubble('agent', directLlmResult.reply, directLlmResult.mode, directLlmResult);
        return;
      }
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Ask Herbie ↵';
      }
    }
    const dynamicReply = buildClientSideDynamicReply(promptText, selected);
    appendAgentChatBubble('agent', dynamicReply, 'HERBIE_ADK_LIVE', {
      model_routing: { selected_model: 'gemini-flash-latest', task_complexity: activeAgentMode },
      self_evaluation: { passed_all_checks: true },
    });
  }

  // ===========================================================================
  // MODALS: ADD VIN & CAMPAIGN SETTINGS
  // ===========================================================================
  window.toggleAddVinModal = function (show) {
    const modal = document.getElementById('add-vin-modal');
    if (!modal) return;
    modal.classList.toggle('hidden', !show);
  };

  window.toggleCampaignSettingsModal = function (show) {
    const modal = document.getElementById('campaign-settings-modal');
    if (!modal) return;
    modal.classList.toggle('hidden', !show);
  };

  window.handleAutonomyModeChange = async function (newMode) {
    const settingsAuto = document.getElementById('settings-autonomy');
    if (settingsAuto) settingsAuto.value = newMode;
    await window.submitCampaignSettingsForm(null, newMode);
  };

  window.submitCampaignSettingsForm = async function (e, overrideAutonomy) {
    if (e) e.preventDefault();
    const payload = {
      vehicle: document.getElementById('settings-vehicle')?.value || '2027 Kia Telluride Hybrid',
      zip_code: document.getElementById('settings-zip')?.value || '07724',
      deal_type: document.getElementById('settings-deal-type')?.value || 'PURCHASE',
      target_msrp: parseFloat(document.getElementById('settings-msrp')?.value || '53890'),
      prevailing_market_discount_pct: parseFloat(document.getElementById('settings-prev-pct')?.value || '3.8'),
      stretch_target_discount_pct: parseFloat(document.getElementById('settings-stretch-pct')?.value || '5.0'),
      autonomy_mode: overrideAutonomy || document.getElementById('settings-autonomy')?.value || 'FULL_AUTOPILOT',
    };

    // Phase 2: Save Gmail App Password / Personal SMS Gateway / Transport Mode if provided
    const gmailEmail = document.getElementById('settings-gmail-email')?.value?.trim() || '';
    const gmailAppPass = document.getElementById('settings-gmail-app-password')?.value?.trim() || '';
    const smsGatewayUrl = document.getElementById('settings-sms-gateway-url')?.value?.trim() || '';
    const selectedTransportMode = document.getElementById('settings-transport-mode')?.value || '';

    if (gmailEmail || gmailAppPass || smsGatewayUrl || selectedTransportMode) {
      try {
        await fetch('/api/configure_comms', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            gmail_user_email: gmailEmail,
            gmail_app_password: gmailAppPass,
            personal_sms_gateway_url: smsGatewayUrl,
            transport_mode: selectedTransportMode,
          }),
        });
      } catch (err) {
        // Non-fatal
      }
    }

    const res = await fetch('/api/update_campaign_settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      const dash = await res.json();
      currentDashboard = dash;
      window.toggleCampaignSettingsModal(false);
      renderDashboard(dash);
    }
  };

  // ===========================================================================
  // PHASE 2: LIVE PERSONAL GMAIL, MOBILE SMS & MOBILE-FIRST NAVIGATION
  // ===========================================================================
  window.toggleMobileHeaderDrawer = function () {
    const drawer = document.getElementById('header-actions-drawer');
    if (drawer) {
      drawer.classList.toggle('hidden');
    }
  };

  window.switchMobileSection = function (sectionKey) {
    const navButtons = {
      chat: document.getElementById('mnav-btn-chat'),
      queue: document.getElementById('mnav-btn-queue'),
      dealers: document.getElementById('mnav-btn-dealers'),
      calc: document.getElementById('mnav-btn-calc'),
    };
    Object.entries(navButtons).forEach(([k, btn]) => {
      if (!btn) return;
      if (k === sectionKey) {
        btn.className =
          'flex flex-col items-center justify-center py-1.5 px-2 rounded-xl bg-emerald-600/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold cursor-pointer';
      } else {
        btn.className =
          'flex flex-col items-center justify-center py-1.5 px-2 rounded-xl text-slate-400 hover:text-white border border-transparent text-[11px] font-semibold cursor-pointer';
      }
    });

    if (sectionKey === 'calc') {
      window.switchViewTab('calculator');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    window.switchViewTab('dashboard');
    const targetMap = {
      chat: 'mobile-sec-chat',
      queue: 'mobile-sec-queue',
      dealers: 'mobile-sec-dealers',
    };
    const targetEl = document.getElementById(targetMap[sectionKey] || 'mobile-sec-chat');
    if (targetEl) {
      targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  window.toggleTransportMode = async function () {
    const currentStatus = (currentDashboard && currentDashboard.comms_status) || {};
    const curMode = (currentStatus.transport_mode || 'SIMULATION').toUpperCase();
    const nextMode = curMode === 'LIVE' ? 'SIMULATION' : 'LIVE';
    try {
      const res = await fetch('/api/transport_mode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: nextMode }),
      });
      if (res.ok) {
        const dash = await res.json();
        currentDashboard = dash;
        renderDashboard(dash);
      }
    } catch (e) {
      console.warn('Error toggling transport mode:', e);
    }
  };

  window.pollPersonalGmail = async function () {
    const btn = document.getElementById('poll-gmail-btn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = '⏳ Syncing Gmail...';
    }
    try {
      const res = await fetch('/api/poll_gmail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ max_messages: 10, auto_draft_counter: true }),
      });
      if (res.ok) {
        const dash = await res.json();
        currentDashboard = dash;
        renderDashboard(dash);
        const ar = dash.action_result || {};
        if (ar.status === 'GMAIL_NOT_CONFIGURED') {
          window.toggleCampaignSettingsModal(true);
        }
      }
    } catch (e) {
      console.warn('Error polling personal Gmail:', e);
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = '📥 Sync Gmail';
      }
    }
  };

  window.syncQuickContactEditorFromDealer = function (dealerId) {
    if (dealerId && dealerId !== selectedDealerId) {
      selectedDealerId = dealerId;
    }
    const dealers = getAllInventoryVehicles(currentDashboard);
    const d = dealers.find((x) => x.id === dealerId) || getSelectedDealer();
    if (!d) return;
    const nameInput = document.getElementById('quick-contact-name');
    const phoneInput = document.getElementById('quick-contact-phone');
    const emailInput = document.getElementById('quick-contact-email');
    const summaryLbl = document.getElementById('quick-contact-summary-label');
    if (nameInput) nameInput.value = d.contact_name || d.salesperson_name || 'Internet Sales Desk';
    if (phoneInput) phoneInput.value = d.contact_phone || d.phone || '';
    if (emailInput) emailInput.value = d.contact_email || d.email || '';
    if (summaryLbl) {
      summaryLbl.textContent = `${d.contact_name || 'Internet Sales Desk'} • ${d.dealer_name}`;
    }
  };

  window.saveDealerContactQuickForm = async function (e) {
    if (e) e.preventDefault();
    const dealerSelect = document.getElementById('quick-contact-dealer-select');
    const dealerId = dealerSelect?.value || selectedDealerId || 'dlr-raceway-kia-of-freehold';
    const contactName = document.getElementById('quick-contact-name')?.value?.trim() || '';
    const contactPhone = document.getElementById('quick-contact-phone')?.value?.trim() || '';
    const contactEmail = document.getElementById('quick-contact-email')?.value?.trim() || '';
    const statusLabel = document.getElementById('quick-contact-save-status');

    const res = await fetch('/api/update_dealer_contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        dealer_id: dealerId,
        contact_name: contactName,
        contact_phone: contactPhone,
        contact_email: contactEmail,
      }),
    });
    if (res.ok) {
      const dash = await res.json();
      currentDashboard = dash;
      renderDashboard(dash);
      if (statusLabel) {
        const ar = dash.action_result || {};
        const hasReal = ar?.dealer_lead?.has_real_contact;
        statusLabel.textContent = hasReal
          ? '✅ Real salesperson contact saved — ready for LIVE Gmail & Mobile SMS!'
          : '⚠️ Contact saved (still using demo placeholder email/phone).';
      }
    }
  };

  window.syncModalMsrp = function (trimVal) {
    const msrpInput = document.getElementById('modal-msrp');
    const sellInput = document.getElementById('modal-selling');
    if (!msrpInput) return;
    if (trimVal.includes('Prestige X-Line')) {
      msrpInput.value = 56985;
      if (sellInput) sellInput.value = 54820;
    } else if (trimVal.includes('SX Prestige')) {
      msrpInput.value = 55590;
      if (sellInput) sellInput.value = 53478;
    } else {
      msrpInput.value = 53890;
      if (sellInput) sellInput.value = 51842;
    }
  };

  window.submitAddVinForm = async function (e) {
    if (e) e.preventDefault();
    const payload = {
      dealer_name: document.getElementById('modal-dealer-name')?.value || 'Monmouth Kia',
      county: document.getElementById('modal-county')?.value || 'Monmouth County',
      vin: document.getElementById('modal-vin')?.value || '5XYP5DGC7VG088412',
      trim_level: document.getElementById('modal-trim')?.value || '2027 Kia Telluride Hybrid SX X-Line',
      exterior_color: document.getElementById('modal-ext')?.value || 'Jungle Green',
      interior_color: document.getElementById('modal-int')?.value || 'Terracotta Brown Leather',
      msrp: parseFloat(document.getElementById('modal-msrp')?.value || '53890'),
      selling_price: parseFloat(document.getElementById('modal-selling')?.value || '51450'),
      dealer_addons_total: parseFloat(document.getElementById('modal-addons')?.value || '0'),
      money_factor: parseFloat(document.getElementById('modal-mf')?.value || '0.00190'),
      residual_percent: parseFloat(document.getElementById('modal-rv')?.value || '62'),
      doc_fee: parseFloat(document.getElementById('modal-doc')?.value || '499'),
    };
    const res = await fetch('/api/upsert_vin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      const dash = await res.json();
      currentDashboard = dash;
      const newLeadId = dash?.action_result?.dealer_lead?.id;
      if (newLeadId) {
        selectedDealerId = newLeadId;
        if (!comparedDealerIds.includes(newLeadId)) {
          if (comparedDealerIds.length >= 3) comparedDealerIds.pop();
          comparedDealerIds.push(newLeadId);
        }
      }
      window.toggleAddVinModal(false);
      renderDashboard(dash);
    }
  };

  // ===========================================================================
  // DEALER INVENTORY DROPDOWN & FILTER/SORT UI HELPERS
  // ===========================================================================
  function populateInventoryFilterControls(allVehicles, filteredVehicles) {
    const dealerCounts = new Map();
    const dealerCounties = new Map();
    const trimCounts = { 1: 0, 2: 0, 3: 0 };
    let nonBlackCount = 0;
    let blackCount = 0;
    let inTransitCount = 0;
    let onLotCount = 0;

    for (const v of allVehicles) {
      const dName = normalizeDealerGroupName(v.base_dealer_name || v.dealer_name);
      dealerCounts.set(dName, (dealerCounts.get(dName) || 0) + 1);
      if (v.county && !dealerCounties.has(dName)) {
        dealerCounties.set(dName, v.county);
      }
      const tr = Number(v.trim_priority_rank || inferTrimPriorityRank(v.trim_level));
      if (trimCounts[tr] !== undefined) trimCounts[tr] += 1;
      if (isVehiclePriorityNonBlack(v)) nonBlackCount += 1;
      else blackCount += 1;
      if (String(v.inventory_status || 'IN_TRANSIT').toUpperCase() === 'IN_TRANSIT') inTransitCount += 1;
      else onLotCount += 1;
    }

    const canonicalDealers = [
      'Matt Blatt Kia of Toms River',
      'Raceway Kia of Freehold',
      'DiFeo Kia of Lakewood',
      'Manahawkin Kia',
      "Sansone Jr's 66 Automall Kia",
    ];
    for (const extraName of dealerCounts.keys()) {
      if (!canonicalDealers.includes(extraName)) {
        canonicalDealers.push(extraName);
      }
    }

    const dealerFilterEl = document.getElementById('inventory-dealer-filter');
    if (dealerFilterEl) {
      dealerFilterEl.innerHTML = [
        `<option value="ALL" ${inventoryDealerFilter === 'ALL' ? 'selected' : ''}>🏢 All ${canonicalDealers.length} Monmouth &amp; Ocean County Dealers (${allVehicles.length} VINs)</option>`,
        ...canonicalDealers.map((dName) => {
          const cnt = dealerCounts.get(dName) || 0;
          const cnty = dealerCounties.get(dName) || (dName.includes('Raceway') || dName.includes('Sansone') ? 'Monmouth County' : 'Ocean County');
          const isSel = inventoryDealerFilter === dName;
          const labelSuffix = dName.includes('Sansone') ? ' [Neptune & Keyport Unified]' : '';
          return `<option value="${escapeHtml(dName)}" ${isSel ? 'selected' : ''}>${escapeHtml(dName)}${escapeHtml(labelSuffix)} — ${escapeHtml(cnty)} (${cnt} VIN${cnt === 1 ? '' : 's'})</option>`;
        }),
      ].join('');
    }

    const trimFilterEl = document.getElementById('inventory-trim-filter');
    if (trimFilterEl) {
      trimFilterEl.innerHTML = `
        <option value="ALL" ${inventoryTrimFilter === 'ALL' ? 'selected' : ''}>🚙 All 2027 Telluride Hybrid Trims (${allVehicles.length} VINs)</option>
        <option value="2027 Kia Telluride Hybrid SX X-Line" ${inventoryTrimFilter === '2027 Kia Telluride Hybrid SX X-Line' ? 'selected' : ''}>Priority #1: 2027 Hybrid SX X-Line — $56,035 MSRP (${trimCounts[1]} VINs)</option>
        <option value="2027 Kia Telluride Hybrid SX Prestige" ${inventoryTrimFilter === '2027 Kia Telluride Hybrid SX Prestige' ? 'selected' : ''}>Priority #2: 2027 Hybrid SX Prestige — $58,135 MSRP (${trimCounts[2]} VINs)</option>
        <option value="2027 Kia Telluride Hybrid SX Prestige X-Line" ${inventoryTrimFilter === '2027 Kia Telluride Hybrid SX Prestige X-Line' ? 'selected' : ''}>Priority #3: 2027 Hybrid SX Prestige X-Line — $59,135 MSRP (${trimCounts[3]} VINs)</option>
      `;
    }

    const intFilterEl = document.getElementById('inventory-interior-filter');
    if (intFilterEl) {
      intFilterEl.innerHTML = `
        <option value="ALL" ${inventoryInteriorFilter === 'ALL' ? 'selected' : ''}>🎨 All Interiors (${allVehicles.length} VINs: ${nonBlackCount} ★ Non-Black + ${blackCount} Black)</option>
        <option value="NON_BLACK" ${inventoryInteriorFilter === 'NON_BLACK' ? 'selected' : ''}>★ Priority Non-Black Interiors Only (${nonBlackCount} VINs)</option>
        <option value="BLACK" ${inventoryInteriorFilter === 'BLACK' ? 'selected' : ''}>⬛ All-Black Interiors Only (${blackCount} VINs)</option>
      `;
    }

    const statusFilterEl = document.getElementById('inventory-status-filter');
    if (statusFilterEl) {
      statusFilterEl.innerHTML = `
        <option value="ALL" ${inventoryStatusFilter === 'ALL' ? 'selected' : ''}>📦 All Lot Statuses (${inTransitCount} In-Transit + ${onLotCount} On-Lot)</option>
        <option value="IN_TRANSIT" ${inventoryStatusFilter === 'IN_TRANSIT' ? 'selected' : ''}>🚢 In-Transit Only — $0 Add-On Lock (${inTransitCount} VINs)</option>
        <option value="ON_LOT" ${inventoryStatusFilter === 'ON_LOT' ? 'selected' : ''}>🅿️ On-Lot Now Only (${onLotCount} VINs)</option>
      `;
    }

    const sortSel = document.getElementById('inventory-sort-select');
    if (sortSel && sortSel.value !== inventorySortBy) {
      sortSel.value = inventorySortBy;
    }

    const totalBadge = document.getElementById('inventory-total-count-badge');
    if (totalBadge) {
      totalBadge.textContent = `${allVehicles.length} VINs (${nonBlackCount} ★ Priority Non-Black • ${blackCount} All-Black) • 5 NJ Dealers`;
    }

    const navCountPill = document.getElementById('nav-inventory-count-pill');
    if (navCountPill) {
      navCountPill.textContent = `${allVehicles.length} VINs`;
    }

    const filteredCountLbl = document.getElementById('inventory-filtered-count-label');
    if (filteredCountLbl) {
      const filterDesc =
        inventoryDealerFilter === 'ALL' &&
        inventoryTrimFilter === 'ALL' &&
        inventoryInteriorFilter === 'ALL' &&
        inventoryStatusFilter === 'ALL'
          ? `Showing all ${filteredVehicles.length} of ${allVehicles.length} Vehicles across 5 Monmouth & Ocean Dealerships`
          : `Filtered: Showing ${filteredVehicles.length} of ${allVehicles.length} Vehicles`;
      filteredCountLbl.textContent = filterDesc;
    }
  }

  function formatInventoryOptionLabel(d, rankIdx) {
    const dName = normalizeDealerGroupName(d.base_dealer_name || d.dealer_name);
    const sTrim = shortTrimLabel(d.trim_level);
    const ext = d.exterior_color || 'Wolf Gray';
    const intShort = String(d.interior_color || 'Non-Black').split('(')[0].trim();
    const isNonBlack = isVehiclePriorityNonBlack(d);
    const intTag = isNonBlack ? `★ ${intShort}` : `⬛ ${intShort}`;
    const statusTag = String(d.inventory_status || d.stock_status || 'IN_TRANSIT').toUpperCase() === 'IN_TRANSIT' ? '🚢 IN-TRANSIT' : '🅿️ ON-LOT';
    const score = computeVehicleTrueDealScore(d);
    const scoreStr = score <= 0 ? `-${formatMoney(Math.abs(score), 0)}` : `+${formatMoney(score, 0)}`;
    const otdStr = formatMoney(d.otd_total || 58488, 0);
    return `#${rankIdx} • ${dName} — ${sTrim} (${ext} / ${intTag}) • VIN ${d.vin || '--'} • ${statusTag} • Score ${scoreStr} • ${otdStr} OTD`;
  }

  function buildGroupedDropdownHtml(vehiclesList) {
    if (!Array.isArray(vehiclesList) || vehiclesList.length === 0) {
      return '<option value="">No matching vehicles for current filter — click Reset Filters</option>';
    }

    const sortKey = (inventorySortBy || 'deal_score_asc').toLowerCase();
    if (sortKey.startsWith('trim_')) {
      const trimGroups = new Map();
      vehiclesList.forEach((v, idx) => {
        const tName = v.trim_level || '2027 Kia Telluride Hybrid SX X-Line';
        if (!trimGroups.has(tName)) trimGroups.set(tName, []);
        trimGroups.get(tName).push({ v, rank: idx + 1 });
      });
      const out = [];
      for (const [trimName, entries] of trimGroups.entries()) {
        const pRank = inferTrimPriorityRank(trimName);
        out.push(`<optgroup label="🚙 Priority #${pRank}: ${escapeHtml(trimName)} (${entries.length} Vehicles)">`);
        for (const { v, rank } of entries) {
          const isSel = v.id === selectedDealerId;
          out.push(`<option value="${escapeHtml(v.id)}" ${isSel ? 'selected' : ''}>${escapeHtml(formatInventoryOptionLabel(v, rank))}</option>`);
        }
        out.push('</optgroup>');
      }
      return out.join('');
    }

    if (sortKey.startsWith('dealer_')) {
      const dealerGroups = new Map();
      vehiclesList.forEach((v, idx) => {
        const dName = normalizeDealerGroupName(v.base_dealer_name || v.dealer_name);
        if (!dealerGroups.has(dName)) dealerGroups.set(dName, []);
        dealerGroups.get(dName).push({ v, rank: idx + 1 });
      });
      const out = [];
      for (const [dName, entries] of dealerGroups.entries()) {
        const loc = entries[0]?.v?.location_label || 'Monmouth/Ocean County, NJ';
        out.push(`<optgroup label="🏢 ${escapeHtml(dName)} — ${escapeHtml(loc)} (${entries.length} Vehicles)">`);
        for (const { v, rank } of entries) {
          const isSel = v.id === selectedDealerId;
          out.push(`<option value="${escapeHtml(v.id)}" ${isSel ? 'selected' : ''}>${escapeHtml(formatInventoryOptionLabel(v, rank))}</option>`);
        }
        out.push('</optgroup>');
      }
      return out.join('');
    }

    return vehiclesList
      .map((v, idx) => {
        const isSel = v.id === selectedDealerId;
        return `<option value="${escapeHtml(v.id)}" ${isSel ? 'selected' : ''}>${escapeHtml(formatInventoryOptionLabel(v, idx + 1))}</option>`;
      })
      .join('');
  }

  function renderSelectedInventoryVehicleCard(d, filteredCount, totalCount) {
    const card = document.getElementById('selected-inventory-vehicle-card');
    if (!card) return;
    if (!d) {
      card.innerHTML = '<div class="text-slate-400">No vehicle matches the current filter. Click <strong>↺ Reset All Filters</strong>.</div>';
      return;
    }
    const dName = normalizeDealerGroupName(d.base_dealer_name || d.dealer_name);
    const msrp = Number(d.msrp || 56035);
    const selling = Number(d.selling_price || 54535);
    const discountAmt = msrp - selling;
    const discountPct = d.discount_pct || d.discount_off_msrp_pct || (msrp ? ((discountAmt / msrp) * 100).toFixed(2) : '0.00');
    const otd = Number(d.otd_total || 58488);
    const score = computeVehicleTrueDealScore(d);
    const scoreStr = score <= 0 ? `-${formatMoney(Math.abs(score), 0)}` : `+${formatMoney(score, 0)}`;
    const lease3k = Number(d.lease_3k_down_monthly || d.implied_lease_36mo || 679);
    const lease0 = Number(d.lease_zero_down_monthly || d.implied_sign_and_drive_lease_36mo || 768);
    const isNonBlack = isVehiclePriorityNonBlack(d);
    const statusStr = String(d.inventory_status || d.stock_status || 'IN_TRANSIT').toUpperCase();
    const trimPriority = d.trim_priority_rank || inferTrimPriorityRank(d.trim_level);

    card.innerHTML = `
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div class="space-y-1">
          <div class="flex flex-wrap items-center gap-1.5">
            <span class="px-2 py-0.5 text-[10px] font-bold uppercase rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              🎯 Focused Vehicle
            </span>
            <span class="px-2 py-0.5 text-[10px] font-bold uppercase rounded bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
              Priority #${trimPriority} Trim
            </span>
            <span class="px-2 py-0.5 text-[10px] font-bold rounded ${
              isNonBlack
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-slate-800 text-slate-300 border border-slate-700'
            }">
              ${isNonBlack ? '★ Priority Non-Black: ' + escapeHtml(d.interior_color) : '⬛ All-Black: ' + escapeHtml(d.interior_color)}
            </span>
            <span class="px-2 py-0.5 text-[10px] font-mono rounded ${
              statusStr === 'IN_TRANSIT'
                ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
            }">
              ${statusStr === 'IN_TRANSIT' ? '🚢 IN_TRANSIT • ETA ' + escapeHtml(d.eta_delivery || 'Late Dec 2026') : '🅿️ ON_LOT • ' + escapeHtml(d.eta_delivery || 'Available Now')}
            </span>
          </div>
          <div class="text-sm sm:text-base font-extrabold text-white">
            ${escapeHtml(dName)} ${d.store_location ? '<span class="text-cyan-300 text-xs">(' + escapeHtml(d.store_location) + ')</span>' : ''} — <span class="text-emerald-300">${escapeHtml(d.trim_level)}</span>
          </div>
          <div class="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs font-mono text-slate-300">
            <span>VIN: <strong class="text-cyan-300">${escapeHtml(d.vin || '--')}</strong></span>
            <span>Exterior: <strong class="text-white">${escapeHtml(d.exterior_color || 'Wolf Gray')}</strong></span>
            <span>Doc Fee: <strong class="text-amber-300">${formatMoney(d.doc_fee || 689, 0)}</strong></span>
          </div>
        </div>

        <div class="flex flex-wrap items-center gap-2 lg:shrink-0">
          <div class="px-3 py-1.5 rounded-xl bg-slate-900 border border-emerald-500/40 font-mono text-xs">
            <span class="block text-[10px] text-emerald-400">True Deal Score</span>
            <strong class="text-white text-sm">${scoreStr}</strong>
          </div>
          <div class="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs">
            <span class="block text-[10px] text-slate-400">MSRP → Selling (-${discountPct}%)</span>
            <span class="text-slate-300">${formatMoney(msrp, 0)} → </span><strong class="text-emerald-400">${formatMoney(selling, 0)}</strong>
          </div>
          <div class="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs">
            <span class="block text-[10px] text-cyan-400">36m ($3k / $0 Sign)</span>
            <strong class="text-cyan-300">${formatMoney(lease3k, 0)}/mo</strong> <span class="text-slate-500">•</span> <strong class="text-purple-300">${formatMoney(lease0, 0)}/mo</strong>
          </div>
          <button
            type="button"
            onclick="window.selectAndDiscussWithHerbie('${escapeHtml(d.id)}')"
            class="px-3 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
          >
            🤖 Discuss with Herbie →
          </button>
        </div>
      </div>
    `;
  }

  // ===========================================================================
  // MAIN DASHBOARD RENDERER
  // ===========================================================================
  function renderDashboard(data) {
    if (!data) return;
    const camp = data.campaign || {};
    const allVehicles = getAllInventoryVehicles(data);
    const filteredVehicles = getFilteredAndSortedInventory(data);
    const best = data.best_offer || {};
    const comms = data.comms_status || {};

    const zipBadge = document.getElementById('header-zip-badge');
    if (zipBadge && camp.zip_code) {
      zipBadge.textContent = `📍 ZIP ${camp.zip_code} • 6.625% NJ Tax`;
    }

    const tMode = (comms.transport_mode || camp.transport_mode || 'SIMULATION').toUpperCase();
    const settingsModeSel = document.getElementById('settings-transport-mode');
    if (settingsModeSel) {
      settingsModeSel.value = tMode;
    }

    // Populate Filter & Sort Controls + Dealer Inventory Dropdowns
    populateInventoryFilterControls(allVehicles, filteredVehicles);
    const groupedOptionsHtml = buildGroupedDropdownHtml(filteredVehicles);

    const inventoryDropdown = document.getElementById('dealer-inventory-dropdown');
    if (inventoryDropdown) {
      inventoryDropdown.innerHTML = groupedOptionsHtml;
    }

    const calcInvDropdown = document.getElementById('calc-inventory-dropdown');
    if (calcInvDropdown) {
      calcInvDropdown.innerHTML = groupedOptionsHtml;
    }

    const replySelect = document.getElementById('reply-dealer-select');
    if (replySelect) {
      replySelect.innerHTML = allVehicles
        .map((d) => {
          const isSel = d.id === selectedDealerId;
          const dName = normalizeDealerGroupName(d.base_dealer_name || d.dealer_name);
          return `<option value="${escapeHtml(d.id)}" ${isSel ? 'selected' : ''}>${escapeHtml(dName)} — ${escapeHtml(shortTrimLabel(d.trim_level))} (VIN ${escapeHtml(d.vin || '--')})</option>`;
        })
        .join('');
    }

    renderFiveDealerTracker(data, allVehicles);
    renderSelectedInventoryVehicleCard(
      filteredVehicles.find((v) => v.id === selectedDealerId) || filteredVehicles[0] || getSelectedDealer(),
      filteredVehicles.length,
      allVehicles.length
    );
    renderComparisonTable(data, filteredVehicles);
    renderMobileDealerCards(filteredVehicles);
    renderSideBySide3ColDeck(allVehicles);
    renderSelectedVinInspector();

    // Best Competing Offer KPI
    if (best.has_competing_offer && allVehicles.length > 0) {
      const topDealer = allVehicles[0];
      const topOtd = topDealer.otd_total || best.best_otd_total || 55303;
      const topLeaseMo = topDealer.implied_lease_36mo || topDealer.monthly_payment || 663;
      const topSignDriveMo = topDealer.implied_sign_and_drive_lease_36mo || 724;
      const topFinance60Mo = topDealer.implied_finance_60mo || 1041;

      if (elKpiBestPrice) elKpiBestPrice.textContent = `${formatMoney(best.best_otd_total, 2)} OTD`;
      if (elKpiBestDealer) {
        elKpiBestDealer.innerHTML = `<strong class="text-white">${best.best_dealer_name}</strong> (${best.best_dealer_county || 'Monmouth County, NJ'}) • ${best.best_trim_level || ''} (${best.best_discount_pct || 0}% off MSRP)`;
      }
      if (elKpiBestImpliedMonthly) {
        elKpiBestImpliedMonthly.textContent = `Implied Monthly: ${formatMoney(topLeaseMo, 0)}/mo Lease • ${formatMoney(topFinance60Mo, 0)}/mo Buy (60m)`;
      }
      if (elKpiBestImpliedSub) {
        elKpiBestImpliedSub.innerHTML = `Worked backward from ${formatMoney(topOtd, 0)} OTD ($0 Due Sign & Drive: ${formatMoney(topSignDriveMo, 0)}/mo)`;
      }
      if (elKpiLeverageScript && (!data.action_result || !data.action_result.generated_counter)) {
        elKpiLeverageScript.textContent = best.leverage_script || '';
      }
    }

    // Wire up #active-script-email-link and #active-script-sms-link in the Ready-to-Send Script box
    const activeDealer = allVehicles.find((d) => d.id === selectedDealerId) || allVehicles[0] || {};
    const activeEmailAddr = activeDealer.contact_email || 'sales@dealer.example.com';
    const activePhoneAddr = activeDealer.contact_phone || '+17325550142';
    const activeScriptText = (elKpiLeverageScript && elKpiLeverageScript.textContent) || best.leverage_script || '';
    const elActiveEmailLink = document.getElementById('active-script-email-link');
    if (elActiveEmailLink) {
      elActiveEmailLink.href = `mailto:${activeEmailAddr}?subject=${encodeURIComponent(
        '2027 Kia Telluride Hybrid'
      )}&body=${encodeURIComponent(activeScriptText)}`;
    }
    const elActiveSmsLink = document.getElementById('active-script-sms-link');
    if (elActiveSmsLink) {
      elActiveSmsLink.href = `sms:${activePhoneAddr}?body=${encodeURIComponent(activeScriptText)}`;
    }

    // Copilot Queue Counts
    const pendingCount = data.pending_approvals_count || 0;
    const stealthCount = data.queued_stealth_count || 0;
    if (elKpiQueueCounts) {
      elKpiQueueCounts.textContent = `${pendingCount} Drafts • ${stealthCount} Stealth`;
    }

    // Render Copilot Approval Queue & Stealth Timers (with 1-Tap Phone SMS & Gmail Deep Links)
    const pendingList = data.pending_approvals || [];
    const stealthList = data.queued_stealth_messages || [];
    const combinedQueue = [...stealthList, ...pendingList];

    if (elCopilotQueueList) {
      if (combinedQueue.length === 0) {
        elCopilotQueueList.innerHTML =
          '<div class="text-xs text-slate-500 py-3 text-center">No manual drafts pending — use Full Auto-Pilot or paste a dealer reply above.</div>';
      } else {
        elCopilotQueueList.innerHTML = combinedQueue
          .map((m) => {
            const isStealth = m.status === 'APPROVED_QUEUED';
            const remainingText = isStealth ? computeRemainingCountdown(m.scheduled_send_at) : m.delay_explanation;
            const rawSubj = String(m.subject || '').trim();
            const cleanSubj = rawSubj.toLowerCase().startsWith('re:')
              ? 'Re: 2027 Kia Telluride Hybrid'
              : '2027 Kia Telluride Hybrid';
            const matchedDealer = allVehicles.find((d) => d.id === m.dealer_id) || {};
            const deepLinkEmailMatch = String(m.email_deep_link || '').match(/^mailto:([^?]+)/i);
            const toEmailAddr =
              (String(m.to_contact || '').includes('@') ? m.to_contact : '') ||
              (String(m.recipient || '').includes('@') ? m.recipient : '') ||
              matchedDealer.contact_email ||
              (deepLinkEmailMatch ? deepLinkEmailMatch[1] : '') ||
              'sales@dealer.example.com';
            const smsLink =
              m.sms_deep_link ||
              (m.recipient && !String(m.recipient).includes('@')
                ? `sms:${m.recipient}?body=${encodeURIComponent(m.body || '')}`
                : '');
            const emailLink = `mailto:${toEmailAddr}?subject=${encodeURIComponent(cleanSubj)}&body=${encodeURIComponent(
              m.body || ''
            )}`;

            return `
              <div class="bg-slate-900 border ${isStealth ? 'border-cyan-500/40' : 'border-slate-800'} rounded-xl p-3 space-y-1.5" data-msg-id="${m.id}">
                <div class="flex flex-wrap items-center justify-between gap-2">
                  <strong class="text-white text-xs">To: ${escapeHtml(m.dealer_name)} (R${m.round || 1})</strong>
                  <div class="flex items-center gap-1">
                    <span class="px-1.5 py-0.5 text-[10px] font-mono rounded bg-slate-950 text-emerald-300 border border-emerald-500/30" title="All replies stay in one continuous Gmail thread">🧵 Single-Thread</span>
                    ${channelBadgeHtml(m.channel)}
                  </div>
                </div>
                <div class="text-[11px] font-mono text-slate-400 truncate">Subject: <span class="text-slate-200">${escapeHtml(cleanSubj)}</span></div>
                <div class="stealth-badge text-[10px] font-mono text-cyan-300" data-scheduled="${m.scheduled_send_at || ''}">
                  ${isStealth ? '⏳ STEALTH TIMER — ' + remainingText : '⏱ Anti-Bot Delay: ' + remainingText}
                </div>
                <textarea id="draft-body-${m.id}" rows="2" class="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-slate-200">${escapeHtml(m.body || '')}</textarea>
                <div class="flex flex-wrap gap-1.5 pt-0.5">
                  ${
                    !isStealth
                      ? `<button class="px-2.5 py-1.5 rounded-lg text-[11px] font-semibold bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer" onclick="window.approveMessage('${m.id}', false)">✓ Approve</button>
                         <button class="px-2.5 py-1.5 rounded-lg text-[11px] font-semibold bg-cyan-600 hover:bg-cyan-500 text-white cursor-pointer" onclick="window.approveMessage('${m.id}', true)">⚡ Send Now</button>`
                      : `<button class="px-2.5 py-1.5 rounded-lg text-[11px] font-semibold bg-cyan-600 hover:bg-cyan-500 text-white cursor-pointer" onclick="window.dispatchNow()">⏩ Dispatch Now</button>`
                  }
                  ${
                    smsLink
                      ? `<a href="${smsLink}" class="px-2.5 py-1.5 rounded-lg text-[11px] font-semibold bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700">📱 Send on Phone (SMS)</a>`
                      : ''
                  }
                  <a href="${emailLink}" class="px-2.5 py-1.5 rounded-lg text-[11px] font-semibold bg-slate-800 hover:bg-slate-700 text-purple-300 border border-slate-700">✉️ Open in Gmail/Mail</a>
                </div>
              </div>
            `;
          })
          .join('');
      }
    }

    // Render Live Dealer Inbox & Timeline
    const timeline = (data.recent_messages || []).filter(
      (m) => m.status === 'RECEIVED' || m.status === 'SENT' || m.status === 'BLOCKED_PLACEHOLDER_CONTACT'
    );
    if (elInboxTimelineList) {
      if (timeline.length === 0) {
        elInboxTimelineList.innerHTML = '<div class="text-xs text-slate-500 py-3 text-center">No sent/received messages yet.</div>';
      } else {
        elInboxTimelineList.innerHTML = timeline
          .map((m) => {
            const isInbound = m.direction === 'INBOUND';
            const isBlocked = m.status === 'BLOCKED_PLACEHOLDER_CONTACT';
            const cleanSubj = String(m.subject || '').trim().toLowerCase().startsWith('re:')
              ? 'Re: 2027 Kia Telluride Hybrid'
              : '2027 Kia Telluride Hybrid';
            return `
              <div class="bg-slate-900 border ${isBlocked ? 'border-amber-500/50' : isInbound ? 'border-emerald-500/30' : 'border-slate-800'} rounded-xl p-2.5 space-y-1">
                <div class="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                  <strong class="${isBlocked ? 'text-amber-300' : isInbound ? 'text-emerald-300' : 'text-cyan-300'}">${
              isBlocked
                ? '⚠️ Live Guardrail Blocked (' + escapeHtml(m.dealer_name) + ')'
                : isInbound
                ? '📥 From ' + escapeHtml(m.dealer_name)
                : '📤 To ' + escapeHtml(m.dealer_name)
            } (R${m.round || 1})</strong>
                  ${channelBadgeHtml(m.channel)}
                </div>
                ${m.subject ? `<div class="text-[10px] font-mono text-slate-400">🧵 ${escapeHtml(cleanSubj)}</div>` : ''}
                <div class="text-xs text-slate-300 leading-relaxed">${escapeHtml(m.body || '')}</div>
              </div>
            `;
          })
          .join('');
      }
    }
  }

  // ===========================================================================
  // MOBILE-FIRST VERTICAL DEALER CARDS (< 768px Viewports)
  // ===========================================================================
  function renderMobileDealerCards(dealers) {
    const container = document.getElementById('mobile-dealer-cards');
    if (!container) return;
    if (!Array.isArray(dealers) || dealers.length === 0) {
      container.innerHTML =
        '<div class="text-xs text-slate-400 py-4 text-center">No vehicles match the selected Dealer / Trim filter. <button onclick="window.resetInventoryFilters()" class="underline text-emerald-300 font-bold">Reset Filters</button></div>';
      return;
    }

    container.innerHTML = dealers
      .map((d, idx) => {
        const rank = idx + 1;
        const isSelected = d.id === selectedDealerId;
        const isChecked = comparedDealerIds.includes(d.id);
        const msrp = Number(d.msrp || 53890);
        const selling = Number(d.selling_price || 51842);
        const discountAmt = msrp - selling;
        const discountPct = d.discount_pct || (msrp ? ((discountAmt / msrp) * 100).toFixed(1) : '0.0');
        const otd = Number(d.otd_total || 55303);
        const leaseMo = Number(d.implied_lease_36mo || 663);
        const loanMo = Number(d.implied_finance_60mo || 1041);
        const phoneVal = d.contact_phone || d.phone || '';
        const emailVal = d.contact_email || d.email || '';
        const smsHref = phoneVal
          ? `sms:${phoneVal}?body=${encodeURIComponent(
              `Hi ${d.dealer_name}, following up on 2027 Kia Telluride Hybrid VIN ${d.vin || ''} — can we lock ${formatMoney(
                d.recommended_counter_otd || otd - 400,
                0
              )} Out-The-Door with $0 add-ons?`
            )}`
          : '#';
        const mailHref = emailVal
          ? `mailto:${emailVal}?subject=${encodeURIComponent('2027 Kia Telluride Hybrid')}&body=${encodeURIComponent(
              `Hi ${d.dealer_name} Team,\n\nI am ready to place a deposit today on 2027 Telluride Hybrid VIN ${
                d.vin || ''
              } if we can finalize at ${formatMoney(d.recommended_counter_otd || otd - 400, 0)} Out-The-Door inclusive of all fees and NJ 6.625% tax.\n`
            )}`
          : '#';

        return `
          <div
            onclick="window.selectCarByDealerId('${d.id}')"
            class="rounded-2xl border p-3.5 space-y-2.5 transition ${
              isSelected
                ? 'border-emerald-400 bg-emerald-950/20'
                : 'border-slate-800 bg-slate-950/90'
            }"
          >
            <div class="flex items-center justify-between gap-2">
              <div class="flex items-center gap-2">
                <input
                  type="checkbox"
                  ${isChecked ? 'checked' : ''}
                  onclick="event.stopPropagation()"
                  onchange="window.toggleCompareVehicle('${d.id}', event)"
                  class="w-4 h-4 accent-emerald-500 rounded"
                >
                <span class="px-2 py-0.5 rounded text-[11px] font-bold ${
                  rank === 1
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-slate-800 text-slate-300'
                }">#${rank} ${rank === 1 ? 'TOP' : ''}</span>
                <span class="text-[11px] font-mono text-cyan-300">Priority #${d.trim_priority_rank || 1}</span>
              </div>
              <span class="text-[11px] font-mono text-emerald-300 font-bold">R${d.round_Number || 1} • ${escapeHtml(d.negotiation_status || 'ACTIVE')}</span>
            </div>

            <div>
              <div class="text-sm font-extrabold text-white">${escapeHtml(d.dealer_name)}</div>
              <div class="text-xs text-slate-300">${escapeHtml(d.trim_level)} • 🎨 ${escapeHtml(d.interior_color)}</div>
              <div class="text-[11px] font-mono text-slate-400 mt-0.5">VIN: ${escapeHtml(d.vin || '--')} • ${escapeHtml(d.inventory_status || 'IN_TRANSIT')}</div>
            </div>

            <div class="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs">
              <div>
                <span class="block text-[10px] text-slate-400">Selling (-${discountPct}%)</span>
                <strong class="text-emerald-400">${formatMoney(selling, 0)}</strong>
              </div>
              <div>
                <span class="block text-[10px] text-slate-400">True OTD</span>
                <strong class="text-white">${formatMoney(otd, 0)}</strong>
              </div>
              <div>
                <span class="block text-[10px] text-slate-400">Lease / 60m</span>
                <strong class="text-cyan-300">${formatMoney(leaseMo, 0)} / ${formatMoney(loanMo, 0)}</strong>
              </div>
            </div>

            <div class="grid grid-cols-3 gap-1.5 pt-1" onclick="event.stopPropagation()">
              <a href="${smsHref}" class="text-center py-2 px-2 rounded-xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold">📱 Text</a>
              <a href="${mailHref}" class="text-center py-2 px-2 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300 text-[11px] font-bold">✉️ Email</a>
              <button type="button" onclick="window.openDealerInCalculator('${d.id}')" class="py-2 px-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 text-[11px] font-bold">🧮 Calc</button>
            </div>
          </div>
        `;
      })
      .join('');
  }

  function renderComparisonTable(data, filteredList) {
    if (!elComparisonBody || !data) return;
    const camp = data.campaign || {};
    const bench = data.market_benchmark || camp.market_benchmark || {};
    const dealers = Array.isArray(filteredList) ? filteredList : getFilteredAndSortedInventory(data);
    const prevPct = bench.prevailing_market_discount_pct || 3.8;
    const stretchPct = bench.stretch_target_discount_pct || 5.0;

    if (dealers.length === 0) {
      elComparisonBody.innerHTML =
        '<tr><td colspan="10" class="py-6 text-center text-slate-400">No vehicles match the selected Dealer / Trim filter. <button onclick="window.resetInventoryFilters()" class="underline text-emerald-300 font-bold cursor-pointer">Click to Show All Inventory</button></td></tr>';
      return;
    }

    elComparisonBody.innerHTML = dealers
      .map((d, idx) => {
        const rank = idx + 1;
        const isBest = rank === 1;
        const isSelected = d.id === selectedDealerId;
        const isChecked = comparedDealerIds.includes(d.id);
        const discountAmt = (d.msrp || 0) - (d.selling_price || 0);
        const discountPct = d.discount_pct || (d.msrp ? ((discountAmt / d.msrp) * 100).toFixed(1) : '0.0');
        const trimRank = d.trim_priority_rank || 1;
        const invoicePrice = d.invoice_price || Math.round((d.msrp || 53890) * 0.962);
        const colorParityOtd = Number(d.color_parity_otd || d.otd_total || 55303);
        const impliedLeaseMo = d.implied_lease_36mo || 663;
        const impliedSignDriveMo = d.implied_sign_and_drive_lease_36mo || 724;
        const impliedFin60Mo = d.implied_finance_60mo || 1041;
        const savedRounds = Number(d.total_otd_savings || 0);
        const qHist = d.quote_history || [];
        const r1Otd = qHist.length > 0 ? qHist[0].otd_total : d.otd_total;

        const roundDropHtml =
          savedRounds > 0
            ? `<div class="font-mono text-emerald-400 font-bold">-${formatMoney(savedRounds, 0)} Saved</div>
               <div class="font-mono text-[10px] text-slate-400">R1: ${formatMoney(r1Otd, 0)} → R${d.round_Number || 1}</div>`
            : `<div class="font-mono text-slate-400">Round ${d.round_Number || 1}</div>
               <div class="font-mono text-[10px] text-cyan-300">Target: ${formatMoney(d.recommended_counter_otd, 0)}</div>`;

        const flags = d.red_flags || [];
        const negStatus = d.negotiation_status || 'ACTIVE';
        const statusPill =
          negStatus === 'DEAL_SECURED'
            ? '<span class="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">🔒 DEAL SECURED</span>'
            : flags.length === 0
            ? '<span class="px-2 py-0.5 text-[10px] font-bold rounded bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">✅ CLEAN SPEC</span>'
            : `<span class="px-2 py-0.5 text-[10px] font-bold rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">⚠️ ${flags.length} AUDIT FLAG${flags.length > 1 ? 'S' : ''}</span>`;

        const trueDealScore =
          d.true_deal_score !== undefined
            ? Number(d.true_deal_score)
            : Number(((d.selling_price || 0) - (d.msrp || 0) + (d.doc_fee || 0) + (d.dealer_addons_total || 0)).toFixed(0));
        const scoreStr = trueDealScore <= 0 ? `-${formatMoney(Math.abs(trueDealScore), 0)}` : `+${formatMoney(trueDealScore, 0)}`;
        const isNonBlack = Boolean(d.is_non_black_interior);
        const interiorBadge = isNonBlack
          ? '<span class="px-1.5 py-0.5 text-[10px] font-bold rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">★ PRIORITY NON-BLACK</span>'
          : '<span class="px-1.5 py-0.5 text-[10px] font-bold rounded bg-slate-800 text-slate-300 border border-slate-700">⬛ ALL-BLACK</span>';
        const lease3k = d.nj_payment_matrix?.lease_3000_down_monthly || d.implied_lease_36mo || 663;
        const lease0 = d.nj_payment_matrix?.lease_0_down_monthly || d.implied_sign_and_drive_lease_36mo || 746;

        return `
          <tr
            onclick="window.selectCarByDealerId('${d.id}')"
            class="transition cursor-pointer ${isSelected ? 'bg-emerald-950/30' : 'hover:bg-slate-800/40'}"
          >
            <td class="py-3 px-2.5 text-center" onclick="event.stopPropagation()">
              <input
                type="checkbox"
                ${isChecked ? 'checked' : ''}
                onchange="window.toggleCompareVehicle('${d.id}', event)"
                class="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
                title="Select up to 3 vehicles for Side-by-Side Comparison &amp; Auto-Negotiation"
              >
            </td>
            <td class="py-3 px-2.5">
              <span class="px-2 py-1 rounded text-[11px] font-bold ${isBest ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-800 text-slate-300'}">
                #${rank} ${isBest ? 'TOP' : ''}
              </span>
            </td>
            <td class="py-3 px-2.5">
              <div class="font-bold text-white">${escapeHtml(d.dealer_name)}</div>
              <div class="text-[11px] text-cyan-300">📍 ${escapeHtml(d.location_label || 'Monmouth County, NJ')}</div>
            </td>
            <td class="py-3 px-2.5">
              <div class="flex flex-wrap gap-1 mb-0.5">
                <span class="px-1.5 py-0.5 text-[10px] font-bold rounded bg-cyan-500/15 text-cyan-300">TRIM #${trimRank}</span>
                ${interiorBadge}
              </div>
              <div class="font-bold text-white">${escapeHtml(d.trim_level)}</div>
              <div class="text-[11px] text-slate-300">Ext: ${escapeHtml(d.exterior_color || 'Wolf Gray')}</div>
              <div class="text-[11px] ${isNonBlack ? 'text-emerald-300 font-semibold' : 'text-slate-400'}">🎨 ${escapeHtml(d.interior_color)}</div>
            </td>
            <td class="py-3 px-2.5">
              <div class="font-mono text-xs font-bold text-cyan-300">${escapeHtml(d.vin || '--')}</div>
              ${inventoryBadgeHtml(d.inventory_status, d.eta_delivery)}
            </td>
            <td class="py-3 px-2.5 font-mono">
              <div class="text-white"><strong>${formatMoney(d.selling_price)}</strong> <span class="text-slate-400 text-[10px]">(MSRP ${formatMoney(d.msrp)})</span></div>
              <div class="text-emerald-400 font-semibold">-${formatMoney(discountAmt)} (${discountPct}% off)</div>
              <div class="text-[10px] text-slate-400">Doc: ${formatMoney(d.doc_fee)} • Add-Ons: ${formatMoney(d.dealer_addons_total || 0)}</div>
            </td>
            <td class="py-3 px-2.5 font-mono">
              <div class="text-sm font-extrabold ${trueDealScore <= 0 ? 'text-emerald-300' : 'text-amber-300'}">${scoreStr} Score</div>
              <div class="text-[11px] text-white">OTD: ${formatMoney(d.otd_total, 0)}</div>
              <div class="text-[10px] text-purple-300">Parity: ${formatMoney(colorParityOtd, 0)}</div>
            </td>
            <td class="py-3 px-2.5 font-mono">
              <div class="text-emerald-300 font-bold">$3k Down: ${formatMoney(lease3k, 0)}/mo</div>
              <div class="text-[11px] text-purple-300">$0 Down: ${formatMoney(lease0, 0)}/mo</div>
              <div class="text-[10px] text-cyan-300">60m Loan: ${formatMoney(impliedFin60Mo, 0)}/mo</div>
            </td>
            <td class="py-3 px-2.5">${roundDropHtml}</td>
            <td class="py-3 px-2.5" onclick="event.stopPropagation()">
              <button
                type="button"
                onclick="window.selectCarByDealerId('${d.id}')"
                class="px-2.5 py-1.5 rounded-lg bg-emerald-600/25 hover:bg-emerald-600/40 border border-emerald-500/40 text-emerald-200 text-[11px] font-bold transition mb-1 w-full"
              >
                🤖 Discuss with Herbie →
              </button>
              <div>${statusPill}</div>
            </td>
          </tr>
        `;
      })
      .join('');
  }

  // ===========================================================================
  // REVERSE OTD -> MONTHLY PAYMENT CALCULATOR ENGINE
  // ===========================================================================
  function loanMonthlyPaymentLocal(principal, annualAprPct, months) {
    const p = Number(principal || 0);
    const m = Math.max(1, parseInt(months || 60, 10));
    const apr = Number(annualAprPct || 0);
    if (p <= 0) return 0;
    if (apr <= 0) return Number((p / m).toFixed(2));
    const r = apr / 100 / 12;
    const pow = Math.pow(1 + r, m);
    if (pow <= 1) return Number((p / m).toFixed(2));
    return Number(((p * r * pow) / (pow - 1)).toFixed(2));
  }

  function calculateMonthlyFromOtdLocal(params) {
    const otdPrice = Number(params.otdPrice ?? 55303);
    const msrp = Number(params.msrp ?? 53890);
    const docFee = Number(params.docFee ?? 499);
    const govFees = Number(params.govFees ?? 385);
    const taxRate = Number(params.taxRate ?? 6.625);
    const rebates = Number(params.rebates ?? 500);
    const cashDown = Number(params.cashDown ?? 0);
    const apr = Number(params.apr ?? 4.9);
    const loanTerm = Math.max(1, parseInt(params.loanTerm ?? 60, 10));
    const rvPct = Number(params.rvPct ?? 62);
    const mf = Number(params.mf ?? 0.00190);
    const leaseTerm = Math.max(1, parseInt(params.leaseTerm ?? 36, 10));
    const acqFee = Number(params.acqFee ?? 650);

    const taxMult = 1 + taxRate / 100;
    const impliedTaxableBase = Math.max(0, (otdPrice - govFees) / taxMult);
    const impliedSalesTax = Number((otdPrice - govFees - impliedTaxableBase).toFixed(2));
    const impliedSellingPrice = Number((impliedTaxableBase - docFee + rebates).toFixed(2));
    const impliedDiscountDollars = Number((msrp - impliedSellingPrice).toFixed(2));
    const impliedDiscountPct = msrp > 0 ? Number(((impliedDiscountDollars / msrp) * 100).toFixed(2)) : 0;

    const amountFinanced = Math.max(0, Number((otdPrice - cashDown).toFixed(2)));
    const monthlyLoanSelected = loanMonthlyPaymentLocal(amountFinanced, apr, loanTerm);
    const monthly48 = loanMonthlyPaymentLocal(amountFinanced, apr, 48);
    const monthly60 = loanMonthlyPaymentLocal(amountFinanced, apr, 60);
    const monthly72 = loanMonthlyPaymentLocal(amountFinanced, apr, 72);
    const totalLoanPayments = Number((monthlyLoanSelected * loanTerm).toFixed(2));
    const totalInterestSelected = Math.max(0, Number((totalLoanPayments - amountFinanced).toFixed(2)));

    // Lease calculation matching tools/finance_tools.py:calculate_lease_payment
    const equivalentApr = Number((mf * 2400).toFixed(2));
    const residualValue = Number((msrp * (rvPct / 100)).toFixed(2));
    const grossCapCost = impliedSellingPrice;
    const adjustedCapCost = Number((grossCapCost - rebates - cashDown).toFixed(2));
    const monthlyDepreciation = Number(((adjustedCapCost - residualValue) / leaseTerm).toFixed(2));
    const monthlyRentCharge = Number(((adjustedCapCost + residualValue) * mf).toFixed(2));
    const baseMonthlyPayment = Number((monthlyDepreciation + monthlyRentCharge).toFixed(2));
    const monthlyTax = Number((baseMonthlyPayment * (taxRate / 100)).toFixed(2));
    const totalMonthlyPayment = Number((baseMonthlyPayment + monthlyTax).toFixed(2));

    const upfrontTax = Number(((cashDown + rebates + docFee + acqFee) * (taxRate / 100)).toFixed(2));
    const driveOffDueAtSigning = Number(
      (totalMonthlyPayment + acqFee + docFee + govFees + cashDown + upfrontTax).toFixed(2)
    );
    const totalLeaseCost = Number(
      (driveOffDueAtSigning + totalMonthlyPayment * Math.max(0, leaseTerm - 1)).toFixed(2)
    );
    const effectiveMonthlyCost = Number((totalLeaseCost / leaseTerm).toFixed(2));

    const rolledCapCost = Number(
      (impliedSellingPrice + docFee + govFees + acqFee - rebates - cashDown).toFixed(2)
    );
    const rolledDep = (rolledCapCost - residualValue) / leaseTerm;
    const rolledRent = (rolledCapCost + residualValue) * mf;
    const signAndDriveLeaseMonthly = Number(((rolledDep + rolledRent) * taxMult).toFixed(2));

    const breakdownDict = {
      otd_price: Number(otdPrice.toFixed(2)),
      msrp: Number(msrp.toFixed(2)),
      implied_selling_price_cap_cost: impliedSellingPrice,
      implied_discount_off_msrp: impliedDiscountDollars,
      implied_discount_pct: impliedDiscountPct,
      implied_taxable_base: Number(impliedTaxableBase.toFixed(2)),
      implied_sales_tax: impliedSalesTax,
      estimated_sales_tax_included_in_otd: impliedSalesTax,
      tax_rate_percent: taxRate,
      doc_fee: Number(docFee.toFixed(2)),
      gov_fees: Number(govFees.toFixed(2)),
      rebates_applied: Number(rebates.toFixed(2)),
    };

    return {
      otd_price_input: Number(otdPrice.toFixed(2)),
      msrp: Number(msrp.toFixed(2)),
      reverse_otd_decomposition: breakdownDict,
      reverse_otd_breakdown: breakdownDict,
      finance_purchase_from_otd: {
        amount_financed: amountFinanced,
        amount_financed_from_otd: amountFinanced,
        cash_down_or_trade_equity: Number(cashDown.toFixed(2)),
        loan_apr_percent: apr,
        selected_term_months: loanTerm,
        monthly_payment_selected: monthlyLoanSelected,
        monthly_loan_payment: monthlyLoanSelected,
        total_interest_selected: totalInterestSelected,
        total_interest_paid: totalInterestSelected,
        total_loan_payments: totalLoanPayments,
        monthly_48mo: monthly48,
        monthly_60mo: monthly60,
        monthly_72mo: monthly72,
      },
      lease_from_otd_cap_cost: {
        term_months: leaseTerm,
        annual_miles: 12000,
        residual_percent: rvPct,
        residual_value: residualValue,
        money_factor: mf,
        equivalent_apr: equivalentApr,
        equivalent_apr_percent: equivalentApr,
        monthly_depreciation: monthlyDepreciation,
        monthly_rent_charge: monthlyRentCharge,
        base_monthly_payment: baseMonthlyPayment,
        monthly_tax: monthlyTax,
        monthly_sales_tax: monthlyTax,
        monthly_lease_payment_with_fees_upfront: totalMonthlyPayment,
        total_monthly_payment: totalMonthlyPayment,
        drive_off_due_at_signing: driveOffDueAtSigning,
        sign_and_drive_zero_due_monthly: signAndDriveLeaseMonthly,
        effective_monthly_lease_cost: effectiveMonthlyCost,
        acquisition_fee: acqFee,
        doc_fee: docFee,
        gov_fees: govFees,
      },
    };
  }

  function syncTrimSelectWithMsrp(msrpVal) {
    const trimSelect = document.getElementById('calc-trim-select');
    if (!trimSelect) return;
    const target = Number(msrpVal || 53890);
    let bestValue = trimSelect.options[0]?.value || '53890';
    let bestDiff = Infinity;
    for (let i = 0; i < trimSelect.options.length; i += 1) {
      const optVal = Number(trimSelect.options[i].value);
      const diff = Math.abs(optVal - target);
      if (diff < bestDiff) {
        bestDiff = diff;
        bestValue = trimSelect.options[i].value;
      }
    }
    trimSelect.value = bestValue;
  }

  function syncCalculatorInputsFromDealer(found) {
    if (!found) return;
    const otdEl = document.getElementById('calc-otd-input');
    const msrpEl = document.getElementById('calc-msrp-input');
    const docEl = document.getElementById('calc-doc-input');
    const govEl = document.getElementById('calc-gov-input');
    const rebEl = document.getElementById('calc-rebates-input');
    const mfEl = document.getElementById('calc-mf-input');
    const rvEl = document.getElementById('calc-rv-input');
    const calcInvDropdown = document.getElementById('calc-inventory-dropdown');

    const msrpVal = Math.round(Number(found.msrp || 53890));
    if (otdEl) otdEl.value = Math.round(Number(found.otd_total || 55303));
    if (msrpEl) msrpEl.value = msrpVal;
    syncTrimSelectWithMsrp(msrpVal);
    if (docEl) docEl.value = Math.round(Number(found.doc_fee ?? 499));
    if (govEl) govEl.value = Math.round(Number(found.gov_fees ?? 385));
    if (rebEl) rebEl.value = Math.round(Number(found.rebates ?? 500));
    if (mfEl) mfEl.value = Number(found.money_factor || 0.00190).toFixed(5);
    if (rvEl) rvEl.value = Number(found.residual_percent || 62);
    if (calcInvDropdown && found.id) {
      calcInvDropdown.value = found.id;
    }
  }

  function highlightActivePresetButton(activeKey) {
    const container = document.getElementById('calc-dealer-presets');
    if (!container) return;
    const buttons = container.querySelectorAll('button[data-preset]');
    buttons.forEach((btn) => {
      const key = btn.getAttribute('data-preset');
      if (key === activeKey) {
        btn.classList.add('ring-2', 'ring-emerald-400');
      } else {
        btn.classList.remove('ring-2', 'ring-emerald-400');
      }
    });
  }

  window.openDealerInCalculator = function (dealerId) {
    if (dealerId) {
      const dealers = getAllInventoryVehicles(currentDashboard);
      const found = dealers.find((d) => d.id === dealerId);
      if (found) {
        selectedDealerId = found.id;
        syncCalculatorInputsFromDealer(found);
      }
    }
    window.switchViewTab('calculator');
    runReverseOtdCalculator();
  };

  window.loadPresetIntoCalc = function (presetKey) {
    highlightActivePresetButton(presetKey);
    const dealers = getAllInventoryVehicles(currentDashboard);
    if (presetKey === 'raceway') {
      const d = dealers.find((x) => x.id === 'dlr-raceway-kia-of-freehold' || x.dealer_name?.includes('Raceway'));
      if (d) {
        selectedDealerId = d.id;
        syncCalculatorInputsFromDealer(d);
      } else {
        setCalcInputs(55303, 53890, 499, 385, 500, 0.00190, 62);
      }
    } else if (presetKey === 'mattblatt') {
      const d = dealers.find((x) => x.id === 'dlr-matt-blatt-kia-of-toms-river' || x.dealer_name?.includes('Matt Blatt'));
      if (d) {
        selectedDealerId = d.id;
        syncCalculatorInputsFromDealer(d);
      } else {
        setCalcInputs(60978, 55590, 799, 385, 500, 0.00245, 62);
      }
    } else if (presetKey === 'sansone') {
      const d = dealers.find((x) => x.id === 'dlr-sansone-jr-s-66-automall-kia' || x.dealer_name?.includes('Sansone'));
      if (d) {
        selectedDealerId = d.id;
        syncCalculatorInputsFromDealer(d);
      } else {
        setCalcInputs(61126, 56985, 699, 385, 500, 0.00225, 62);
      }
    } else if (presetKey === 'invoice_target') {
      setCalcInputs(54878, 53890, 499, 385, 500, 0.00190, 62);
    } else if (presetKey === 'stretch_target') {
      setCalcInputs(54189, 53890, 499, 385, 500, 0.00190, 62);
    }
    runReverseOtdCalculator();
  };

  function setCalcInputs(otd, msrp, doc, gov, rebates, mf = 0.00190, rv = 62) {
    const otdEl = document.getElementById('calc-otd-input');
    const msrpEl = document.getElementById('calc-msrp-input');
    const docEl = document.getElementById('calc-doc-input');
    const govEl = document.getElementById('calc-gov-input');
    const rebEl = document.getElementById('calc-rebates-input');
    const mfEl = document.getElementById('calc-mf-input');
    const rvEl = document.getElementById('calc-rv-input');
    if (otdEl) otdEl.value = otd;
    if (msrpEl) msrpEl.value = msrp;
    syncTrimSelectWithMsrp(msrp);
    if (docEl) docEl.value = doc;
    if (govEl) govEl.value = gov;
    if (rebEl) rebEl.value = rebates;
    if (mfEl) mfEl.value = Number(mf).toFixed(5);
    if (rvEl) rvEl.value = Number(rv);
  }

  window.handleCalcTrimChange = function (newTrimMsrpVal) {
    const otdEl = document.getElementById('calc-otd-input');
    const msrpEl = document.getElementById('calc-msrp-input');
    const docFee = parseFloat(document.getElementById('calc-doc-input')?.value || '499');
    const govFees = parseFloat(document.getElementById('calc-gov-input')?.value || '385');
    const taxRate = parseFloat(document.getElementById('calc-tax-input')?.value || '6.625');
    const rebates = parseFloat(document.getElementById('calc-rebates-input')?.value || '500');

    const newMsrp = parseFloat(newTrimMsrpVal || document.getElementById('calc-trim-select')?.value || '53890');
    const prevMsrp = parseFloat(msrpEl?.value || '53890');
    const prevOtd = parseFloat(otdEl?.value || '55303');

    if (Number.isFinite(newMsrp) && newMsrp > 0) {
      const taxMult = 1 + taxRate / 100;
      const prevTaxable = Math.max(0, (prevOtd - govFees) / taxMult);
      const prevSelling = prevTaxable - docFee + rebates;
      let discRatio = prevMsrp > 0 ? (prevMsrp - prevSelling) / prevMsrp : 0.038;
      if (!Number.isFinite(discRatio) || discRatio < -0.10 || discRatio > 0.20) {
        discRatio = 0.038;
      }

      if (msrpEl) {
        msrpEl.value = Math.round(newMsrp);
      }
      if (otdEl && Math.round(newMsrp) !== Math.round(prevMsrp)) {
        const newSelling = Math.round(newMsrp * (1 - discRatio));
        const newTaxable = Math.max(0, newSelling + docFee - rebates);
        const newOtd = Math.round(newTaxable * taxMult + govFees);
        otdEl.value = newOtd;
      }
    }
    runReverseOtdCalculator();
  };

  window.selectCalcLoanTerm = function (termMonths) {
    const termSelect = document.getElementById('calc-loan-term-input');
    if (termSelect) {
      termSelect.value = String(termMonths);
    }
    runReverseOtdCalculator();
  };

  async function runReverseOtdCalculator() {
    const otdPrice = parseFloat(document.getElementById('calc-otd-input')?.value || '55303');
    const msrp = parseFloat(document.getElementById('calc-msrp-input')?.value || '53890');
    const rebates = parseFloat(document.getElementById('calc-rebates-input')?.value || '500');
    const docFee = parseFloat(document.getElementById('calc-doc-input')?.value || '499');
    const govFees = parseFloat(document.getElementById('calc-gov-input')?.value || '385');
    const taxRate = parseFloat(document.getElementById('calc-tax-input')?.value || '6.625');
    const cashDown = parseFloat(document.getElementById('calc-down-input')?.value || '0');
    const apr = parseFloat(document.getElementById('calc-apr-input')?.value || '4.9');
    const loanTerm = parseInt(document.getElementById('calc-loan-term-input')?.value || '60', 10);
    const rvPct = parseFloat(document.getElementById('calc-rv-input')?.value || '62');
    const mf = parseFloat(document.getElementById('calc-mf-input')?.value || '0.00190');
    const leaseTerm = parseInt(document.getElementById('calc-lease-term-input')?.value || '36', 10);
    const acqFee = parseFloat(document.getElementById('calc-acq-input')?.value || '650');

    // 1. Immediately compute and render deterministic NJ math on the client (0ms latency)
    const localCalc = calculateMonthlyFromOtdLocal({
      otdPrice,
      msrp,
      docFee,
      govFees,
      taxRate,
      rebates,
      cashDown,
      apr,
      loanTerm,
      rvPct,
      mf,
      leaseTerm,
      acqFee,
    });
    renderCalculatorOutputs(localCalc, loanTerm);

    // 2. Also sync with backend API if reachable
    try {
      const res = await fetch('/api/calculate_from_otd', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          otd_price: otdPrice,
          msrp: msrp,
          doc_fee: docFee,
          gov_fees: govFees,
          tax_rate_percent: taxRate,
          rebates: rebates,
          cash_down_payment: cashDown,
          apr_percent: apr,
          loan_term_months: loanTerm,
          residual_percent: rvPct,
          money_factor: mf,
          lease_term_months: leaseTerm,
          annual_miles: 12000,
          acquisition_fee: acqFee,
        }),
      });
      if (res.ok) {
        const calc = await res.json();
        renderCalculatorOutputs(calc, loanTerm);
      }
    } catch (e) {
      // Already rendered via deterministic client-side engine
    }
  }
  window.runReverseOtdCalculator = runReverseOtdCalculator;

  function renderCalculatorOutputs(calc, selectedLoanTerm) {
    if (!calc) return;
    const b = calc.reverse_otd_breakdown || calc.reverse_otd_decomposition || {};
    const fin = calc.finance_purchase_from_otd || {};
    const lse = calc.lease_from_otd_cap_cost || {};

    const elStep1Label = document.getElementById('res-step1-label');
    const elImpliedSelling = document.getElementById('res-implied-selling');
    const elImpliedDiscount = document.getElementById('res-implied-discount');
    const elFormula = document.getElementById('res-reverse-formula');

    const taxRateNum = Number(b.tax_rate_percent ?? 6.625);
    if (elStep1Label) {
      elStep1Label.textContent = `STEP 1 • WORKED BACKWARD FROM OTD PRICE (${taxRateNum}% NJ TAX STRIPPED OUT)`;
    }
    if (elImpliedSelling) {
      elImpliedSelling.textContent = formatMoney(b.implied_selling_price_cap_cost, 2);
    }
    if (elImpliedDiscount) {
      const discDollars = Number(b.implied_discount_off_msrp || 0);
      const discPct = Math.abs(Number(b.implied_discount_pct || 0)).toFixed(2);
      const isDiscount = discDollars >= 0;
      const discSign = isDiscount ? '-' : '+';
      const labelWord = isDiscount ? 'off' : 'above';
      elImpliedDiscount.textContent = `${discSign}${formatMoney(Math.abs(discDollars), 2)} (${discPct}% ${labelWord} ${formatMoney(b.msrp, 0)} MSRP)`;
      elImpliedDiscount.style.color = isDiscount ? '#34d399' : '#fbbf24';
    }
    if (elFormula) {
      const salesTaxAmt = b.implied_sales_tax ?? b.estimated_sales_tax_included_in_otd ?? 0;
      elFormula.innerHTML =
        `OTD <strong>${formatMoney(b.otd_price, 2)}</strong> - ${formatMoney(b.gov_fees, 2)} NJ MVC = ${formatMoney(b.otd_price - b.gov_fees, 2)}<br>` +
        `÷ ${(1 + taxRateNum / 100).toFixed(5)} (NJ Tax: ${formatMoney(salesTaxAmt, 2)}) = ${formatMoney(b.implied_taxable_base, 2)} Taxable Base<br>` +
        `- ${formatMoney(b.doc_fee, 2)} Doc Fee + ${formatMoney(b.rebates_applied, 2)} Rebate = <strong>${formatMoney(b.implied_selling_price_cap_cost, 2)} Selling Price</strong>`;
    }

    const elLoanPrimary = document.getElementById('res-loan-primary');
    const elLoanSub = document.getElementById('res-loan-sub');
    const elLoan48 = document.getElementById('res-loan-48');
    const elLoan60 = document.getElementById('res-loan-60');
    const elLoan72 = document.getElementById('res-loan-72');
    const elLoanInterest = document.getElementById('res-loan-interest');

    const termMonths = Number(selectedLoanTerm || fin.selected_term_months || 60);
    const monthlyLoan = Number(fin.monthly_loan_payment ?? fin.monthly_payment_selected ?? 0);
    const amountFinanced = Number(fin.amount_financed ?? fin.amount_financed_from_otd ?? 0);
    const totalInterest = Number(
      fin.total_interest_paid ??
        fin.total_interest_selected ??
        Math.max(0, monthlyLoan * termMonths - amountFinanced)
    );
    const totalLoanCost = Number(fin.total_loan_payments ?? monthlyLoan * termMonths);

    if (elLoanPrimary) {
      elLoanPrimary.innerHTML = `${formatMoney(monthlyLoan, 2)}<span style="font-size:1rem;">/mo</span>`;
    }
    if (elLoanSub) {
      elLoanSub.textContent = `${termMonths} Months @ ${Number(fin.loan_apr_percent ?? 4.9).toFixed(2)}% APR • Amount Financed: ${formatMoney(amountFinanced, 2)}`;
    }
    if (elLoan48) elLoan48.textContent = `${formatMoney(fin.monthly_48mo, 2)}/mo`;
    if (elLoan60) elLoan60.textContent = `${formatMoney(fin.monthly_60mo, 2)}/mo`;
    if (elLoan72) elLoan72.textContent = `${formatMoney(fin.monthly_72mo, 2)}/mo`;
    if (elLoanInterest) {
      elLoanInterest.textContent = `Total Interest (${termMonths}m): ${formatMoney(totalInterest, 2)} • Total Paid: ${formatMoney(totalLoanCost, 2)}`;
    }

    [48, 60, 72].forEach((t) => {
      const pill = document.getElementById(`term-pill-${t}`);
      if (pill) {
        pill.classList.toggle('active-term', t === termMonths);
      }
    });

    const elLeaseLabel = document.getElementById('res-lease-label');
    const elLeasePrimary = document.getElementById('res-lease-primary');
    const elLeaseSub = document.getElementById('res-lease-sub');
    const elLeaseSignDriveSub = document.getElementById('res-lease-signdrive-sub');
    const elLeaseSignDrive = document.getElementById('res-lease-signdrive');
    const elLeaseBreakdown = document.getElementById('res-lease-breakdown');

    const leaseTermNum = Number(lse.term_months || 36);
    const leaseMonthlyUpfront = Number(
      lse.monthly_lease_payment_with_fees_upfront ?? lse.total_monthly_payment ?? 0
    );
    if (elLeaseLabel) {
      elLeaseLabel.textContent = `🔄 ${leaseTermNum}-MO HYBRID LEASE MONTHLY (FROM OTD CAP COST)`;
    }
    if (elLeasePrimary) {
      elLeasePrimary.innerHTML = `${formatMoney(leaseMonthlyUpfront, 2)}<span style="font-size:1rem;">/mo</span>`;
    }
    if (elLeaseSub) {
      elLeaseSub.textContent = `Standard ${leaseTermNum}-Mo Lease (${formatMoney(lse.drive_off_due_at_signing, 2)} Due at Signing incl. 1st Mo + NJ Fees)`;
    }
    if (elLeaseSignDriveSub) {
      const acqVal = Number(lse.acquisition_fee ?? document.getElementById('calc-acq-input')?.value ?? 650);
      const docVal = Number(b.doc_fee ?? document.getElementById('calc-doc-input')?.value ?? 499);
      const govVal = Number(b.gov_fees ?? document.getElementById('calc-gov-input')?.value ?? 385);
      elLeaseSignDriveSub.textContent = `All NJ taxes, ${formatMoney(acqVal, 0)} Acq, ${formatMoney(docVal, 0)} Doc & ${formatMoney(govVal, 0)} MVC rolled into ${leaseTermNum} payments`;
    }
    if (elLeaseSignDrive) {
      elLeaseSignDrive.textContent = `${formatMoney(lse.sign_and_drive_zero_due_monthly, 2)}/mo`;
    }
    if (elLeaseBreakdown) {
      const eqApr = Number(lse.equivalent_apr_percent ?? lse.equivalent_apr ?? 4.56).toFixed(2);
      const leaseTax = Number(lse.monthly_sales_tax ?? lse.monthly_tax ?? 0);
      elLeaseBreakdown.textContent =
        `Residual (${lse.residual_percent}%): ${formatMoney(lse.residual_value, 2)} • ` +
        `Depreciation: ${formatMoney(lse.monthly_depreciation, 2)}/mo • ` +
        `Rent Charge (${eqApr}% APR): ${formatMoney(lse.monthly_rent_charge, 2)}/mo • ` +
        `NJ Tax: ${formatMoney(leaseTax, 2)}/mo`;
    }
  }

  function computeRemainingCountdown(isoTarget) {
    if (!isoTarget) return 'Ready';
    const diffMs = new Date(isoTarget).getTime() - Date.now();
    if (diffMs <= 0) return '0m 00s (Dispatching...)';
    const totalSec = Math.floor(diffMs / 1000);
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins}m ${String(secs).padStart(2, '0')}s remaining`;
  }

  window.approveMessage = async function (msgId, sendNow) {
    const textarea = document.getElementById(`draft-body-${msgId}`);
    const editedBody = textarea ? textarea.value : '';
    const res = await fetch('/api/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message_id: msgId,
        send_immediately_override: Boolean(sendNow),
        edited_body: editedBody,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      currentDashboard = data;
      renderDashboard(data);
      mirrorToClientFirestore(data);
    }
  };

  window.dispatchNow = async function () {
    const res = await fetch('/api/dispatch_ready', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ force_send_all_queued: true }),
    });
    if (res.ok) {
      const data = await res.json();
      currentDashboard = data;
      renderDashboard(data);
      mirrorToClientFirestore(data);
    }
  };

  async function seedCampaign(dealType) {
    const res = await fetch('/api/seed', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deal_type: dealType,
        vehicle:
          '2027 Kia Telluride Hybrid (Priority: #1 Hybrid SX X-Line, #2 Hybrid SX Prestige, #3 Hybrid SX Prestige X-Line — Non-Black Interior Nice-to-Have)',
        target_msrp: 53890,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      currentDashboard = data;
      const dealers = data.dealers_ranked || [];
      comparedDealerIds = dealers.slice(0, 3).map((d) => d.id);
      renderDashboard(data);
      mirrorToClientFirestore(data);
    }
  }

  // Bind UI Controls
  document.getElementById('seed-purchase-btn')?.addEventListener('click', () => seedCampaign('PURCHASE'));
  document.getElementById('seed-lease-btn')?.addEventListener('click', () => seedCampaign('LEASE'));
  document.getElementById('approve-all-stealth-btn')?.addEventListener('click', () => window.approveMessage('ALL', false));
  document.getElementById('fast-forward-btn')?.addEventListener('click', async () => {
    await window.approveMessage('ALL', false);
    await window.dispatchNow();
  });

  const calcTrimSelect = document.getElementById('calc-trim-select');
  if (calcTrimSelect) {
    calcTrimSelect.addEventListener('change', () => {
      window.handleCalcTrimChange(calcTrimSelect.value);
    });
  }

  const calcInputIds = [
    'calc-otd-input',
    'calc-msrp-input',
    'calc-rebates-input',
    'calc-doc-input',
    'calc-gov-input',
    'calc-tax-input',
    'calc-down-input',
    'calc-apr-input',
    'calc-loan-term-input',
    'calc-rv-input',
    'calc-mf-input',
    'calc-lease-term-input',
    'calc-acq-input',
  ];
  calcInputIds.forEach((id) => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', runReverseOtdCalculator);
      el.addEventListener('change', runReverseOtdCalculator);
    }
  });

  setInterval(() => {
    const badges = document.querySelectorAll('.stealth-badge[data-scheduled]');
    badges.forEach((b) => {
      const sched = b.getAttribute('data-scheduled');
      if (sched) {
        b.textContent = '⏳ STEALTH TIMER — ' + computeRemainingCountdown(sched);
      }
    });
  }, 1000);

  window.addEventListener('DOMContentLoaded', () => {
    initFirestoreSync();
    fetchDashboard();
    if (window.location && window.location.search && window.location.search.includes('tab=calculator')) {
      window.switchViewTab('calculator');
    } else {
      runReverseOtdCalculator();
    }
    setInterval(fetchDashboard, 6000);
  });
})();

