"""""""""
Demo Campaign Seeder for the Autonomous Car Negotiator (Monmouth & Ocean County, NJ).

Uses the dynamic Prevailing Market Benchmark (Invoice, Holdback, Prevailing NJ Comp %,
and Stretch Counter Target %) instead of static multipliers.
"""

from typing import Any, Dict

from .comms_tools import (
    approve_queued_message,
    generate_natural_buyer_counter,
    queue_dealer_message,
)
from .deal_tracker import (
    create_or_update_campaign,
    get_best_competing_offer,
    get_negotiation_dashboard,
    upsert_dealer_lead,
)
from .firestore_sync import _default_state, save_state
from .market_research_tools import get_prevailing_market_benchmark
from .observability import instrument_tool


@instrument_tool
def seed_sample_negotiation_campaign(
    vehicle: str = "2027 Kia Telluride Hybrid (Priority: #1 Hybrid SX X-Line, #2 Hybrid SX Prestige, #3 Hybrid SX Prestige X-Line — Non-Black Interior Nice-to-Have)",
    deal_type: str = "PURCHASE",
    target_msrp: float = 53890.0,
    target_otd_or_monthly: float = 54877.67,
    buyer_name: str = "Alex",
    buyer_phone: str = "+17325550199",
    reset_existing: bool = True,
) -> Dict[str, Any]:
    """Seeds a 3-dealer Monmouth & Ocean County, NJ 2027 Kia Telluride Hybrid campaign anchored to prevailing NJ market comps.

    Args:
        vehicle (str): Target vehicle and trim priority description.
        deal_type (str): 'PURCHASE' or 'LEASE'.
        target_msrp (float): Primary target trim MSRP in USD (default 53890.0 for Hybrid SX X-Line).
        target_otd_or_monthly (float): Target OTD price (for PURCHASE) or monthly payment (for LEASE) in USD.
        buyer_name (str): Buyer's first name used in outbound scripts.
        buyer_phone (str): Buyer's phone number for SMS routing.
        reset_existing (bool): If True, resets existing state before seeding baseline campaign.

    Returns:
        Dict[str, Any]: Complete negotiation dashboard snapshot after seeding Round 1 quotes and Round 2 pending drafts.
    """
    if reset_existing:
        save_state(_default_state())

    create_or_update_campaign(
        vehicle=vehicle,
        deal_type=deal_type,
        target_msrp=target_msrp,
        target_otd_or_monthly=target_otd_or_monthly,
        zip_code="07724",
        tax_rate_percent=6.625,
        term_months=36,
        annual_miles=12000,
        base_buy_rate_mf=0.00190,
        residual_percent=62.0,
        buyer_name=buyer_name,
        buyer_phone=buyer_phone,
        target_delivery_window="End of December 2026",
        inventory_preference="IN_TRANSIT_DECEMBER_DELIVERY",
        interior_preference="Non-Black Interior Nice-to-Have Tiebreaker (Terracotta, Sage Green, Mahogany; ~$295 factory option; Black accepted for lower OTD)",
        dealer_region_rule="NJ Only — Priority #1: Monmouth & Ocean Counties, NJ",
        trade_in_secrecy_active=True,
        autonomy_mode="COPILOT",
    )

    dealers = [
        {
            "dealer_name": "Raceway Kia of Freehold",
            "city": "Freehold",
            "county": "Monmouth County",
            "state": "NJ",
            "contact_name": "Marcus Vance (Internet Director)",
            "contact_email": "mvance@racewaykiafreehold.example.com",
            "contact_phone": "+17325550142",
            "preferred_channel": "SMS_PERSONAL",
            "vin": "5XYP5DGC8VG041822",
            "stock_number": "RWK-822-HYB",
            "trim_level": "2027 Kia Telluride Hybrid SX X-Line",
            "exterior_color": "Wolf Gray",
            "interior_color": "Terracotta Brown Leather (Non-Black Preferred)",
            "msrp": 53890.0,
            "persona": "volume_dealer",
            "inventory_status": "IN_TRANSIT",
            "eta_delivery": "Dec 23–Dec 28, 2026",
        },
        {
            "dealer_name": "Matt Blatt Kia of Toms River",
            "city": "Toms River",
            "county": "Ocean County",
            "state": "NJ",
            "contact_name": "Dana Sterling (Inventory & Allocation Mgr)",
            "contact_email": "dsterling@mattblattkiatr.example.com",
            "contact_phone": "+17325550188",
            "preferred_channel": "SMS_TWILIO",
            "vin": "5XYP5DGC2VG049104",
            "stock_number": "MBK-104-HYB",
            "trim_level": "2027 Kia Telluride Hybrid SX Prestige",
            "exterior_color": "Glacial White Pearl",
            "interior_color": "Sage Green Nappa Leather (Non-Black Preferred)",
            "msrp": 55590.0,
            "persona": "high_markup_dealer",
            "inventory_status": "IN_TRANSIT",
            "eta_delivery": "Dec 21–Dec 27, 2026",
        },
        {
            "dealer_name": "Sansone Jr's 66 Automall Kia",
            "city": "Neptune",
            "county": "Monmouth County",
            "state": "NJ",
            "contact_name": "Bill Kowalski (Senior Internet Sales)",
            "contact_email": "sales@66automallkia.example.com",
            "contact_phone": "+17325550165",
            "preferred_channel": "EMAIL",
            "vin": "5XYP5DGC9VG011290",
            "stock_number": "S66-290-HYB",
            "trim_level": "2027 Kia Telluride Hybrid SX Prestige X-Line",
            "exterior_color": "Jungle Green",
            "interior_color": "Mahogany Brown Nappa Leather (Non-Black Preferred)",
            "msrp": 56985.0,
            "persona": "old_school_dealer",
            "inventory_status": "IN_TRANSIT",
            "eta_delivery": "Dec 24–Dec 30, 2026",
        },
    ]

    for d in dealers:
        lead = upsert_dealer_lead(**d)
        r1_gen = generate_natural_buyer_counter(
            dealer_lead=lead,
            target_otd=0.0,
            target_selling_price=0.0,
            buyer_name=buyer_name,
            round_number=1,
        )
        msg = queue_dealer_message(
            dealer_id=lead["id"],
            body=r1_gen["script"],
            channel=d["preferred_channel"],
        )
        approve_queued_message(msg["id"], send_immediately_override=True)

    best_offer = get_best_competing_offer()
    dashboard = get_negotiation_dashboard()

    for lead in dashboard["dealers_ranked"]:
        d_id = lead["id"]
        lead_msrp = float(lead.get("msrp", 53890.0))
        trim_name = lead.get("trim_level", "2027 Kia Telluride Hybrid SX X-Line")
        bench = get_prevailing_market_benchmark(trim_level=trim_name, msrp=lead_msrp)

        target_cap = float(bench["stretch_counter_selling_price"])
        target_otd = float(
            lead.get("recommended_counter_otd")
            or round((target_cap + 499.0 - 500.0) * 1.06625 + 385.0, 0)
        )

        r2_gen = generate_natural_buyer_counter(
            dealer_lead=lead,
            target_otd=target_otd,
            target_selling_price=target_cap,
            competing_best_otd=float(best_offer.get("best_otd_total") or 55303.0),
            competing_discount_pct=float(best_offer.get("best_discount_pct") or 3.8),
            buyer_name=buyer_name,
            round_number=2,
            dealer_objection_text=str(lead.get("last_dealer_message") or ""),
        )

        queue_dealer_message(
            dealer_id=d_id,
            body=r2_gen["script"],
            channel=lead["preferred_channel"],
        )

    return get_negotiation_dashboard()
