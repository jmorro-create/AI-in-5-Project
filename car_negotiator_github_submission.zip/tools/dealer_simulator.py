"""
AI & Deterministic Car Dealership Salesperson Simulator (Monmouth & Ocean County, NJ).

Uses the campaign's dynamic Prevailing Market Benchmark (Invoice, Holdback, Prevailing NJ Comp %,
and Stretch Target %) to simulate realistic multi-round NJ dealer responses.
"""

from datetime import datetime, timezone
from typing import Any, Dict
import uuid

from .deal_tracker import record_dealer_quote, upsert_dealer_lead
from .finance_tools import calculate_lease_payment, calculate_otd_price
from .firestore_sync import load_state, upsert_document
from .market_research_tools import get_prevailing_market_benchmark
from .observability import instrument_tool


@instrument_tool
def simulate_dealer_reply(dealer_id: str, buyer_message: str = "") -> Dict[str, Any]:
    """Generates a realistic NJ dealer response anchored to prevailing market benchmarks.

    Args:
        dealer_id (str): Target dealership ID (e.g., 'dlr-raceway-kia-of-freehold').
        buyer_message (str): Optional outbound buyer message text that triggered this reply.

    Returns:
        Dict[str, Any]: Dictionary containing `inbound_message`, `updated_lead`, and `financial_audit`.
    """
    state = load_state()
    lead = state.get("dealer_leads", {}).get(dealer_id)
    if not lead:
        lead = upsert_dealer_lead(
            dealer_name=dealer_id.replace("dlr-", "").replace("-", " ").title()
        )
        state = load_state()

    camp_id = lead.get("campaign_id") or state.get("active_campaign_id")
    campaign = state.get("campaigns", {}).get(camp_id, {})

    deal_type = campaign.get("deal_type", "PURCHASE")
    trim_level = lead.get("trim_level", "2027 Kia Telluride Hybrid SX X-Line")
    exterior_color = lead.get("exterior_color", "Wolf Gray")
    interior_color = lead.get("interior_color", "Terracotta Brown Leather (Non-Black Preferred)")
    location_label = lead.get("location_label", "Freehold, Monmouth County, NJ")
    msrp = float(lead.get("msrp") or campaign.get("target_msrp") or 53890.0)
    tax_rate = float(campaign.get("tax_rate_percent", 6.625))
    term_months = int(campaign.get("term_months", 36))
    annual_miles = int(campaign.get("annual_miles", 12000))
    base_mf = float(campaign.get("base_buy_rate_mf", 0.00190))
    residual_pct = float(campaign.get("residual_percent", 62.0))
    buyer_name = campaign.get("buyer_name", "Alex")

    bench = get_prevailing_market_benchmark(trim_level=trim_level, msrp=msrp)
    prevailing_pct = float(bench["prevailing_market_discount_pct"])
    stretch_pct = float(bench["stretch_target_discount_pct"])
    invoice_price = float(bench["estimated_invoice_price"])

    persona = lead.get("persona", "volume_dealer")
    current_round = int(lead.get("round", 0)) + 1
    dealer_name = lead.get("dealer_name", "Monmouth County Kia")
    contact_name = lead.get("contact_name", "Internet Sales Manager")
    vin = lead.get("vin", "5XYP5DGC8VG041822")
    eta = lead.get("eta_delivery", "Dec 23–Dec 28, 2026")
    channel = lead.get("preferred_channel", "SMS_PERSONAL")

    vehicle_spec_desc = f"{trim_level} ({exterior_color} / {interior_color})"

    if persona == "high_markup_dealer":
        if current_round == 1:
            disc_pct = max(0.8, prevailing_pct - 2.8)
            selling_price = round(msrp * (1.0 - disc_pct / 100.0), 0)
            addons_total = 1495.0
            addons_desc = "NJ Appearance & Etch Pack ($1,495)"
            mf = round(base_mf + 0.00055, 5)
            doc_fee = 799.0
            pitch_note = (
                f"Hi {buyer_name}, {contact_name} at {dealer_name} ({location_label}). "
                f"Confirming our incoming IN-TRANSIT {vehicle_spec_desc}, VIN {vin} (ETA {eta}). "
                f"2027 Telluride Hybrids are in high demand—here is our initial OTD worksheet: "
            )
        elif current_round == 2:
            disc_pct = prevailing_pct + 0.4
            selling_price = round(msrp * (1.0 - disc_pct / 100.0), 0)
            addons_total = 0.0
            addons_desc = ""
            mf = base_mf
            doc_fee = 549.0
            pitch_note = (
                f"{buyer_name}, since VIN {vin} ({vehicle_spec_desc}) is still in transit to {location_label}, "
                f"my GSM agreed to place a strict PDI Hold ($0 dealer add-ons), beat invoice (${invoice_price:,.0f}), "
                f"and apply the tier-1 {base_mf:.5f} buy-rate: "
            )
        else:
            disc_pct = stretch_pct + 0.2
            selling_price = round(msrp * (1.0 - disc_pct / 100.0), 0)
            addons_total = 0.0
            addons_desc = ""
            mf = base_mf
            doc_fee = 499.0
            pitch_note = (
                f"Okay {buyer_name}, we want to earn your business right here in Ocean/Monmouth County! "
                f"Here is our final written lock dipping into our dealer holdback on the IN-TRANSIT {vehicle_spec_desc} with $0 add-ons: "
            )

    elif persona == "old_school_dealer":
        if current_round == 1:
            disc_pct = max(1.5, prevailing_pct - 2.0)
            selling_price = round(msrp * (1.0 - disc_pct / 100.0), 0)
            addons_total = 695.0
            addons_desc = "Window Tint & Wheel Locks ($695)"
            mf = round(base_mf + 0.00035, 5)
            doc_fee = 699.0
            pitch_note = (
                f"Hi {buyer_name}, thanks for contacting {dealer_name} in {location_label}! "
                f"We have that IN-TRANSIT {vehicle_spec_desc} (VIN {vin}, ETA {eta}) allocated. "
                f"When can you stop by our showroom on Route 66? Here is our starter worksheet: "
            )
        elif current_round == 2:
            disc_pct = prevailing_pct + 0.2
            selling_price = round(msrp * (1.0 - disc_pct / 100.0), 0)
            addons_total = 0.0
            addons_desc = ""
            mf = base_mf
            doc_fee = 499.0
            pitch_note = (
                f"Understood {buyer_name}—we'll lock the numbers in writing at invoice (${selling_price:,.0f}) and put a PDI hold on VIN {vin} "
                f"({vehicle_spec_desc}) so the $695 tint/locks are never installed when the carrier arrives in late December: "
            )
        else:
            disc_pct = stretch_pct
            selling_price = round(msrp * (1.0 - disc_pct / 100.0), 0)
            addons_total = 0.0
            addons_desc = ""
            mf = base_mf
            doc_fee = 449.0
            pitch_note = (
                f"Alright {buyer_name}, my GSM signed off on matching your ${selling_price:,.0f} target (below invoice) "
                f"on the {vehicle_spec_desc} so we can count this unit for year-end in December: "
            )

    else:
        if current_round == 1:
            disc_pct = prevailing_pct
            selling_price = round(msrp * (1.0 - disc_pct / 100.0), 0)
            addons_total = 399.0
            addons_desc = "VIN Etch & Cargo Tray ($399)"
            mf = base_mf
            doc_fee = 499.0
            pitch_note = (
                f"Hi {buyer_name}! {contact_name} at {dealer_name} ({location_label}). "
                f"Happy to lock in our IN-TRANSIT {vehicle_spec_desc} (VIN {vin}, ETA {eta}) in writing at ${selling_price:,.0f} selling price for end-of-December delivery. "
                f"Here is our Round 1 itemized quote: "
            )
        elif current_round == 2:
            disc_pct = stretch_pct
            selling_price = round(msrp * (1.0 - disc_pct / 100.0), 0)
            addons_total = 0.0
            addons_desc = ""
            mf = base_mf
            doc_fee = 449.0
            pitch_note = (
                f"Thanks {buyer_name}. We removed the $399 etch/cargo fee ($0 add-ons) on IN-TRANSIT VIN {vin} ({vehicle_spec_desc}) "
                f"and dropped the price to ${selling_price:,.0f} (${msrp - selling_price:,.0f} below MSRP): "
            )
        else:
            disc_pct = stretch_pct + 0.6
            selling_price = round(msrp * (1.0 - disc_pct / 100.0), 0)
            addons_total = 0.0
            addons_desc = ""
            mf = base_mf
            doc_fee = 399.0
            pitch_note = (
                f"You've got a deal, {buyer_name}! Since you're right here in Monmouth County, we'll beat every NJ quote "
                f"on the IN-TRANSIT {vehicle_spec_desc} at ${selling_price:,.0f} selling price (${msrp - selling_price:,.0f} off MSRP) with $0 add-ons: "
            )

    gov_fees = 385.0
    rebates = float(bench.get("kia_incentives_rebates", 500.0))

    otd_calc = calculate_otd_price(
        msrp=msrp,
        selling_price=selling_price,
        doc_fee=doc_fee,
        gov_fees=gov_fees,
        tax_rate_percent=tax_rate,
        dealer_addons_total=addons_total,
        rebates=rebates,
        addon_descriptions=addons_desc,
        prevailing_market_discount_pct=prevailing_pct,
        stretch_counter_discount_pct=stretch_pct,
        invoice_below_msrp_pct=float(bench["invoice_below_msrp_pct"]),
    )
    otd_val = otd_calc["otd_total"]

    if deal_type == "LEASE":
        calc = calculate_lease_payment(
            msrp=msrp,
            selling_price=selling_price,
            residual_percent=residual_pct,
            money_factor=mf,
            term_months=term_months,
            annual_miles=annual_miles,
            tax_rate_percent=tax_rate,
            acquisition_fee=650.0,
            doc_fee=doc_fee,
            gov_fees=gov_fees,
            dealer_addons_total=addons_total,
            rebates_and_lease_cash=rebates,
            cap_cost_reduction_down=0.0,
            base_buy_rate_mf=base_mf,
        )
        monthly = calc["total_monthly_payment"]
        drive_off = calc["drive_off_due_at_signing"]
        quote_summary = (
            f"Trim: {trim_level} | Interior: {interior_color} | Status: {lead.get('inventory_status', 'IN_TRANSIT')} ({eta}) | "
            f"MSRP: ${msrp:,.0f} | Selling Price (Cap Cost): ${selling_price:,.0f} | "
            f"Rebates: ${rebates:,.0f} | Add-ons: ${addons_total:,.0f} {f'({addons_desc})' if addons_desc else '($0 Add-Ons)'} | "
            f"Equivalent OTD: ${otd_val:,.2f} | Residual: {residual_pct}% (${calc['residual_value']:,.0f}) | "
            f"NJ Doc Fee: ${doc_fee:,.0f} | NJ MVC Fees: ${gov_fees:,.0f} | "
            f"Payment: ${monthly:,.2f}/mo (incl. {tax_rate}% NJ tax) for {term_months} mos / {annual_miles:,} mi/yr with ${drive_off:,.2f} drive-off."
        )
    else:
        monthly = 0.0
        drive_off = 0.0
        quote_summary = (
            f"Trim: {trim_level} | Interior: {interior_color} | Status: {lead.get('inventory_status', 'IN_TRANSIT')} ({eta}) | "
            f"MSRP: ${msrp:,.0f} | Selling Price: ${selling_price:,.0f} | "
            f"Rebates: -${rebates:,.0f} | Add-ons: ${addons_total:,.0f} {f'({addons_desc})' if addons_desc else '($0 Add-Ons)'} | "
            f"NJ Doc Fee: ${doc_fee:,.0f} | NJ MVC Title/Reg: ${gov_fees:,.0f} | NJ Sales Tax ({tax_rate}%): ${otd_calc['sales_tax']:,.2f} | "
            f"Total Out-The-Door (OTD): ${otd_val:,.2f}."
        )

    reply_text = f"{pitch_note}\n\n{quote_summary}\n\nReady to hold VIN {vin} for your end-of-December delivery!"

    lead["round"] = current_round
    upsert_document("dealer_leads", dealer_id, lead)

    audit_result = record_dealer_quote(
        dealer_id=dealer_id,
        selling_price=selling_price,
        dealer_quoted_otd=otd_val,
        dealer_quoted_monthly=monthly,
        dealer_quoted_drive_off=drive_off,
        money_factor=mf,
        residual_percent=residual_pct,
        dealer_addons_total=addons_total,
        addon_descriptions=addons_desc,
        doc_fee=doc_fee,
        gov_fees=gov_fees,
        rebates=rebates,
        cap_cost_reduction_down=0.0,
        raw_dealer_message=reply_text,
    )

    msg_id = f"msg-{uuid.uuid4().hex[:10]}"
    now_iso = datetime.now(timezone.utc).isoformat()
    inbound_msg = {
        "id": msg_id,
        "campaign_id": camp_id or "camp-2027-kia-telluride-nj",
        "dealer_id": dealer_id,
        "dealer_name": dealer_name,
        "direction": "INBOUND",
        "channel": channel
        if channel in ("EMAIL", "SMS_PERSONAL", "SMS_TWILIO")
        else "SMS_PERSONAL",
        "status": "RECEIVED",
        "round": current_round,
        "subject": f"Re: In-Transit Quote - {trim_level} ({interior_color})",
        "body": reply_text,
        "delay_seconds": 0,
        "delay_explanation": "Inbound NJ dealer response",
        "scheduled_send_at": now_iso,
        "sent_at": now_iso,
        "created_at": now_iso,
    }
    upsert_document("message_queue", msg_id, inbound_msg)

    return {
        "inbound_message": inbound_msg,
        "updated_lead": audit_result["dealer_lead"],
        "financial_audit": audit_result["financial_audit"],
    }
