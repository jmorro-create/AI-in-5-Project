"""
Prevailing Market Intelligence & Real-World Deal Comps Engine.

Stores and computes NJ / Tri-State market benchmarks (Invoice, Dealer Holdback,
Prevailing Market Discount %, and Top-Decile Stretch Counter Target %) for the
2027 Kia Telluride Hybrid trims (#1 Hybrid SX X-Line, #2 Hybrid SX Prestige, #3 Hybrid SX Prestige X-Line).
"""

from datetime import datetime, timezone
from typing import Any, Dict

from .firestore_sync import load_state, upsert_document
from .observability import instrument_tool
from .schemas import MarketBenchmarkUpdateInputSchema, build_guided_error, validate_tool_input

DEFAULT_MARKET_BENCHMARK = {
    "zip_code": "07724",
    "region": "Monmouth & Ocean Counties, NJ (NYC/NJ Tri-State Market - ZIP 07724)",
    "powertrain_requirement": "2027 Kia Telluride Hybrid ONLY (2.5L Turbo Hybrid AWD — Non-Hybrid Gas V6 Excluded)",
    "invoice_below_msrp_pct": 3.8,
    "dealer_holdback_pct": 2.0,
    "prevailing_market_discount_pct": 3.8,
    "stretch_target_discount_pct": 5.0,
    "kia_incentives_rebates": 750.0,
    "v3_rebates_note": "$750 Kia Owner Loyalty OR $750 Competitive Bonus Cash (plus $500 Military if applicable)",
    "true_deal_score_targets": {
        "stage_1_in_transit_lock": "-$500 to -$850",
        "stage_2_dec_lot_raid": "-$1,400 to -$2,200",
    },
    "sources": [
        "Reddit r/KiaTelluride '2027 Hybrid Prices Paid & OTD' Megathread (NJ/NY/PA buyers)",
        "Leasehackr Signed! Deals & Northeast Tri-State Auto Broker Spreadsheets",
        "Edmunds 2027 Kia Telluride Hybrid Invoice / MF / RV Forums (ZIP 07724)",
        "TrueCar / KBB Monmouth County NJ Hybrid Market Average Transaction Data",
    ],
    "market_intel_notes": (
        "Two-Stage Squeeze (Monmouth & Ocean County, NJ): Stage 1 (Oct/Nov In-Transit Reserve) targets $1,300–$1,600 off MSRP "
        "with $0 add-ons, a 100% refundable $500 credit card deposit, and a Pre-PDI 'No Add-Ons' directive. "
        "Stage 2 (Dec 18–28 Year-End Lot Raid) raids physical on-lot inventory down to $2,200–$3,000 off MSRP (invoice + holdback)."
    ),
    "trims": {
        "2027 Kia Telluride Hybrid SX X-Line": {
            "priority_rank": 1,
            "msrp": 56035.0,
            "invoice_price": 53906.0,
            "holdback_amount": 1121.0,
            "allowed_non_black_interiors": ["Saddle Brown & Millstone", "Black & Millstone"],
            "stage_1_target_off_msrp": "$1,300 – $1,500 off MSRP",
            "stage_2_target_off_msrp": "$2,200 – $2,600 off MSRP",
            "prevailing_discount_pct": 3.8,
            "prevailing_selling_price": 53906.0,
            "stretch_target_discount_pct": 5.0,
            "stretch_counter_selling_price": 53233.0,
        },
        "2027 Kia Telluride Hybrid SX Prestige": {
            "priority_rank": 2,
            "msrp": 58135.0,
            "invoice_price": 55926.0,
            "holdback_amount": 1163.0,
            "allowed_non_black_interiors": ["Deep Navy & Tuscan Umber (Exclusive to non-X-Line)"],
            "stage_1_target_off_msrp": "$1,400 – $1,600 off MSRP",
            "stage_2_target_off_msrp": "$2,300 – $2,800 off MSRP",
            "prevailing_discount_pct": 3.8,
            "prevailing_selling_price": 55926.0,
            "stretch_target_discount_pct": 5.0,
            "stretch_counter_selling_price": 55228.0,
        },
        "2027 Kia Telluride Hybrid SX Prestige X-Line": {
            "priority_rank": 3,
            "msrp": 59135.0,
            "invoice_price": 56888.0,
            "holdback_amount": 1183.0,
            "allowed_non_black_interiors": ["Black & Millstone (No brown/umber built on this trim)"],
            "stage_1_target_off_msrp": "$1,400 – $1,600 off MSRP",
            "stage_2_target_off_msrp": "$2,400 – $3,000 off MSRP",
            "prevailing_discount_pct": 3.8,
            "prevailing_selling_price": 56888.0,
            "stretch_target_discount_pct": 5.0,
            "stretch_counter_selling_price": 56178.0,
        },
    },
}


@instrument_tool
def get_prevailing_market_benchmark(
    trim_level: str = "2027 Kia Telluride Hybrid SX X-Line",
    msrp: float = 0.0,
) -> Dict[str, Any]:
    """Retrieves the prevailing NJ market deal benchmark (Invoice, Holdback, Prevailing Comp, Stretch Target).

    Args:
        trim_level (str): Target 2027 Kia Telluride Hybrid trim name (e.g. '2027 Kia Telluride Hybrid SX X-Line',
            '2027 Kia Telluride Hybrid SX Prestige', or '2027 Kia Telluride Hybrid SX Prestige X-Line').
        msrp (float): Optional vehicle sticker MSRP in USD (if 0.0, uses the trim's standard base MSRP).

    Returns:
        Dict[str, Any]: Market benchmark dictionary containing `estimated_invoice_price`, `dealer_holdback_amount`,
            `true_dealer_dead_cost_net_holdback`, `prevailing_market_selling_price`, and `stretch_counter_selling_price`.
    """
    if msrp < 0:
        return build_guided_error(
            error_code="INVALID_MSRP",
            message=f"msrp={msrp} cannot be negative.",
            recovery_instructions="Pass msrp=0.0 to use the trim's default MSRP, or a positive USD value like 53890.0.",
            invalid_fields={"msrp": msrp},
        )

    state = load_state()
    camp_id = state.get("active_campaign_id")
    campaign = state.get("campaigns", {}).get(camp_id, {})
    bench = campaign.get("market_benchmark") or DEFAULT_MARKET_BENCHMARK

    trims_map = bench.get("trims", DEFAULT_MARKET_BENCHMARK["trims"])
    matched_trim = trims_map.get(trim_level)

    if not matched_trim:
        for k, v in trims_map.items():
            if k.lower() in trim_level.lower() or trim_level.lower() in k.lower():
                matched_trim = v
                trim_level = k
                break

    invoice_pct = float(bench.get("invoice_below_msrp_pct", 3.8))
    holdback_pct = float(bench.get("dealer_holdback_pct", 2.0))
    prevailing_pct = float(
        matched_trim.get("prevailing_discount_pct")
        if matched_trim
        else bench.get("prevailing_market_discount_pct", 3.8)
    )
    stretch_pct = float(
        matched_trim.get("stretch_target_discount_pct")
        if matched_trim
        else bench.get("stretch_target_discount_pct", 5.0)
    )

    effective_msrp = (
        float(msrp)
        if msrp > 0
        else float(matched_trim["msrp"] if matched_trim else 53890.0)
    )
    invoice_price = round(effective_msrp * (1.0 - invoice_pct / 100.0), 2)
    holdback_amt = round(effective_msrp * (holdback_pct / 100.0), 2)
    dealer_dead_cost = round(invoice_price - holdback_amt, 2)
    prevailing_selling = round(effective_msrp * (1.0 - prevailing_pct / 100.0), 2)
    stretch_selling = round(effective_msrp * (1.0 - stretch_pct / 100.0), 2)

    return {
        "trim_level": trim_level,
        "zip_code": campaign.get("zip_code") or bench.get("zip_code", "07724"),
        "region": bench.get("region", DEFAULT_MARKET_BENCHMARK["region"]),
        "powertrain_requirement": DEFAULT_MARKET_BENCHMARK["powertrain_requirement"],
        "msrp": effective_msrp,
        "invoice_below_msrp_pct": invoice_pct,
        "estimated_invoice_price": invoice_price,
        "dealer_holdback_pct": holdback_pct,
        "dealer_holdback_amount": holdback_amt,
        "true_dealer_dead_cost_net_holdback": dealer_dead_cost,
        "prevailing_market_discount_pct": prevailing_pct,
        "prevailing_market_selling_price": prevailing_selling,
        "stretch_target_discount_pct": stretch_pct,
        "stretch_counter_selling_price": stretch_selling,
        "kia_incentives_rebates": float(bench.get("kia_incentives_rebates", 500.0)),
        "market_intel_notes": bench.get(
            "market_intel_notes", DEFAULT_MARKET_BENCHMARK["market_intel_notes"]
        ),
        "sources": bench.get("sources", DEFAULT_MARKET_BENCHMARK["sources"]),
    }


@instrument_tool
def update_market_benchmark(
    prevailing_market_discount_pct: float = 3.8,
    stretch_target_discount_pct: float = 5.0,
    invoice_below_msrp_pct: float = 3.8,
    dealer_holdback_pct: float = 2.0,
    kia_incentives_rebates: float = 500.0,
    market_intel_notes: str = "",
) -> Dict[str, Any]:
    """Updates the campaign's prevailing market deal benchmark and recalculates target prices across all Hybrid trims.

    Args:
        prevailing_market_discount_pct (float): Prevailing NJ market discount percentage below MSRP (e.g. 4.5 for 4.5%).
        stretch_target_discount_pct (float): Top-decile stretch counter target percentage below MSRP (e.g. 6.0 for 6.0%).
        invoice_below_msrp_pct (float): Factory dealer invoice percentage below MSRP (default 3.8).
        dealer_holdback_pct (float): Manufacturer dealer holdback percentage of MSRP (default 2.0).
        kia_incentives_rebates (float): Applicable manufacturer rebates or lease cash in USD (default 500.0).
        market_intel_notes (str): Summary notes of new market intelligence or comp sources.

    Returns:
        Dict[str, Any]: Updated market benchmark configuration with recalculated target prices for all 3 Hybrid trims.
    """
    _, guided_err = validate_tool_input(
        schema_cls=MarketBenchmarkUpdateInputSchema,
        raw_kwargs={
            "prevailing_market_discount_pct": prevailing_market_discount_pct,
            "stretch_target_discount_pct": stretch_target_discount_pct,
            "invoice_below_msrp_pct": invoice_below_msrp_pct,
            "dealer_holdback_pct": dealer_holdback_pct,
            "kia_incentives_rebates": kia_incentives_rebates,
            "market_intel_notes": market_intel_notes,
        },
        tool_name="update_market_benchmark",
        recovery_hint=(
            "Ensure discount percentages (`prevailing_market_discount_pct`, `stretch_target_discount_pct`) are between "
            "0.0 and 30.0 (e.g. 4.5 for 4.5% off MSRP) and `kia_incentives_rebates` is a non-negative USD amount."
        ),
    )
    if guided_err is not None:
        return guided_err

    state = load_state()
    camp_id = state.get("active_campaign_id") or "camp-2027-kia-telluride-hybrid-nj"
    campaign = state.get("campaigns", {}).get(camp_id, {})

    new_bench = {
        **DEFAULT_MARKET_BENCHMARK,
        **(campaign.get("market_benchmark") or {}),
        "invoice_below_msrp_pct": round(float(invoice_below_msrp_pct), 2),
        "dealer_holdback_pct": round(float(dealer_holdback_pct), 2),
        "prevailing_market_discount_pct": round(
            float(prevailing_market_discount_pct), 2
        ),
        "stretch_target_discount_pct": round(float(stretch_target_discount_pct), 2),
        "kia_incentives_rebates": round(float(kia_incentives_rebates), 2),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    if market_intel_notes.strip():
        new_bench["market_intel_notes"] = market_intel_notes.strip()

    updated_trims = {}
    for trim_name, t_info in DEFAULT_MARKET_BENCHMARK["trims"].items():
        t_msrp = float(t_info["msrp"])
        inv_price = round(t_msrp * (1.0 - invoice_below_msrp_pct / 100.0), 0)
        hb_amt = round(t_msrp * (dealer_holdback_pct / 100.0), 0)
        prev_price = round(t_msrp * (1.0 - prevailing_market_discount_pct / 100.0), 0)
        stretch_price = round(t_msrp * (1.0 - stretch_target_discount_pct / 100.0), 0)
        updated_trims[trim_name] = {
            "priority_rank": t_info["priority_rank"],
            "msrp": t_msrp,
            "invoice_price": inv_price,
            "holdback_amount": hb_amt,
            "prevailing_discount_pct": round(float(prevailing_market_discount_pct), 2),
            "prevailing_selling_price": prev_price,
            "stretch_target_discount_pct": round(float(stretch_target_discount_pct), 2),
            "stretch_counter_selling_price": stretch_price,
        }

    new_bench["trims"] = updated_trims
    campaign["market_benchmark"] = new_bench
    upsert_document("negotiation_campaigns", camp_id, campaign)

    state = load_state()
    for d_id, lead in state.get("dealer_leads", {}).items():
        d_msrp = float(lead.get("msrp", 53890.0))
        lead["invoice_price"] = round(d_msrp * (1.0 - invoice_below_msrp_pct / 100.0), 0)
        lead["prevailing_market_selling_price"] = round(
            d_msrp * (1.0 - prevailing_market_discount_pct / 100.0), 0
        )
        lead["recommended_counter_selling_price"] = round(
            d_msrp * (1.0 - stretch_target_discount_pct / 100.0), 0
        )
        upsert_document("dealer_leads", d_id, lead)

    return new_bench
