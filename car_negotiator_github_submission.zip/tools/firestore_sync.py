"""
Firestore & Local Real-Time State Synchronization Layer.

Syncs negotiation campaigns, competing dealer leads/quotes, Copilot approval queues, and
persistent conversational sessions to both Cloud Firestore (or Firebase Firestore Emulator
on port 8080) and a local JSON store (`data/negotiation_state.json`).
"""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import socket
import threading
from typing import Any, Dict, List, Optional
import urllib.error
import urllib.parse
import urllib.request

from .observability import log_structured_event, start_trace_span
from .secret_manager import get_secret

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = str(BASE_DIR / "data")
STATE_FILE = str(BASE_DIR / "data" / "negotiation_state.json")

DEFAULT_PROJECT_ID = os.environ.get("FIRESTORE_PROJECT_ID", "agy-sandbox-22ebe")
DEFAULT_EMULATOR_HOST = os.environ.get("FIRESTORE_EMULATOR_HOST", "localhost:8080")

_STATE_LOCK = threading.RLock()


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _default_state() -> Dict[str, Any]:
    return {
        "campaigns": {},
        "dealer_leads": {},
        "message_queue": {},
        "chat_sessions": {},
        "memory_digests": {},
        "active_campaign_id": None,
        "updated_at": _utc_now_iso(),
    }


def load_state(hydrate_from_firestore_if_missing: bool = False) -> Dict[str, Any]:
    """Loads the current negotiation state from local JSON storage (with optional Firestore hydration).

    Args:
        hydrate_from_firestore_if_missing (bool): If True and local state file does not exist,
            attempts to pull active campaign state from Cloud Firestore / Emulator.

    Returns:
        Dict[str, Any]: Current negotiation state dictionary.
    """
    with _STATE_LOCK:
        os.makedirs(DATA_DIR, exist_ok=True)
        if not os.path.exists(STATE_FILE):
            state = _default_state()
            if hydrate_from_firestore_if_missing:
                remote_camp = fetch_doc_from_firestore(
                    "negotiation_campaigns", "camp-2027-kia-telluride-hybrid-nj"
                )
                if remote_camp:
                    state["campaigns"][remote_camp["id"]] = remote_camp
                    state["active_campaign_id"] = remote_camp["id"]
            save_state(state)
            return state
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                for key in (
                    "campaigns",
                    "dealer_leads",
                    "message_queue",
                    "chat_sessions",
                    "memory_digests",
                ):
                    if key not in data:
                        data[key] = {}
                return data
        except Exception as exc:
            log_structured_event(
                event_type="STATE_LOAD_ERROR",
                message=f"Failed to read local state file, returning default state: {exc}",
                severity="WARNING",
                component="firestore_sync",
            )
            return _default_state()


def save_state(state: Dict[str, Any]) -> None:
    """Persists the negotiation state atomically to local JSON storage.

    Args:
        state (Dict[str, Any]): Full negotiation state dictionary to persist.

    Returns:
        None
    """
    with _STATE_LOCK:
        os.makedirs(DATA_DIR, exist_ok=True)
        state["updated_at"] = _utc_now_iso()
        tmp_path = f"{STATE_FILE}.{threading.get_ident()}.tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2)
        os.replace(tmp_path, STATE_FILE)


def _to_firestore_value(val: Any) -> Dict[str, Any]:
    """Converts a Python value into Firestore REST API Value representation.

    Args:
        val (Any): Python primitive, list, or dictionary.

    Returns:
        Dict[str, Any]: Firestore REST Value object.
    """
    if val is None:
        return {"nullValue": None}
    if isinstance(val, bool):
        return {"booleanValue": val}
    if isinstance(val, int):
        return {"integerValue": str(val)}
    if isinstance(val, float):
        return {"doubleValue": val}
    if isinstance(val, str):
        return {"stringValue": val}
    if isinstance(val, list):
        return {"arrayValue": {"values": [_to_firestore_value(v) for v in val]}}
    if isinstance(val, dict):
        return {
            "mapValue": {
                "fields": {str(k): _to_firestore_value(v) for k, v in val.items()}
            }
        }
    return {"stringValue": str(val)}


def _from_firestore_value(val_obj: Dict[str, Any]) -> Any:
    """Converts a Firestore REST API Value object back into a native Python value.

    Args:
        val_obj (Dict[str, Any]): Firestore REST Value dictionary.

    Returns:
        Any: Decoded Python value.
    """
    if "nullValue" in val_obj:
        return None
    if "booleanValue" in val_obj:
        return bool(val_obj["booleanValue"])
    if "integerValue" in val_obj:
        return int(val_obj["integerValue"])
    if "doubleValue" in val_obj:
        return float(val_obj["doubleValue"])
    if "stringValue" in val_obj:
        return str(val_obj["stringValue"])
    if "arrayValue" in val_obj:
        values = val_obj["arrayValue"].get("values", [])
        return [_from_firestore_value(v) for v in values]
    if "mapValue" in val_obj:
        fields = val_obj["mapValue"].get("fields", {})
        return {k: _from_firestore_value(v) for k, v in fields.items()}
    return None


def _to_firestore_doc(doc_dict: Dict[str, Any]) -> Dict[str, Any]:
    return {"fields": {str(k): _to_firestore_value(v) for k, v in doc_dict.items()}}


def _from_firestore_doc(raw_doc: Dict[str, Any]) -> Dict[str, Any]:
    fields = raw_doc.get("fields", {})
    return {k: _from_firestore_value(v) for k, v in fields.items()}


def _is_host_port_open(host_port: str) -> bool:
    try:
        host, port_s = host_port.split(":", 1)
        with socket.create_connection((host, int(port_s)), timeout=0.05):
            return True
    except Exception:
        return False


def _build_firestore_urls(collection: str, doc_id: str) -> List[str]:
    project_id = get_secret("FIRESTORE_PROJECT_ID", default=DEFAULT_PROJECT_ID)
    emulator_host = os.environ.get("FIRESTORE_EMULATOR_HOST", DEFAULT_EMULATOR_HOST)

    safe_doc_id = urllib.parse.quote(str(doc_id), safe="")
    base_path = f"/v1/projects/{project_id}/databases/(default)/documents/{collection}/{safe_doc_id}"

    urls: List[str] = []
    if emulator_host and _is_host_port_open(emulator_host):
        urls.append(f"http://{emulator_host}{base_path}")
    api_key = get_secret("FIREBASE_WEB_API_KEY", default="")
    if api_key:
        urls.append(f"https://firestore.googleapis.com{base_path}?key={api_key}")
    return urls


def sync_doc_to_firestore(collection: str, doc_id: str, data: Dict[str, Any]) -> bool:
    """Pushes a document to the Firestore Emulator (port 8080) or Cloud Firestore REST API.

    Args:
        collection (str): Target Firestore collection name.
        doc_id (str): Document ID.
        data (Dict[str, Any]): Document dictionary to serialize and PATCH.

    Returns:
        bool: True if synced to Firestore or Emulator, False if offline/unavailable.
    """
    urls = _build_firestore_urls(collection, doc_id)
    if not urls:
        return False

    with start_trace_span(
        "firestore.sync_doc",
        attributes={"firestore.collection": collection, "firestore.doc_id": doc_id},
    ):
        payload_bytes = json.dumps(_to_firestore_doc(data)).encode("utf-8")
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

        for url in urls:
            try:
                req = urllib.request.Request(
                    url,
                    data=payload_bytes,
                    headers={"Content-Type": "application/json"},
                    method="PATCH",
                )
                with opener.open(req, timeout=0.4) as resp:
                    if 200 <= resp.status < 300:
                        return True
            except Exception as exc:
                log_structured_event(
                    event_type="FIRESTORE_SYNC_RETRY",
                    message=f"Firestore PATCH fallback for {collection}/{doc_id}: {exc}",
                    severity="DEBUG",
                    component="firestore_sync",
                )
                continue
        return False


def fetch_doc_from_firestore(
    collection: str, doc_id: str
) -> Optional[Dict[str, Any]]:
    """Retrieves a document from the Firestore Emulator or Cloud Firestore REST API.

    Args:
        collection (str): Firestore collection name.
        doc_id (str): Document identifier.

    Returns:
        Optional[Dict[str, Any]]: Decoded Python dictionary if found, or None if offline/not found.
    """
    urls = _build_firestore_urls(collection, doc_id)
    if not urls:
        return None

    with start_trace_span(
        "firestore.fetch_doc",
        attributes={"firestore.collection": collection, "firestore.doc_id": doc_id},
    ):
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for url in urls:
            try:
                req = urllib.request.Request(url, method="GET")
                with opener.open(req, timeout=0.4) as resp:
                    if 200 <= resp.status < 300:
                        raw_json = json.loads(resp.read().decode("utf-8"))
                        return _from_firestore_doc(raw_json)
            except Exception:
                continue
        return None


def submit_async_firestore_sync(
    collection: str, doc_id: str, data: Dict[str, Any]
) -> bool:
    """Synchronizes a document to Firestore and returns completion status.

    Args:
        collection (str): Target Firestore collection.
        doc_id (str): Target document ID.
        data (Dict[str, Any]): Snapshot of document data to sync.

    Returns:
        bool: True if remote sync succeeded, False otherwise.
    """
    return sync_doc_to_firestore(collection, doc_id, dict(data))


def flush_async_persistence_queue(timeout: float = 2.0) -> int:
    """No-op compatibility helper for synchronous local + Firestore persistence.

    Args:
        timeout (float): Unused timeout parameter retained for signature compatibility.

    Returns:
        int: 0 (all writes complete atomically in-process).
    """
    return 0


def upsert_document(
    collection: str,
    doc_id: str,
    data: Dict[str, Any],
    async_remote_sync: bool = False,
) -> Dict[str, Any]:
    """Saves a document atomically in local state and syncs it to Firestore.

    Args:
        collection (str): Collection name ('negotiation_campaigns', 'dealer_leads', 'message_queue', 'chat_sessions').
        doc_id (str): Unique document identifier.
        data (Dict[str, Any]): Document dictionary to persist.
        async_remote_sync (bool): Retained for signature compatibility.

    Returns:
        Dict[str, Any]: Saved document dictionary with `id`, `updated_at`, and `_firestore_synced` metadata.
    """
    state_key_map = {
        "negotiation_campaigns": "campaigns",
        "dealer_leads": "dealer_leads",
        "message_queue": "message_queue",
        "chat_sessions": "chat_sessions",
        "memory_digests": "memory_digests",
    }
    bucket = state_key_map.get(collection, collection)

    with _STATE_LOCK:
        state = load_state()
        if bucket not in state:
            state[bucket] = {}

        data["id"] = doc_id
        data["updated_at"] = _utc_now_iso()
        state[bucket][doc_id] = data
        if collection == "negotiation_campaigns":
            state["active_campaign_id"] = doc_id

        save_state(state)

    firestore_synced = sync_doc_to_firestore(collection, doc_id, data)
    data["_firestore_synced"] = firestore_synced
    return data


def async_upsert_document(
    collection: str,
    doc_id: str,
    data: Dict[str, Any],
) -> Dict[str, Any]:
    """Persists a document to local state and Firestore.

    Args:
        collection (str): Collection name ('negotiation_campaigns', 'dealer_leads', 'message_queue', 'chat_sessions').
        doc_id (str): Document ID.
        data (Dict[str, Any]): Document payload.

    Returns:
        Dict[str, Any]: Updated document dictionary with `id`, `updated_at`, and `_firestore_synced`.
    """
    return upsert_document(collection, doc_id, data)
