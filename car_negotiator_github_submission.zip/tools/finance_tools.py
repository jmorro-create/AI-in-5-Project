"""
Deterministic Automotive Financial & Quote Auditing Engine.

Provides:
1. Exact Out-The-Door (OTD) purchase calculations (`calculate_otd_price`)
2. Reverse OTD-to-Monthly Payment Calculator (`calculate_monthly_from_otd`) — works backward from an OTD price
   to derive the implied Vehicle Selling Price (Cap Cost) and exact Monthly Finance & Lease payments
3. Lease worksheet calculations (`calculate_lease_payment`)
4. Prevailing market comp benchmarking & hidden dealer markup auditing (`audit_dealer_quote`)
5. Zero Scarcity Tax Color-Parity Calculator (`calculate_color_parity_benchmark`)
6. Two-Stage Affirmative Trade-In & Post-OTD Lock Shell-Game Auditor (`calculate_trade_in_impact`).

All tools enforce strict Pydantic input/output schemas, guided LLM error recovery instructions,
OpenTelemetry distributed tracing, and Intent-vs-Outcome structured JSON logging.
"""

from typing import Any, Dict, Optional

from .observability import instrument_tool
from .schemas import (
    AuditDealerQuoteInputSchema,
    AuditUploadedLeaseSheetInputSchema,
    CalculateNJPaymentsInputSchema,
    LeaseCalculationInputSchema,
    OTDCalculationInputSchema,
    OTDCalculationOutputSchema,
    ReverseOTDInputSchema,
    validate_tool_input,
)


@instrument_tool
def calculate_otd_price(
    msrp: float,
    selling_price: float,
    doc_fee: float = 499.0,
    gov_fees: float = 385.0,
    tax_rate_percent: float = 6.625,
    dealer_addons_total: float = 0.0,
    rebates: float = 0.0,
    addon_descriptions: str = "",
    prevailing_market_discount_pct: float = 3.8,
    stretch_counter_discount_pct: float = 5.0,
    invoice_below_msrp_pct: float = 3.8,
) -> Dict[str, Any]:
    """Calculates the exact Out-The-Door (OTD) purchase price, compares against prevailing market deals, and flags junk fees.

    Args:
        msrp (float): Vehicle sticker MSRP in USD (e.g., 53890.0 for 2027 Kia Telluride Hybrid SX X-Line).
        selling_price (float): Dealer quoted or target vehicle selling price before taxes and fees in USD.
        doc_fee (float): Dealer documentation fee in USD (default 499.0 for NJ).
        gov_fees (float): Non-taxable government MVC registration, title, and tire fees in USD (default 385.0 for NJ).
        tax_rate_percent (float): State sales tax percentage (default 6.625 for New Jersey; pass 6.625, not 0.06625).
        dealer_addons_total (float): Total cost of dealer-installed add-ons (tint, VIN etch, LoJack) in USD.
        rebates (float): Manufacturer rebates and incentives deducted from taxable base in USD.
        addon_descriptions (str): Comma-separated names of dealer add-ons.
        prevailing_market_discount_pct (float): Prevailing market discount percentage below MSRP (default 3.8%).
        stretch_counter_discount_pct (float): Top-decile stretch counter target discount percentage below MSRP (default 5.0%).
        invoice_below_msrp_pct (float): Estimated dealer invoice percentage below MSRP (default 3.8%).

    Returns:
        Dict[str, Any]: Validated OTD breakdown dictionary including `otd_total`, `sales_tax`, `discount_off_msrp`,
            `discount_pct`, `clean_otd_without_addons`, `potential_addon_savings`, and `red_flags`.
    """
    validated, guided_err = validate_tool_input(
        schema_cls=OTDCalculationInputSchema,
        raw_kwargs={
            "msrp": msrp,
            "selling_price": selling_price,
            "doc_fee": doc_fee,
            "gov_fees": gov_fees,
            "tax_rate_percent": tax_rate_percent,
            "dealer_addons_total": dealer_addons_total,
            "rebates": rebates,
            "addon_descriptions": addon_descriptions,
            "prevailing_market_discount_pct": prevailing_market_discount_pct,
            "stretch_counter_discount_pct": stretch_counter_discount_pct,
            "invoice_below_msrp_pct": invoice_below_msrp_pct,
        },
        tool_name="calculate_otd_price",
        recovery_hint=(
            "Ensure `msrp` and `selling_price` are positive USD amounts (e.g. msrp=53890.0, selling_price=51842.0) "
            "and `tax_rate_percent` is passed as percentage points (e.g. 6.625 for 6.625% NJ tax, NOT 0.06625)."
        ),
    )
    if guided_err is not None:
        return guided_err

    discount_off_msrp = round(msrp - selling_price, 2)
    discount_pct = round((discount_off_msrp / msrp) * 100.0, 2) if msrp > 0 else 0.0

    estimated_invoice_price = round(msrp * (1.0 - invoice_below_msrp_pct / 100.0), 2)
    prevailing_market_selling_price = round(
        msrp * (1.0 - prevailing_market_discount_pct / 100.0), 2
    )
    stretch_target_selling_price = round(
        msrp * (1.0 - stretch_counter_discount_pct / 100.0), 2
    )
    vs_prevailing_market_dollars = round(
        selling_price - prevailing_market_selling_price, 2
    )

    taxable_base = max(0.0, selling_price + doc_fee + dealer_addons_total - rebates)
    sales_tax = round(taxable_base * (tax_rate_percent / 100.0), 2)
    otd_total = round(
        selling_price + doc_fee + dealer_addons_total + gov_fees + sales_tax - rebates,
        2,
    )

    clean_tax = round(
        max(0.0, selling_price + min(doc_fee, 499.0) - rebates)
        * (tax_rate_percent / 100.0),
        2,
    )
    clean_otd_without_addons = round(
        selling_price + min(doc_fee, 499.0) + gov_fees + clean_tax - rebates,
        2,
    )

    red_flags = []
    if dealer_addons_total > 0:
        label = f" ({addon_descriptions})" if addon_descriptions else ""
        red_flags.append(
            f"Dealer-installed add-ons of ${dealer_addons_total:,.2f}{label} should be removed."
        )
    if doc_fee > 549:
        red_flags.append(
            f"High NJ Doc Fee (${doc_fee:,.2f}). Request an equivalent reduction in selling price to offset."
        )
    if selling_price > msrp:
        red_flags.append(
            f"Market adjustment / markup of ${selling_price - msrp:,.2f} over MSRP detected."
        )
    elif vs_prevailing_market_dollars > 150:
        red_flags.append(
            f"Above Prevailing NJ Market Comp: Quoted ${selling_price:,.0f} ({discount_pct}% off) is ${vs_prevailing_market_dollars:,.0f} higher than current prevailing NJ deals (${prevailing_market_selling_price:,.0f} / {prevailing_market_discount_pct}% off MSRP). Counter at ${stretch_target_selling_price:,.0f} ({stretch_counter_discount_pct}% off)."
        )

    out_model = OTDCalculationOutputSchema(
        deal_type="PURCHASE",
        msrp=round(msrp, 2),
        selling_price=round(selling_price, 2),
        discount_off_msrp=discount_off_msrp,
        discount_pct=discount_pct,
        estimated_invoice_price=estimated_invoice_price,
        prevailing_market_discount_pct=prevailing_market_discount_pct,
        prevailing_market_selling_price=prevailing_market_selling_price,
        stretch_counter_discount_pct=stretch_counter_discount_pct,
        target_selling_price=stretch_target_selling_price,
        vs_prevailing_market_dollars=vs_prevailing_market_dollars,
        rebates=round(rebates, 2),
        doc_fee=round(doc_fee, 2),
        gov_fees=round(gov_fees, 2),
        dealer_addons_total=round(dealer_addons_total, 2),
        addon_descriptions=addon_descriptions,
        tax_rate_percent=tax_rate_percent,
        sales_tax=sales_tax,
        otd_total=otd_total,
        clean_otd_without_addons=clean_otd_without_addons,
        potential_addon_savings=round(otd_total - clean_otd_without_addons, 2),
        red_flags=red_flags,
    )
    return out_model.model_dump()


def _loan_monthly_payment(principal: float, apr_percent: float, months: int) -> float:
    if principal <= 0 or months <= 0:
        return 0.0
    if apr_percent <= 0:
        return round(principal / months, 2)
    r = (apr_percent / 100.0) / 12.0
    factor = (r * ((1.0 + r) ** months)) / (((1.0 + r) ** months) - 1.0)
    return round(principal * factor, 2)


@instrument_tool
def calculate_monthly_from_otd(
    otd_price: float,
    msrp: float = 53890.0,
    tax_rate_percent: float = 6.625,
    doc_fee: float = 499.0,
    gov_fees: float = 385.0,
    rebates: float = 500.0,
    cash_down_or_trade_equity: float = 0.0,
    loan_apr_percent: float = 4.9,
    loan_term_months: int = 60,
    lease_term_months: int = 36,
    lease_annual_miles: int = 12000,
    residual_percent: float = 63.0,
    money_factor: float = 0.00190,
    acquisition_fee: float = 650.0,
) -> Dict[str, Any]:
    """Works backward from a negotiated Out-The-Door (OTD) price to compute the buyer's monthly finance & lease payments.

    Why this tool is essential:
    The agent negotiates strictly on the Out-The-Door (OTD) price with the dealership so the dealer cannot
    play monthly-payment shell games. This function works backward from that OTD price to show the buyer:
    1. The exact Implied Vehicle Selling Price (Cap Cost) and Discount off MSRP inside that OTD figure.
    2. The exact Monthly Finance Payment (for 48, 60, 72 months) based on that OTD price.
    3. The exact Monthly Lease Payment (for 24, 36, 39 months) using the Implied Selling Price (Cap Cost)
       derived backward from that OTD price.

    Args:
        otd_price (float): The negotiated or target Out-The-Door (OTD) total price in USD.
        msrp (float): Vehicle MSRP sticker price in USD (e.g. 53890.0 for 2027 Telluride Hybrid SX X-Line).
        tax_rate_percent (float): Sales tax rate percentage (default 6.625 for NJ).
        doc_fee (float): Dealer documentation fee included in OTD in USD.
        gov_fees (float): Non-taxable government MVC registration/title fees included in OTD in USD.
        rebates (float): Manufacturer rebates applied in USD.
        cash_down_or_trade_equity (float): Optional cash down or post-lock trade equity applied at signing in USD.
        loan_apr_percent (float): Annual Percentage Rate (APR) for financing purchase.
        loan_term_months (int): Primary loan term in months (e.g. 60).
        lease_term_months (int): Primary lease term in months (e.g. 36).
        lease_annual_miles (int): Annual lease mileage allowance (e.g. 12000).
        residual_percent (float): Lease residual value percentage of MSRP (default 63.0 for Telluride Hybrid).
        money_factor (float): Lease buy-rate money factor (default 0.00190 = 4.56% APR).
        acquisition_fee (float): Captive bank lease acquisition fee in USD (default 650.0 for Kia Finance).

    Returns:
        Dict[str, Any]: Reverse OTD decomposition, implied selling price/discount, and monthly finance & lease payment schedules.
    """
    _, guided_err = validate_tool_input(
        schema_cls=ReverseOTDInputSchema,
        raw_kwargs={
            "otd_price": otd_price,
            "msrp": msrp,
            "tax_rate_percent": tax_rate_percent,
            "doc_fee": doc_fee,
            "gov_fees": gov_fees,
            "rebates": rebates,
            "cash_down_or_trade_equity": cash_down_or_trade_equity,
            "loan_apr_percent": loan_apr_percent,
            "loan_term_months": loan_term_months,
            "lease_term_months": lease_term_months,
            "lease_annual_miles": lease_annual_miles,
            "residual_percent": residual_percent,
            "money_factor": money_factor,
            "acquisition_fee": acquisition_fee,
        },
        tool_name="calculate_monthly_from_otd",
        recovery_hint=(
            "Pass `otd_price` and `msrp` as positive USD amounts (e.g. otd_price=54878.0, msrp=53890.0), "
            "`residual_percent` as percentage points (e.g. 62.0, NOT 0.62), and `money_factor` as a lease factor (e.g. 0.00190)."
        ),
    )
    if guided_err is not None:
        return guided_err

    tax_mult = 1.0 + (tax_rate_percent / 100.0)
    implied_taxable_base = max(0.0, (otd_price - gov_fees) / tax_mult)
    implied_sales_tax = round((otd_price - gov_fees) - implied_taxable_base, 2)
    implied_selling_price = round(implied_taxable_base - doc_fee + rebates, 2)
    implied_discount_dollars = round(msrp - implied_selling_price, 2)
    implied_discount_pct = (
        round((implied_discount_dollars / msrp) * 100.0, 2) if msrp > 0 else 0.0
    )

    amount_financed = max(0.0, round(otd_price - cash_down_or_trade_equity, 2))
    monthly_loan_selected = _loan_monthly_payment(
        amount_financed, loan_apr_percent, loan_term_months
    )
    monthly_loan_48 = _loan_monthly_payment(amount_financed, loan_apr_percent, 48)
    monthly_loan_60 = _loan_monthly_payment(amount_financed, loan_apr_percent, 60)
    monthly_loan_72 = _loan_monthly_payment(amount_financed, loan_apr_percent, 72)
    total_interest_selected = round(
        (monthly_loan_selected * loan_term_months) - amount_financed, 2
    )

    total_interest_48 = max(0.0, round((monthly_loan_48 * 48) - amount_financed, 2))
    total_interest_60 = max(0.0, round((monthly_loan_60 * 60) - amount_financed, 2))
    total_interest_72 = max(0.0, round((monthly_loan_72 * 72) - amount_financed, 2))

    lease_calc = calculate_lease_payment(
        msrp=msrp,
        selling_price=implied_selling_price,
        residual_percent=residual_percent,
        money_factor=money_factor,
        term_months=lease_term_months,
        annual_miles=lease_annual_miles,
        tax_rate_percent=tax_rate_percent,
        acquisition_fee=acquisition_fee,
        doc_fee=doc_fee,
        gov_fees=gov_fees,
        dealer_addons_total=0.0,
        rebates_and_lease_cash=rebates,
        cap_cost_reduction_down=cash_down_or_trade_equity,
        base_buy_rate_mf=money_factor,
    )

    rolled_cap_cost = round(
        implied_selling_price + doc_fee + gov_fees + acquisition_fee - rebates - cash_down_or_trade_equity,
        2,
    )
    residual_val = round(msrp * (residual_percent / 100.0), 2)
    rolled_dep = (rolled_cap_cost - residual_val) / max(1, lease_term_months)
    rolled_rent = (rolled_cap_cost + residual_val) * money_factor
    sign_and_drive_lease_monthly = round((rolled_dep + rolled_rent) * tax_mult, 2)

    breakdown_dict = {
        "otd_price": round(otd_price, 2),
        "msrp": round(msrp, 2),
        "implied_selling_price_cap_cost": implied_selling_price,
        "implied_discount_off_msrp": implied_discount_dollars,
        "implied_discount_pct": implied_discount_pct,
        "implied_taxable_base": round(implied_taxable_base, 2),
        "implied_sales_tax": implied_sales_tax,
        "estimated_sales_tax_included_in_otd": implied_sales_tax,
        "tax_rate_percent": tax_rate_percent,
        "doc_fee": round(doc_fee, 2),
        "gov_fees": round(gov_fees, 2),
        "rebates_applied": round(rebates, 2),
        "formula_explanation": (
            f"Worked backward from ${otd_price:,.2f} OTD: subtracted ${gov_fees:,.0f} NJ MVC fees -> "
            f"divided by {tax_mult:.5f} ({tax_rate_percent}% NJ tax) to get ${implied_taxable_base:,.2f} taxable base "
            f"(${implied_sales_tax:,.2f} NJ sales tax) -> subtracted ${doc_fee:,.0f} Doc Fee and added back ${rebates:,.0f} rebate "
            f"= ${implied_selling_price:,.2f} Implied Selling Price / Lease Cap Cost ({implied_discount_pct}% off ${msrp:,.0f} MSRP)."
        ),
    }

    total_loan_payments_selected = round(monthly_loan_selected * loan_term_months, 2)

    return {
        "otd_price_input": round(otd_price, 2),
        "msrp": round(msrp, 2),
        "reverse_otd_decomposition": breakdown_dict,
        "reverse_otd_breakdown": breakdown_dict,
        "finance_purchase_from_otd": {
            "amount_financed": amount_financed,
            "amount_financed_from_otd": amount_financed,
            "cash_down_or_trade_equity": round(cash_down_or_trade_equity, 2),
            "loan_apr_percent": loan_apr_percent,
            "selected_term_months": loan_term_months,
            "monthly_payment_selected": monthly_loan_selected,
            "monthly_loan_payment": monthly_loan_selected,
            "total_interest_selected": max(0.0, total_interest_selected),
            "total_interest_paid": max(0.0, total_interest_selected),
            "total_loan_payments": total_loan_payments_selected,
            "monthly_48mo": monthly_loan_48,
            "monthly_60mo": monthly_loan_60,
            "monthly_72mo": monthly_loan_72,
            "term_comparison_matrix": {
                "48_months": {"monthly_payment": monthly_loan_48, "total_interest": total_interest_48},
                "60_months": {"monthly_payment": monthly_loan_60, "total_interest": total_interest_60},
                "72_months": {"monthly_payment": monthly_loan_72, "total_interest": total_interest_72},
            },
        },
        "lease_from_otd_cap_cost": {
            "term_months": lease_term_months,
            "annual_miles": lease_annual_miles,
            "residual_percent": residual_percent,
            "residual_value": lease_calc["residual_value"],
            "money_factor": money_factor,
            "equivalent_apr": lease_calc["equivalent_apr"],
            "equivalent_apr_percent": lease_calc["equivalent_apr"],
            "monthly_depreciation": lease_calc["monthly_depreciation"],
            "monthly_rent_charge": lease_calc["monthly_rent_charge"],
            "base_monthly_payment": lease_calc["base_monthly_payment"],
            "monthly_tax": lease_calc["monthly_tax"],
            "monthly_sales_tax": lease_calc["monthly_tax"],
            "monthly_lease_payment_with_fees_upfront": lease_calc["total_monthly_payment"],
            "total_monthly_payment": lease_calc["total_monthly_payment"],
            "drive_off_due_at_signing": lease_calc["drive_off_due_at_signing"],
            "sign_and_drive_zero_due_monthly": sign_and_drive_lease_monthly,
            "effective_monthly_lease_cost": lease_calc["effective_monthly_cost"],
        },
    }


@instrument_tool
def calculate_lease_payment(
    msrp: float,
    selling_price: float,
    residual_percent: float,
    money_factor: float,
    term_months: int = 36,
    annual_miles: int = 12000,
    tax_rate_percent: float = 6.625,
    acquisition_fee: float = 650.0,
    doc_fee: float = 499.0,
    gov_fees: float = 385.0,
    dealer_addons_total: float = 0.0,
    rebates_and_lease_cash: float = 0.0,
    cap_cost_reduction_down: float = 0.0,
    base_buy_rate_mf: float = 0.00190,
) -> Dict[str, Any]:
    """Calculates exact monthly lease payments, drive-off total, APR equivalent, 1% Rule ratio, Leasehackr Score, and MF markup.

    Args:
        msrp (float): Vehicle sticker MSRP in USD (used to compute residual value).
        selling_price (float): Negotiated vehicle selling price (gross cap cost before add-ons) in USD.
        residual_percent (float): Residual value percentage of MSRP (e.g., 62.0 for 62%).
        money_factor (float): Quoted lease money factor (e.g., 0.00190; multiply by 2400 for APR %).
        term_months (int): Lease duration in months (default 36).
        annual_miles (int): Annual mileage allowance (default 12000).
        tax_rate_percent (float): Sales tax rate percentage (default 6.625 for NJ).
        acquisition_fee (float): Captive lease bank acquisition fee in USD (default 650.0 for KMF).
        doc_fee (float): Dealer documentation fee in USD (default 499.0).
        gov_fees (float): Government MVC registration/title fees in USD (default 385.0).
        dealer_addons_total (float): Total dealer-installed add-ons rolled into cap cost in USD.
        rebates_and_lease_cash (float): Manufacturer lease cash and rebates in USD.
        cap_cost_reduction_down (float): Upfront cash down cap cost reduction in USD.
        base_buy_rate_mf (float): Tier-1 captive bank buy-rate money factor (default 0.00190).

    Returns:
        Dict[str, Any]: Full lease payment breakdown including `total_monthly_payment`, `drive_off_due_at_signing`,
            `effective_monthly_cost`, `mf_markup_extra_cost`, `one_percent_rule_ratio`, `leasehackr_score_years`, and `red_flags`.
    """
    _, guided_err = validate_tool_input(
        schema_cls=LeaseCalculationInputSchema,
        raw_kwargs={
            "msrp": msrp,
            "selling_price": selling_price,
            "residual_percent": residual_percent,
            "money_factor": money_factor,
            "term_months": term_months,
            "annual_miles": annual_miles,
            "tax_rate_percent": tax_rate_percent,
            "acquisition_fee": acquisition_fee,
            "doc_fee": doc_fee,
            "gov_fees": gov_fees,
            "dealer_addons_total": dealer_addons_total,
            "rebates_and_lease_cash": rebates_and_lease_cash,
            "cap_cost_reduction_down": cap_cost_reduction_down,
            "base_buy_rate_mf": base_buy_rate_mf,
        },
        tool_name="calculate_lease_payment",
        recovery_hint=(
            "Ensure `msrp` and `selling_price` are positive USD amounts, `residual_percent` is between 20.0 and 90.0 "
            "(e.g. 62.0, NOT 0.62), and `money_factor` is between 0.0 and 0.02 (e.g. 0.00190)."
        ),
    )
    if guided_err is not None:
        return guided_err

    equivalent_apr = round(money_factor * 2400.0, 2)
    buy_rate_apr = round(base_buy_rate_mf * 2400.0, 2)
    residual_value = round(msrp * (residual_percent / 100.0), 2)

    gross_cap_cost = round(selling_price + dealer_addons_total, 2)
    adjusted_cap_cost = round(
        gross_cap_cost - rebates_and_lease_cash - cap_cost_reduction_down, 2
    )

    monthly_depreciation = round(
        (adjusted_cap_cost - residual_value) / max(1, term_months), 2
    )
    monthly_rent_charge = round(
        (adjusted_cap_cost + residual_value) * money_factor, 2
    )
    base_monthly_payment = round(monthly_depreciation + monthly_rent_charge, 2)
    monthly_tax = round(base_monthly_payment * (tax_rate_percent / 100.0), 2)
    total_monthly_payment = round(base_monthly_payment + monthly_tax, 2)

    upfront_tax = round(
        (cap_cost_reduction_down + rebates_and_lease_cash + doc_fee + acquisition_fee)
        * (tax_rate_percent / 100.0),
        2,
    )
    drive_off_due_at_signing = round(
        total_monthly_payment
        + acquisition_fee
        + doc_fee
        + gov_fees
        + cap_cost_reduction_down
        + upfront_tax,
        2,
    )

    total_lease_cost = round(
        drive_off_due_at_signing + (total_monthly_payment * max(0, term_months - 1)), 2
    )
    effective_monthly_cost = round(total_lease_cost / max(1, term_months), 2)

    clean_adj_cap = round(
        selling_price - rebates_and_lease_cash - cap_cost_reduction_down, 2
    )
    clean_dep = (clean_adj_cap - residual_value) / max(1, term_months)
    clean_rent = (clean_adj_cap + residual_value) * base_buy_rate_mf
    clean_monthly_with_tax = round(
        (clean_dep + clean_rent) * (1.0 + tax_rate_percent / 100.0), 2
    )

    mf_markup = round(max(0.0, money_factor - base_buy_rate_mf), 5)
    mf_extra_cost_total = round(
        ((adjusted_cap_cost + residual_value) * mf_markup)
        * term_months
        * (1.0 + tax_rate_percent / 100.0),
        2,
    )

    one_percent_ratio = (
        round((effective_monthly_cost / msrp) * 100.0, 2) if msrp > 0 else 0.0
    )
    leasehackr_years = (
        round(msrp / (effective_monthly_cost * 12.0), 1)
        if effective_monthly_cost > 0
        else 0.0
    )

    red_flags = []
    if mf_markup > 0.00005:
        red_flags.append(
            f"Money Factor marked up from {base_buy_rate_mf:.5f} ({buy_rate_apr}% APR) to {money_factor:.5f} ({equivalent_apr}% APR), costing an extra ${mf_extra_cost_total:,.2f} over {term_months} months."
        )
    if dealer_addons_total > 0:
        red_flags.append(
            f"Dealer add-ons (${dealer_addons_total:,.2f}) are rolled into Cap Cost; demand removal."
        )
    if cap_cost_reduction_down > 0:
        red_flags.append(
            f"Quote requires ${cap_cost_reduction_down:,.2f} cap cost reduction (down payment). Recommend $0 down (only first month + fees at signing)."
        )

    return {
        "deal_type": "LEASE",
        "msrp": round(msrp, 2),
        "selling_price": round(selling_price, 2),
        "discount_off_msrp": round(msrp - selling_price, 2),
        "discount_pct": round(((msrp - selling_price) / msrp) * 100.0, 2)
        if msrp > 0
        else 0.0,
        "residual_percent": residual_percent,
        "residual_value": residual_value,
        "money_factor": money_factor,
        "equivalent_apr": equivalent_apr,
        "base_buy_rate_mf": base_buy_rate_mf,
        "buy_rate_apr": buy_rate_apr,
        "mf_markup_extra_cost": mf_extra_cost_total,
        "term_months": term_months,
        "annual_miles": annual_miles,
        "gross_cap_cost": gross_cap_cost,
        "adjusted_cap_cost": adjusted_cap_cost,
        "rebates_and_lease_cash": round(rebates_and_lease_cash, 2),
        "cap_cost_reduction_down": round(cap_cost_reduction_down, 2),
        "monthly_depreciation": monthly_depreciation,
        "monthly_rent_charge": monthly_rent_charge,
        "base_monthly_payment": base_monthly_payment,
        "monthly_tax": monthly_tax,
        "total_monthly_payment": total_monthly_payment,
        "clean_monthly_at_buy_rate": clean_monthly_with_tax,
        "drive_off_due_at_signing": drive_off_due_at_signing,
        "total_lease_cost": total_lease_cost,
        "effective_monthly_cost": effective_monthly_cost,
        "one_percent_rule_ratio": one_percent_ratio,
        "leasehackr_score_years": leasehackr_years,
        "red_flags": red_flags,
    }


@instrument_tool
def audit_dealer_quote(
    deal_type: str,
    msrp: float,
    selling_price: float,
    dealer_quoted_otd: Optional[float] = 0.0,
    dealer_quoted_monthly: Optional[float] = 0.0,
    dealer_quoted_drive_off: Optional[float] = 0.0,
    residual_percent: float = 63.0,
    money_factor: float = 0.00190,
    base_buy_rate_mf: float = 0.00190,
    term_months: int = 36,
    annual_miles: int = 12000,
    doc_fee: float = 499.0,
    gov_fees: float = 385.0,
    acquisition_fee: float = 650.0,
    dealer_addons_total: float = 0.0,
    rebates: float = 0.0,
    cap_cost_reduction_down: float = 0.0,
    tax_rate_percent: float = 6.625,
    prevailing_market_discount_pct: float = 3.8,
    stretch_counter_discount_pct: float = 5.0,
    invoice_below_msrp_pct: float = 3.8,
) -> Dict[str, Any]:
    """Audits a dealer's purchase or lease quote against both mathematical line items and prevailing market comps.

    Args:
        deal_type (str): Quote transaction mode: 'PURCHASE' or 'LEASE'.
        msrp (float): Vehicle sticker MSRP in USD.
        selling_price (float): Dealer quoted vehicle selling price / cap cost in USD.
        dealer_quoted_otd (Optional[float]): Dealer's stated Out-The-Door total in USD (0.0 if not stated).
        dealer_quoted_monthly (Optional[float]): Dealer's stated monthly payment in USD (0.0 if not stated).
        dealer_quoted_drive_off (Optional[float]): Dealer's stated drive-off amount due at signing in USD.
        residual_percent (float): Lease residual value percentage of MSRP (default 63.0).
        money_factor (float): Dealer quoted lease money factor (default 0.00190).
        base_buy_rate_mf (float): Captive bank Tier-1 buy-rate money factor (default 0.00190).
        term_months (int): Lease or loan term in months (default 36).
        annual_miles (int): Annual lease mileage allowance (default 12000).
        doc_fee (float): Dealer documentation fee in USD (default 499.0).
        gov_fees (float): Government MVC title/registration fees in USD (default 385.0).
        acquisition_fee (float): Lease bank acquisition fee in USD (default 650.0).
        dealer_addons_total (float): Total cost of dealer-installed add-ons in USD.
        rebates (float): Manufacturer rebates and incentives in USD.
        cap_cost_reduction_down (float): Upfront cash down payment in USD.
        tax_rate_percent (float): Sales tax percentage (default 6.625 for NJ).
        prevailing_market_discount_pct (float): Prevailing NJ market discount percentage off MSRP (default 3.8%).
        stretch_counter_discount_pct (float): Stretch target discount percentage off MSRP (default 5.0%).
        invoice_below_msrp_pct (float): Factory invoice percentage below MSRP (default 3.8%).

    Returns:
        Dict[str, Any]: Audited quote report containing line-item math, `unexplained_otd_padding` or
            `unexplained_monthly_padding`, `red_flags`, and `recommended_counter_otd` / `recommended_counter_monthly`.
    """
    deal_type_norm = (deal_type or "PURCHASE").strip().upper()
    _, guided_err = validate_tool_input(
        schema_cls=AuditDealerQuoteInputSchema,
        raw_kwargs={
            "deal_type": deal_type_norm,
            "msrp": msrp,
            "selling_price": selling_price,
            "dealer_quoted_otd": dealer_quoted_otd or 0.0,
            "dealer_quoted_monthly": dealer_quoted_monthly or 0.0,
            "dealer_quoted_drive_off": dealer_quoted_drive_off or 0.0,
            "residual_percent": residual_percent,
            "money_factor": money_factor,
            "base_buy_rate_mf": base_buy_rate_mf,
            "term_months": term_months,
            "annual_miles": annual_miles,
            "doc_fee": doc_fee,
            "gov_fees": gov_fees,
            "acquisition_fee": acquisition_fee,
            "dealer_addons_total": dealer_addons_total,
            "rebates": rebates,
            "cap_cost_reduction_down": cap_cost_reduction_down,
            "tax_rate_percent": tax_rate_percent,
        },
        tool_name="audit_dealer_quote",
        recovery_hint=(
            "Pass `deal_type` as either 'PURCHASE' or 'LEASE', positive `msrp` and `selling_price` USD values, "
            "and `residual_percent` as percentage points (e.g. 62.0)."
        ),
    )
    if guided_err is not None:
        return guided_err

    estimated_invoice = round(msrp * (1.0 - invoice_below_msrp_pct / 100.0), 2)
    prevailing_selling = round(msrp * (1.0 - prevailing_market_discount_pct / 100.0), 2)
    stretch_target_selling = round(
        msrp * (1.0 - stretch_counter_discount_pct / 100.0), 2
    )
    vs_prevailing_dollars = round(selling_price - prevailing_selling, 2)

    if deal_type_norm == "LEASE":
        calc = calculate_lease_payment(
            msrp=msrp,
            selling_price=selling_price,
            residual_percent=residual_percent,
            money_factor=money_factor,
            term_months=term_months,
            annual_miles=annual_miles,
            tax_rate_percent=tax_rate_percent,
            acquisition_fee=acquisition_fee,
            doc_fee=doc_fee,
            gov_fees=gov_fees,
            dealer_addons_total=dealer_addons_total,
            rebates_and_lease_cash=rebates,
            cap_cost_reduction_down=cap_cost_reduction_down,
            base_buy_rate_mf=base_buy_rate_mf,
        )
        discrepancy_monthly = 0.0
        if dealer_quoted_monthly is not None and dealer_quoted_monthly > 0:
            discrepancy_monthly = round(
                dealer_quoted_monthly - calc["total_monthly_payment"], 2
            )
            if discrepancy_monthly > 5.0:
                calc["red_flags"].append(
                    f"Dealer quoted ${dealer_quoted_monthly:,.2f}/mo, which is ${discrepancy_monthly:,.2f}/mo higher than itemized math (${calc['total_monthly_payment']:,.2f}/mo)."
                )
        if vs_prevailing_dollars > 150:
            calc["red_flags"].append(
                f"Above Prevailing NJ Market Comp: Cap Cost ${selling_price:,.0f} ({calc['discount_pct']}% off) is ${vs_prevailing_dollars:,.0f} above prevailing NJ deals (${prevailing_selling:,.0f} / {prevailing_market_discount_pct}% off MSRP). Counter at ${stretch_target_selling:,.0f} ({stretch_counter_discount_pct}% off)."
            )

        target_cap_cost = round(min(selling_price, stretch_target_selling), 2)
        target_calc = calculate_lease_payment(
            msrp=msrp,
            selling_price=target_cap_cost,
            residual_percent=residual_percent,
            money_factor=base_buy_rate_mf,
            term_months=term_months,
            annual_miles=annual_miles,
            tax_rate_percent=tax_rate_percent,
            acquisition_fee=acquisition_fee,
            doc_fee=min(doc_fee, 499.0),
            gov_fees=gov_fees,
            dealer_addons_total=0.0,
            rebates_and_lease_cash=rebates,
            cap_cost_reduction_down=0.0,
            base_buy_rate_mf=base_buy_rate_mf,
        )
        calc["estimated_invoice_price"] = estimated_invoice
        calc["prevailing_market_discount_pct"] = prevailing_market_discount_pct
        calc["prevailing_market_selling_price"] = prevailing_selling
        calc["stretch_counter_discount_pct"] = stretch_counter_discount_pct
        calc["vs_prevailing_market_dollars"] = vs_prevailing_dollars
        calc["dealer_quoted_monthly"] = dealer_quoted_monthly
        calc["dealer_quoted_drive_off"] = dealer_quoted_drive_off
        calc["unexplained_monthly_padding"] = discrepancy_monthly
        calc["recommended_counter_cap_cost"] = target_cap_cost
        calc["recommended_counter_monthly"] = target_calc["total_monthly_payment"]
        calc["recommended_counter_drive_off"] = target_calc["drive_off_due_at_signing"]
        return calc

    calc = calculate_otd_price(
        msrp=msrp,
        selling_price=selling_price,
        doc_fee=doc_fee,
        gov_fees=gov_fees,
        tax_rate_percent=tax_rate_percent,
        dealer_addons_total=dealer_addons_total,
        rebates=rebates,
        prevailing_market_discount_pct=prevailing_market_discount_pct,
        stretch_counter_discount_pct=stretch_counter_discount_pct,
        invoice_below_msrp_pct=invoice_below_msrp_pct,
    )
    discrepancy_otd = 0.0
    if dealer_quoted_otd is not None and dealer_quoted_otd > 0:
        discrepancy_otd = round(dealer_quoted_otd - calc["otd_total"], 2)
        if discrepancy_otd > 25.0:
            calc["red_flags"].append(
                f"Dealer quoted ${dealer_quoted_otd:,.2f} OTD, which is ${discrepancy_otd:,.2f} higher than itemized components (${calc['otd_total']:,.2f})."
            )

    target_selling = round(min(selling_price, stretch_target_selling), 2)
    target_calc = calculate_otd_price(
        msrp=msrp,
        selling_price=target_selling,
        doc_fee=min(doc_fee, 499.0),
        gov_fees=gov_fees,
        tax_rate_percent=tax_rate_percent,
        dealer_addons_total=0.0,
        rebates=rebates,
        prevailing_market_discount_pct=prevailing_market_discount_pct,
        stretch_counter_discount_pct=stretch_counter_discount_pct,
        invoice_below_msrp_pct=invoice_below_msrp_pct,
    )
    calc["dealer_quoted_otd"] = dealer_quoted_otd
    calc["unexplained_otd_padding"] = discrepancy_otd
    calc["recommended_counter_selling_price"] = target_selling
    calc["recommended_counter_otd"] = target_calc["otd_total"]
    return calc


@instrument_tool
def calculate_color_parity_benchmark(
    msrp: float,
    selling_price: float,
    otd_total: float = 0.0,
    interior_color: str = "Terracotta Brown Leather",
    is_non_black_interior: bool | None = None,
    doc_fee: float = 499.0,
    gov_fees: float = 385.0,
    dealer_addons_total: float = 0.0,
    rebates: float = 500.0,
    competing_black_otd: float = 0.0,
    competing_black_msrp: float = 53890.0,
    competing_black_discount_pct: float = 3.8,
    tax_rate_percent: float = 6.625,
    residual_percent: float = 62.0,
    lease_term_months: int = 36,
    money_factor: float = 0.00190,
) -> Dict[str, Any]:
    """Computes 'Zero Scarcity Tax' Color-Parity OTD math for Non-Black interiors (nice-to-have tiebreaker).

    Since a Non-Black interior (Terracotta, Sage Green, Mahogany) is a nice-to-have preference and NOT a
    requirement, the buyer never concedes scarcity leverage. The factory option adds $295 to MSRP (~$314.54 OTD
    with 6.625% NJ tax, or ~$3.11/mo on a 62% residual 36-month lease). Any dollar beyond that is flagged as
    dealer 'color scarcity markup'.

    Args:
        msrp (float): Vehicle sticker MSRP in USD (including any factory color option).
        selling_price (float): Dealer quoted selling price in USD.
        otd_total (float): Dealer quoted OTD price in USD (if 0, calculated automatically).
        interior_color (str): Interior color description (e.g. 'Terracotta Brown Leather').
        is_non_black_interior (Optional[bool]): Explicit override for whether interior is Non-Black.
        doc_fee (float): Dealer doc fee in USD (default 499.0).
        gov_fees (float): Government MVC fees in USD (default 385.0).
        dealer_addons_total (float): Dealer add-ons in USD (default 0.0).
        rebates (float): Manufacturer rebates in USD (default 500.0).
        competing_black_otd (float): Competing Black-interior OTD quote in USD for direct comparison.
        competing_black_msrp (float): Competing Black-interior MSRP in USD.
        competing_black_discount_pct (float): Competing discount percentage off MSRP (default 3.8%).
        tax_rate_percent (float): Sales tax percentage (default 6.625 for NJ).
        residual_percent (float): Lease residual percentage (default 62.0).
        lease_term_months (int): Lease term in months (default 36).
        money_factor (float): Lease money factor (default 0.00190).

    Returns:
        Dict[str, Any]: Color-parity benchmark dictionary containing `color_parity_otd`, `otd_color_delta`,
            `lease_monthly_36m_color_delta`, `color_scarcity_overcharge_otd`, and `leverage_script`.
    """
    if is_non_black_interior is None:
        is_non_black_interior = "black" not in (interior_color or "").lower()

    tax_mult = 1.0 + (tax_rate_percent / 100.0)
    if otd_total <= 0:
        otd_total = round(
            (selling_price + dealer_addons_total + doc_fee - rebates) * tax_mult
            + gov_fees,
            2,
        )

    factory_interior_option_msrp = 295.0 if is_non_black_interior else 0.0
    otd_color_delta = round(factory_interior_option_msrp * tax_mult, 2)
    discounted_option_cost = round(
        factory_interior_option_msrp * (1.0 - competing_black_discount_pct / 100.0), 2
    )
    max_fair_otd_color_delta = round(discounted_option_cost * tax_mult, 2)

    residualized_portion = round(
        factory_interior_option_msrp * (residual_percent / 100.0), 2
    )
    lease_dep_delta = (factory_interior_option_msrp - residualized_portion) / max(
        1, lease_term_months
    )
    lease_monthly_36m_color_delta = round(max(0.0, lease_dep_delta), 2)

    color_parity_otd = round(otd_total - otd_color_delta, 2)

    parity_selling_price = round(
        msrp * (1.0 - competing_black_discount_pct / 100.0), 2
    )
    parity_target_otd = (
        round(competing_black_otd + max_fair_otd_color_delta, 2)
        if competing_black_otd > 0 and abs(msrp - competing_black_msrp) <= 600
        else round((parity_selling_price + 499.0 - rebates) * tax_mult + gov_fees, 2)
    )
    scarcity_markup_dollars = max(0.0, round(otd_total - parity_target_otd, 2))
    leverage_script = (
        f"Non-Black interior ({interior_color}) adds ${factory_interior_option_msrp:,.0f} to factory MSRP "
        f"(+${otd_color_delta:,.2f} OTD w/ {tax_rate_percent}% NJ tax, or +${lease_monthly_36m_color_delta:,.2f}/mo on a {lease_term_months}m lease). "
        f"Color-Parity Target OTD is ${parity_target_otd:,.0f}. If the dealer won't match ${parity_target_otd:,.0f} OTD, pivot immediately to the Black-interior unit."
    )

    return {
        "is_non_black_interior": is_non_black_interior,
        "interior_color": interior_color,
        "preference_policy": "NICE_TO_HAVE_TIEBREAKER_NOT_REQUIRED",
        "factory_color_option_msrp": factory_interior_option_msrp,
        "factory_interior_option_msrp": factory_interior_option_msrp,
        "otd_color_delta": otd_color_delta,
        "max_fair_otd_color_delta": max_fair_otd_color_delta,
        "lease_monthly_36m_color_delta": lease_monthly_36m_color_delta,
        "max_fair_lease_monthly_delta": lease_monthly_36m_color_delta,
        "color_parity_otd": color_parity_otd,
        "color_parity_target_selling_price": parity_selling_price,
        "color_parity_target_otd": parity_target_otd,
        "color_scarcity_overcharge_otd": scarcity_markup_dollars,
        "color_scarcity_markup_dollars": scarcity_markup_dollars,
        "has_scarcity_markup": scarcity_markup_dollars > 50.0,
        "leverage_script": leverage_script,
        "tiebreaker_rule": leverage_script,
    }


@instrument_tool
def calculate_trade_in_impact(
    otd_price: float = 0.0,
    locked_vehicle_otd: float = 0.0,
    msrp: float = 53890.0,
    selling_price: float = 51842.0,
    trade_in_allowance: float = 0.0,
    trade_in_value: float = 0.0,
    carmax_floor_offer: float = 0.0,
    carmax_offer_floor: float = 0.0,
    trade_loan_payoff: float = 0.0,
    trade_in_payoff: float = 0.0,
    tax_rate_percent: float = 6.625,
    doc_fee: float = 499.0,
    gov_fees: float = 385.0,
    rebates: float = 500.0,
    cash_down: float = 0.0,
    cash_down_extra: float = 0.0,
    loan_apr_percent: float = 4.9,
    loan_term_months: int = 60,
    residual_percent: float = 62.0,
    money_factor: float = 0.00190,
    lease_term_months: int = 36,
    private_preview_confirmed: bool = False,
    otd_locked_confirmed: bool = False,
    dealer_revised_net_otd: float = 0.0,
    locked_pre_trade_selling_price: float = 0.0,
    post_trade_dealer_selling_price: float = 0.0,
    post_trade_doc_or_addons_delta: float = 0.0,
) -> Dict[str, Any]:
    """Two-Stage Affirmative Trade-In Calculator & Post-OTD Lock Negotiation Engine.

    Gate #1 (`private_preview_confirmed=True`):
      Privately models how a potential trade-in (and the 6.625% NJ Sales Tax Trade-In Credit)
      reduces the buyer's Net OTD balance and Monthly Finance/Lease payments.
      IMPORTANT: While only Gate #1 is active, the Outbound Dealer Gag Order remains 100% locked!

    Gate #2 (`otd_locked_confirmed=True`):
      Only enabled AFTER the buyer confirms the new vehicle's OTD price is locked in writing with the dealer.
      Unlocks Phase 2 dealer trade-in negotiation scripts, CarMax/Carvana tax-credit break-even leverage,
      and the Post-Trade Shell-Game Auditor.

    Args:
        otd_price (float): Negotiated or target pre-trade OTD price in USD.
        locked_vehicle_otd (float): Locked pre-trade vehicle OTD price in USD (alias for `otd_price`).
        msrp (float): Vehicle sticker MSRP in USD.
        selling_price (float): Pre-trade vehicle selling price in USD.
        trade_in_allowance (float): Dealer's offered trade-in allowance in USD.
        trade_in_value (float): Estimated or offered trade-in value in USD (alias for `trade_in_allowance`).
        carmax_floor_offer (float): Written CarMax/Carvana instant cash offer floor in USD.
        carmax_offer_floor (float): Alias for `carmax_floor_offer` in USD.
        trade_loan_payoff (float): Remaining loan payoff balance on the trade-in vehicle in USD.
        trade_in_payoff (float): Alias for `trade_loan_payoff` in USD.
        tax_rate_percent (float): State sales tax percentage (default 6.625 for NJ).
        doc_fee (float): Dealer documentation fee in USD.
        gov_fees (float): Government MVC registration/title fees in USD.
        rebates (float): Manufacturer rebates in USD.
        cash_down (float): Additional cash down payment in USD.
        cash_down_extra (float): Alias for `cash_down` in USD.
        loan_apr_percent (float): Finance loan APR percentage (default 4.9%).
        loan_term_months (int): Finance loan term in months (default 60).
        residual_percent (float): Lease residual percentage (default 62.0%).
        money_factor (float): Lease money factor (default 0.00190).
        lease_term_months (int): Lease term in months (default 36).
        private_preview_confirmed (bool): Gate #1 checkbox confirming private buyer preview.
        otd_locked_confirmed (bool): Gate #2 checkbox confirming new-car OTD is locked in writing.
        dealer_revised_net_otd (float): Dealer's post-trade net OTD worksheet figure for shell-game auditing.
        locked_pre_trade_selling_price (float): Pre-trade locked selling price for clawback detection.
        post_trade_dealer_selling_price (float): Dealer's selling price on the post-trade worksheet.
        post_trade_doc_or_addons_delta (float): Any extra doc fee or add-ons added by dealer after trade reveal.

    Returns:
        Dict[str, Any]: Trade-in impact analysis including `nj_sales_tax_credit_savings`,
            `carmax_tax_equivalent_break_even`, `expected_post_trade_net_otd`, `shell_game_detected`,
            and `phase_2_outbound_trade_script`.
    """
    effective_otd = float(locked_vehicle_otd if locked_vehicle_otd > 0 else (otd_price if otd_price > 0 else 55303.11))
    effective_trade = float(trade_in_value if trade_in_value > 0 else trade_in_allowance)
    effective_payoff = float(trade_in_payoff if trade_in_payoff > 0 else trade_loan_payoff)
    effective_carmax = float(carmax_offer_floor if carmax_offer_floor > 0 else carmax_floor_offer)
    effective_cash_down = float(cash_down_extra if cash_down_extra > 0 else cash_down)

    tax_rate_dec = tax_rate_percent / 100.0
    tax_mult = 1.0 + tax_rate_dec

    baseline = calculate_monthly_from_otd(
        otd_price=effective_otd,
        msrp=msrp,
        tax_rate_percent=tax_rate_percent,
        doc_fee=doc_fee,
        gov_fees=gov_fees,
        rebates=rebates,
        cash_down_or_trade_equity=effective_cash_down,
        loan_apr_percent=loan_apr_percent,
        loan_term_months=loan_term_months,
        lease_term_months=lease_term_months,
        residual_percent=residual_percent,
        money_factor=money_factor,
    )
    implied_selling = float(
        baseline["reverse_otd_breakdown"]["implied_selling_price_cap_cost"]
    )
    effective_selling = (
        locked_pre_trade_selling_price
        if locked_pre_trade_selling_price > 0
        else (selling_price if selling_price > 0 else implied_selling)
    )

    taxable_base_before_trade = max(0.0, effective_selling + doc_fee - rebates)
    taxable_reduction = min(taxable_base_before_trade, max(0.0, effective_trade))
    nj_tax_credit_savings = round(taxable_reduction * tax_rate_dec, 2)

    effective_dealer_trade_value = round(effective_trade + nj_tax_credit_savings, 2)
    carmax_tax_equivalent_break_even = (
        round(effective_carmax / tax_mult, 2) if effective_carmax > 0 else 0.0
    )
    net_advantage_vs_carmax = round(
        effective_dealer_trade_value - effective_carmax, 2
    )

    net_trade_equity = round(effective_trade - effective_payoff, 2)
    total_otd_reduction_from_trade = round(
        net_trade_equity + nj_tax_credit_savings, 2
    )
    expected_post_trade_net_otd = max(
        0.0, round(effective_otd - total_otd_reduction_from_trade - effective_cash_down, 2)
    )

    loan_48_with_trade = _loan_monthly_payment(
        expected_post_trade_net_otd, loan_apr_percent, 48
    )
    loan_60_with_trade = _loan_monthly_payment(
        expected_post_trade_net_otd, loan_apr_percent, 60
    )
    loan_72_with_trade = _loan_monthly_payment(
        expected_post_trade_net_otd, loan_apr_percent, 72
    )
    loan_selected_with_trade = _loan_monthly_payment(
        expected_post_trade_net_otd, loan_apr_percent, loan_term_months
    )

    base_loan_60 = float(baseline["finance_purchase_from_otd"]["monthly_60mo"])
    monthly_loan_60_savings = round(base_loan_60 - loan_60_with_trade, 2)

    lease_cap_reduction = max(0.0, net_trade_equity + effective_cash_down)
    lease_with_trade = calculate_lease_payment(
        msrp=msrp,
        selling_price=effective_selling,
        residual_percent=residual_percent,
        money_factor=money_factor,
        term_months=lease_term_months,
        annual_miles=12000,
        tax_rate_percent=tax_rate_percent,
        doc_fee=doc_fee,
        gov_fees=gov_fees,
        rebates_and_lease_cash=rebates,
        cap_cost_reduction_down=lease_cap_reduction,
        base_buy_rate_mf=money_factor,
    )
    base_lease_mo = float(
        baseline["lease_from_otd_cap_cost"]["total_monthly_payment"]
    )
    lease_mo_with_trade = float(lease_with_trade["total_monthly_payment"])

    shell_game_warnings = []
    shell_game_overcharge = 0.0
    if (
        post_trade_dealer_selling_price > 0
        and locked_pre_trade_selling_price > 0
        and post_trade_dealer_selling_price > locked_pre_trade_selling_price + 10.0
    ):
        clawback = round(
            post_trade_dealer_selling_price - locked_pre_trade_selling_price, 2
        )
        shell_game_overcharge += clawback
        shell_game_warnings.append(
            f"🚨 POST-TRADE SHELL GAME DETECTED: Dealer inflated the locked new-car selling price from "
            f"${locked_pre_trade_selling_price:,.0f} to ${post_trade_dealer_selling_price:,.0f} (+${clawback:,.0f} discount clawback) when adding your trade-in!"
        )
    if post_trade_doc_or_addons_delta > 10.0:
        shell_game_overcharge += round(post_trade_doc_or_addons_delta, 2)
        shell_game_warnings.append(
            f"🚨 POST-TRADE SHELL GAME DETECTED: Dealer added +${post_trade_doc_or_addons_delta:,.0f} in extra doc/add-on fees on the post-trade worksheet!"
        )
    if dealer_revised_net_otd > 0:
        rev_diff = round(dealer_revised_net_otd - expected_post_trade_net_otd, 2)
        if rev_diff > 25.0:
            shell_game_overcharge = max(shell_game_overcharge, rev_diff)
            shell_game_warnings.append(
                f"🚨 POST-TRADE SHELL GAME DETECTED: Dealer's revised net balance (${dealer_revised_net_otd:,.2f}) is "
                f"${rev_diff:,.2f} higher than the exact math (${expected_post_trade_net_otd:,.2f}) from your locked "
                f"${effective_otd:,.2f} OTD minus ${effective_trade:,.0f} trade and ${nj_tax_credit_savings:,.2f} NJ tax credit!"
            )

    shell_game_detected = len(shell_game_warnings) > 0
    shell_game_warning = " ".join(shell_game_warnings)

    carmax_verdict = (
        f"Dealer's ${effective_trade:,.0f} trade offer + ${nj_tax_credit_savings:,.2f} NJ 6.625% tax credit = "
        f"${effective_dealer_trade_value:,.2f} effective value "
        + (
            f"(beats your ${effective_carmax:,.0f} CarMax floor by +${net_advantage_vs_carmax:,.2f} — trade with the dealer!)."
            if net_advantage_vs_carmax >= 0
            else f"(${abs(net_advantage_vs_carmax):,.2f} below your ${effective_carmax:,.0f} CarMax floor — dealer must pay at least ${carmax_tax_equivalent_break_even:,.0f} to break even with CarMax)."
        )
    )

    if not private_preview_confirmed and not otd_locked_confirmed:
        stage_label = "STAGE 0: TRADE-IN GAG ACTIVE (Check Box #1 to Preview)"
        gate_status = "LOCKED_REQUIRES_CHECKBOX_1_AFFIRMATIVE_CONFIRMATION"
    elif not otd_locked_confirmed:
        stage_label = "STAGE 1: PRIVATE PREVIEW ONLY (Outbound Gag Active)"
        gate_status = "GATE_1_PRIVATE_PREVIEW_ONLY"
    else:
        stage_label = "STAGE 2: OTD LOCKED — PHASE 2 TRADE NEGOTIATION UNLOCKED"
        gate_status = "GATE_2_POST_OTD_LOCK_TRADE_NEGOTIATION_UNLOCKED"

    target_trade_ask = round(max(effective_carmax, effective_trade), 0)
    phase_2_outbound_script = ""
    phase_2_scripts = None
    if otd_locked_confirmed:
        phase_2_outbound_script = (
            f"Thanks for confirming ${effective_otd:,.0f} OTD in writing—I'm ready to put down my deposit to lock the incoming December VIN. "
            f"One quick item we can add if the numbers make sense: I have a trade-in with a ${effective_carmax:,.0f} written offer from CarMax (which equals ${carmax_tax_equivalent_break_even:,.0f} after the 6.625% NJ sales tax credit), "
            f"so if your desk can match ${target_trade_ask:,.0f} while keeping our ${effective_otd:,.0f} OTD untouched, I'll trade it in with you at delivery."
        )
        phase_2_scripts = {
            "step_1_post_lock_pivot_script": phase_2_outbound_script,
            "step_2_lowball_counter_script": (
                f"At ${effective_trade:,.0f}, even with the ${nj_tax_credit_savings:,.0f} NJ sales tax credit (${effective_dealer_trade_value:,.0f} net value), "
                f"I'm still better off taking my ${effective_carmax:,.0f} CarMax check. If your appraiser brings the trade to ${carmax_tax_equivalent_break_even + 400:,.0f}+ "
                f"(so my net balance due is ${expected_post_trade_net_otd:,.0f}), I'll include the trade—otherwise let's just keep our straight ${effective_otd:,.0f} OTD deal with no trade."
            ),
        }
        if shell_game_detected:
            phase_2_scripts["step_3_shell_game_pushback_script"] = shell_game_warning

    return {
        "ok": bool(private_preview_confirmed or otd_locked_confirmed),
        "stage_label": stage_label,
        "gate_status": gate_status,
        "outbound_gag_active": not otd_locked_confirmed,
        "outbound_dealer_gag_active": not otd_locked_confirmed,
        "locked_or_target_otd_before_trade": round(effective_otd, 2),
        "trade_in_allowance": round(effective_trade, 2),
        "carmax_floor_offer": round(effective_carmax, 2),
        "trade_loan_payoff": round(effective_payoff, 2),
        "net_trade_equity": net_trade_equity,
        "nj_sales_tax_credit_savings": nj_tax_credit_savings,
        "effective_dealer_trade_value_with_tax_credit": effective_dealer_trade_value,
        "carmax_tax_equivalent_break_even": carmax_tax_equivalent_break_even,
        "carmax_tax_equivalent_dealer_floor": carmax_tax_equivalent_break_even,
        "net_advantage_vs_carmax": net_advantage_vs_carmax,
        "carmax_comparison_verdict": carmax_verdict,
        "expected_post_trade_net_otd": expected_post_trade_net_otd,
        "adjusted_otd_after_trade_and_tax_credit": expected_post_trade_net_otd,
        "monthly_60mo_with_trade": loan_60_with_trade,
        "lease_36mo_with_trade": lease_mo_with_trade,
        "shell_game_detected": shell_game_detected,
        "shell_game_overcharge": shell_game_overcharge,
        "shell_game_warning": shell_game_warning,
        "shell_game_warnings": shell_game_warnings,
        "finance_payments_without_trade": {
            "monthly_48mo": baseline["finance_purchase_from_otd"]["monthly_48mo"],
            "monthly_60mo": base_loan_60,
            "monthly_72mo": baseline["finance_purchase_from_otd"]["monthly_72mo"],
        },
        "finance_payments_with_trade": {
            "amount_financed_after_trade_and_tax_credit": expected_post_trade_net_otd,
            "monthly_48mo": loan_48_with_trade,
            "monthly_60mo": loan_60_with_trade,
            "monthly_72mo": loan_72_with_trade,
            "monthly_selected": loan_selected_with_trade,
            "monthly_60mo_savings_from_trade": monthly_loan_60_savings,
        },
        "lease_payments_comparison": {
            "monthly_36mo_without_trade": base_lease_mo,
            "monthly_36mo_with_trade_equity_applied": lease_mo_with_trade,
        },
        "phase_2_outbound_trade_script": phase_2_outbound_script,
        "phase_2_dealer_scripts": phase_2_scripts,
    }


@instrument_tool
def calculate_nj_payments(
    msrp: float,
    selling_price: float,
    doc_fee: float = 749.0,
    addons: float = 0.0,
    mv_tire_fees: float = 400.0,
    rebates: float = 750.0,
    cash_down: float = 3000.0,
    loan_apr: float = 4.49,
    loan_term: int = 60,
    lease_mf: float = 0.00245,
    lease_residual_pct: float = 0.62,
    lease_term: int = 36,
    target_monthly_budget: float = 750.0,
    mandatory_addons: float | None = None,
    addons_total: float | None = None,
    gov_fees: float | None = None,
    loan_apr_percent: float | None = None,
    apr_percent: float | None = None,
    loan_term_months: int | None = None,
    lease_term_months: int | None = None,
    residual_percent: float | None = None,
    base_mf: float | None = None,
    money_factor: float | None = None,
    acquisition_fee: float = 650.0,
    target_monthly_lease_budget: float | None = None,
    tax_rate_percent: float = 6.625,
) -> Dict[str, Any]:
    """Calculates exact NJ Purchase OTD, 60-Mo Loan, and 36-Mo/12k Lease payments (both with cash_down and $0 Sign & Drive), plus True Deal Score.

    Handles the exact distinction between:
    1. NJ Purchase Sales Tax (6.625% on full Selling Price + Add-ons + Doc Fee BEFORE subtracting manufacturer rebates)
    2. NJ Lease Sales Tax (6.625% taxed ONLY on total lease depreciation + fees, not the full vehicle)

    Args:
        msrp (float): Vehicle window sticker MSRP in USD (e.g. 56035.0, 58135.0, or 59135.0).
        selling_price (float): Quoted or target selling price before taxes and fees in USD.
        doc_fee (float): Dealership NJ documentation fee in USD (default 749.0).
        addons (float): Mandatory or quoted dealer add-ons in USD (default 0.0).
        mv_tire_fees (float): NJ MVC registration, title, and tire fees in USD (default 400.0).
        rebates (float): Stackable Kia factory rebates in USD (default 750.0 Loyalty/Conquest).
        cash_down (float): Personal cash down / out-of-pocket in USD (default 3000.0).
        loan_apr (float): Annual percentage rate for financed purchase (default 4.49).
        loan_term (int): Loan term in months (default 60).
        lease_mf (float): Base or quoted lease Money Factor (default 0.00245 ~ 5.88% APR).
        lease_residual_pct (float): Lease residual ratio (default 0.62 for 62% on 36mo/12k; also accepts 62.0).
        lease_term (int): Lease term in months (default 36).
        target_monthly_budget (float): Buyer's target monthly payment budget in USD (default 750.0).

    Returns:
        Dict[str, Any]: Complete V3 NJ payment & HUD telemetry dictionary including `pure_dealer_discount`,
            `true_deal_score`, `purchase_otd`, `loan_monthly_60mo`, `loan_monthly_60mo_zero_down`,
            `lease_monthly_36mo`, `lease_monthly_36mo_sign_and_drive`, and `extra_discount_to_hit_lease_budget`.
    """
    if mandatory_addons is not None:
        addons = float(mandatory_addons)
    elif addons_total is not None:
        addons = float(addons_total)
    if gov_fees is not None:
        mv_tire_fees = float(gov_fees)
    if loan_apr_percent is not None:
        loan_apr = float(loan_apr_percent)
    elif apr_percent is not None:
        loan_apr = float(apr_percent)
    if loan_term_months is not None:
        loan_term = int(loan_term_months)
    if lease_term_months is not None:
        lease_term = int(lease_term_months)
    if residual_percent is not None:
        lease_residual_pct = float(residual_percent)
    if base_mf is not None:
        lease_mf = float(base_mf)
    elif money_factor is not None:
        lease_mf = float(money_factor)
    if target_monthly_lease_budget is not None:
        target_monthly_budget = float(target_monthly_lease_budget)

    _, guided_err = validate_tool_input(
        schema_cls=CalculateNJPaymentsInputSchema,
        raw_kwargs={
            "msrp": msrp,
            "selling_price": selling_price,
            "doc_fee": doc_fee,
            "addons": addons,
            "mv_tire_fees": mv_tire_fees,
            "rebates": rebates,
            "cash_down": cash_down,
            "loan_apr": loan_apr,
            "loan_term": loan_term,
            "lease_mf": lease_mf,
            "lease_residual_pct": lease_residual_pct,
            "lease_term": lease_term,
            "target_monthly_budget": target_monthly_budget,
        },
        tool_name="calculate_nj_payments",
        recovery_hint=(
            "Ensure `msrp` and `selling_price` are positive USD amounts (e.g. msrp=56035.0, selling_price=54535.0) "
            "and `lease_mf` is between 0.0 and 0.02 (e.g. 0.00245)."
        ),
    )
    if guided_err is not None:
        return guided_err

    nj_tax_rate = (tax_rate_percent / 100.0) if tax_rate_percent > 1.0 else 0.06625  # 6.625% NJ Sales Tax
    kia_acq_fee = float(acquisition_fee or 650.0)

    res_ratio = lease_residual_pct / 100.0 if lease_residual_pct > 1.0 else lease_residual_pct

    effective_selling_price = selling_price + addons
    dealer_discount = msrp - selling_price
    true_deal_score = (selling_price - msrp) + doc_fee + addons

    # 1. NJ PURCHASE / LOAN MATH (6.625% tax on full Selling Price + Doc Fee + Add-ons BEFORE rebates)
    taxable_purchase = effective_selling_price + doc_fee
    purchase_tax = taxable_purchase * nj_tax_rate
    true_otd_price = taxable_purchase + purchase_tax + mv_tire_fees - rebates
    amount_financed = max(0.0, true_otd_price - cash_down)
    amount_financed_zero_down = max(0.0, true_otd_price)

    if loan_apr > 0:
        r = (loan_apr / 100.0) / 12.0
        loan_monthly = amount_financed * (r * (1.0 + r) ** loan_term) / ((1.0 + r) ** loan_term - 1.0)
        loan_monthly_zero_down = (
            amount_financed_zero_down * (r * (1.0 + r) ** loan_term) / ((1.0 + r) ** loan_term - 1.0)
        )
    else:
        loan_monthly = amount_financed / max(1, loan_term)
        loan_monthly_zero_down = amount_financed_zero_down / max(1, loan_term)

    # 2. NJ LEASE MATH (6.625% tax applied ONLY to depreciation + fees, not full car)
    residual_value = msrp * res_ratio
    gross_cap_cost = effective_selling_price + doc_fee + kia_acq_fee
    cap_cost_reduction = cash_down + rebates

    taxable_lease_amount = gross_cap_cost - residual_value
    nj_lease_tax = taxable_lease_amount * nj_tax_rate

    # A. Lease with cash_down ($3,000 default out of pocket)
    net_cap_cost = gross_cap_cost - cap_cost_reduction + nj_lease_tax + mv_tire_fees
    depreciation_mo = (net_cap_cost - residual_value) / max(1, lease_term)
    rent_charge_mo = (net_cap_cost + residual_value) * lease_mf
    lease_monthly = depreciation_mo + rent_charge_mo

    # B. Lease with $0 cash_down (True Sign & Drive — $0 out of pocket, only rebates reduce cap cost)
    net_cap_cost_zero_down = gross_cap_cost - rebates + nj_lease_tax + mv_tire_fees
    depreciation_mo_zero_down = (net_cap_cost_zero_down - residual_value) / max(1, lease_term)
    rent_charge_mo_zero_down = (net_cap_cost_zero_down + residual_value) * lease_mf
    lease_monthly_sign_and_drive = depreciation_mo_zero_down + rent_charge_mo_zero_down

    # Calculate additional OTD discount needed to hit target lease monthly budget
    # Every $1,000 off selling price saves ~$29.50/mo on a 36-mo lease or ~$18.64/mo on a 60-mo loan
    lease_variance = lease_monthly - target_monthly_budget
    extra_discount_needed_for_lease = max(0.0, (lease_variance / 29.50) * 1000.0)

    lease_variance_zero_down = lease_monthly_sign_and_drive - target_monthly_budget
    extra_discount_needed_zero_down = max(0.0, (lease_variance_zero_down / 29.50) * 1000.0)

    if true_deal_score <= -1400:
        deal_score_verdict = "STAGE 2 LOT RAID WINNER (Deep Holdback Deal)"
    elif true_deal_score <= -500:
        deal_score_verdict = "STAGE 1 IN-TRANSIT LOCK TARGET MET (Winning Local Deal)"
    elif true_deal_score <= -200:
        deal_score_verdict = "SOLID LOCAL DEAL (Wipes Out NJ Doc Fee)"
    elif true_deal_score <= 750:
        deal_score_verdict = "NEEDS COUNTER (Doc Fee Not Fully Offset)"
    else:
        deal_score_verdict = "MEDIOCRE / OVERPRICED LOCAL QUOTE"

    forensic_flags = []
    if addons > 0:
        forensic_flags.append(f"Strip ${addons:,.0f} in dealer add-ons (Pre-PDI Directive: $0 add-ons).")
    if mv_tire_fees > 450:
        forensic_flags.append(f"DMV/MVC fee padding detected (${mv_tire_fees:,.0f} quoted vs ~$400 NJ standard).")
    if lease_mf > 0.00245 + 0.00004:
        forensic_flags.append(
            f"Hidden Lease MF Markup: {lease_mf:.5f} ({lease_mf * 2400:.2f}% APR) vs 0.00245 (5.88% base)."
        )
    if doc_fee >= 850:
        forensic_flags.append(
            f"High NJ Doc Fee (${doc_fee:,.0f}): Demand an extra $200+ off MSRP to normalize True Deal Score."
        )

    return {
        "ok": True,
        "msrp": round(msrp, 2),
        "selling_price": round(selling_price, 2),
        "doc_fee": round(doc_fee, 2),
        "addons": round(addons, 2),
        "mv_tire_fees": round(mv_tire_fees, 2),
        "rebates": round(rebates, 2),
        "cash_down": round(cash_down, 2),
        "target_monthly_budget": round(target_monthly_budget, 2),
        "pure_dealer_discount": round(dealer_discount, 2),
        "discount_pct": round((dealer_discount / msrp) * 100.0, 2) if msrp > 0 else 0.0,
        "true_deal_score": round(true_deal_score, 2),
        "deal_score_verdict": deal_score_verdict,
        "purchase_tax": round(purchase_tax, 2),
        "purchase_otd": round(true_otd_price, 2),
        "loan_monthly_60mo": round(loan_monthly, 2),
        "loan_monthly_60mo_zero_down": round(loan_monthly_zero_down, 2),
        "loan_3000_down_monthly": round(loan_monthly, 2),
        "loan_0_down_monthly": round(loan_monthly_zero_down, 2),
        "residual_value": round(residual_value, 2),
        "nj_lease_tax": round(nj_lease_tax, 2),
        "net_cap_cost": round(net_cap_cost, 2),
        "net_cap_cost_zero_down": round(net_cap_cost_zero_down, 2),
        "lease_monthly_36mo": round(lease_monthly, 2),
        "lease_monthly_36mo_sign_and_drive": round(lease_monthly_sign_and_drive, 2),
        "lease_3000_down_monthly": round(lease_monthly, 2),
        "lease_0_down_monthly": round(lease_monthly_sign_and_drive, 2),
        "extra_discount_to_hit_lease_budget": round(extra_discount_needed_for_lease, 2),
        "extra_discount_to_hit_lease_budget_zero_down": round(extra_discount_needed_zero_down, 2),
        "forensic_flags": forensic_flags,
    }


@instrument_tool
def audit_uploaded_lease_sheet(
    msrp: float,
    adj_cap_cost: float | None = None,
    residual_dollar: float | None = None,
    quoted_monthly_payment: float | None = None,
    term: int = 36,
    base_mf: float = 0.00245,
    selling_price: float | None = None,
    dealer_quoted_monthly: float | None = None,
    cash_due_at_signing: float | None = None,
    cash_down: float | None = None,
    residual_percent: float = 62.0,
    base_buy_rate_mf: float | None = None,
    term_months: int | None = None,
    doc_fee: float = 799.0,
    gov_fees: float = 400.0,
    mv_tire_fees: float | None = None,
    acquisition_fee: float = 650.0,
    dealer_addons_total: float = 0.0,
    mandatory_addons: float | None = None,
    rebates: float = 750.0,
) -> Dict[str, Any]:
    """Reverse-engineers the hidden Money Factor and APR from a dealer's uploaded lease worksheet (Mode 4 Audit).

    Args:
        msrp (float): Vehicle window sticker MSRP in USD.
        adj_cap_cost (Optional[float]): Adjusted Capitalized Cost from the dealer worksheet in USD.
        residual_dollar (Optional[float]): Residual value in dollars from the dealer worksheet in USD.
        quoted_monthly_payment (Optional[float]): Quoted monthly lease payment on the dealer worksheet in USD.
        term (int): Lease term in months (default 36).
        base_mf (float): Base Kia Tier 1 Money Factor (default 0.00245 ~ 5.88% APR).

    Returns:
        Dict[str, Any]: Forensic lease audit containing `residual_pct`, `implied_mf`, `implied_apr_pct`,
            `base_apr_pct`, `hidden_monthly_markup`, `total_36mo_overcharge`, and `honest_monthly_payment`.
    """
    if term_months is not None:
        term = int(term_months)
    if base_buy_rate_mf is not None:
        base_mf = float(base_buy_rate_mf)
    if dealer_quoted_monthly is not None and quoted_monthly_payment is None:
        quoted_monthly_payment = float(dealer_quoted_monthly)
    if quoted_monthly_payment is None:
        quoted_monthly_payment = 789.0

    addons_val = float(mandatory_addons if mandatory_addons is not None else dealer_addons_total)
    fees_val = float(mv_tire_fees if mv_tire_fees is not None else gov_fees)
    down_val = float(cash_due_at_signing if cash_due_at_signing is not None else (cash_down if cash_down is not None else 3000.0))

    if residual_dollar is None or residual_dollar <= 0:
        res_ratio = residual_percent / 100.0 if residual_percent > 1.0 else residual_percent
        residual_dollar = round(msrp * res_ratio, 2)

    if adj_cap_cost is None or adj_cap_cost <= 0:
        sell_val = float(selling_price if selling_price is not None else msrp)
        gross_cap = sell_val + addons_val + doc_fee + acquisition_fee
        nj_lease_tax = max(0.0, (gross_cap - residual_dollar) * 0.06625)
        adj_cap_cost = round(gross_cap - down_val - rebates + nj_lease_tax + fees_val, 2)

    _, guided_err = validate_tool_input(
        schema_cls=AuditUploadedLeaseSheetInputSchema,
        raw_kwargs={
            "msrp": msrp,
            "adj_cap_cost": adj_cap_cost,
            "residual_dollar": residual_dollar,
            "quoted_monthly_payment": quoted_monthly_payment,
            "term": term,
            "base_mf": base_mf,
        },
        tool_name="audit_uploaded_lease_sheet",
        recovery_hint=(
            "Pass positive USD amounts for `msrp`, `adj_cap_cost`, `residual_dollar`, and `quoted_monthly_payment`."
        ),
    )
    if guided_err is not None:
        return guided_err

    monthly_depreciation = (adj_cap_cost - residual_dollar) / max(1, term)
    implied_rent_charge = quoted_monthly_payment - monthly_depreciation
    implied_mf = implied_rent_charge / max(1.0, (adj_cap_cost + residual_dollar))

    implied_apr = implied_mf * 2400.0
    base_apr = base_mf * 2400.0

    honest_rent_charge = (adj_cap_cost + residual_dollar) * base_mf
    honest_monthly_payment = monthly_depreciation + honest_rent_charge
    monthly_overcharge = quoted_monthly_payment - honest_monthly_payment
    total_overcharge = monthly_overcharge * term
    has_markup = implied_mf > (base_mf + 0.00004)

    forensic_flags = []
    if has_markup:
        forensic_flags.append(
            f"Hidden Lease Rate Markup: Implied MF {implied_mf:.5f} ({implied_apr:.2f}% APR) vs base {base_mf:.5f} ({base_apr:.2f}% APR) -> +${monthly_overcharge:,.2f}/mo (+${total_overcharge:,.2f} over {term} mos)."
        )
    if addons_val > 0:
        forensic_flags.append(f"Strip ${addons_val:,.0f} in dealer add-ons from gross cap cost.")
    if fees_val > 450:
        forensic_flags.append(f"DMV/MVC fee padding (${fees_val:,.0f} vs ~$400 NJ standard).")

    ready_counter = (
        f"I reviewed your lease worksheet on the 2027 Telluride Hybrid (MSRP ${msrp:,.0f}). "
        f"Your payment of ${quoted_monthly_payment:,.0f}/mo reflects an implied Money Factor of {implied_mf:.5f} ({implied_apr:.2f}% APR) "
        f"instead of Kia's Tier 1 buy rate of {base_mf:.5f} ({base_apr:.2f}% APR), adding ${total_overcharge:,.0f} in finance reserve. "
        f"Remove any add-ons and write the lease at the base {base_mf:.5f} MF (${honest_monthly_payment:,.0f}/mo) and I will place a deposit today."
    )

    return {
        "ok": True,
        "mode": "MODE_4_WORKSHEET_AUDIT",
        "residual_pct": round((residual_dollar / msrp) * 100.0, 1) if msrp > 0 else 0.0,
        "implied_mf": round(implied_mf, 5),
        "implied_dealer_mf": round(implied_mf, 5),
        "implied_apr_pct": round(implied_apr, 2),
        "base_mf": round(base_mf, 5),
        "base_apr_pct": round(base_apr, 2),
        "honest_monthly_payment": round(honest_monthly_payment, 2),
        "quoted_monthly_payment": round(quoted_monthly_payment, 2),
        "hidden_monthly_markup": round(monthly_overcharge, 2),
        "total_36mo_overcharge": round(total_overcharge, 2),
        "has_mf_markup": has_markup,
        "forensic_flags": forensic_flags,
        "ready_to_send_counter": ready_counter,
        "audit_summary": (
            f"🚨 Hidden Lease Rate Markup Detected: Implied MF is {implied_mf:.5f} ({implied_apr:.2f}% APR) vs. "
            f"base {base_mf:.5f} ({base_apr:.2f}% APR) — padding payment by +${monthly_overcharge:,.2f}/mo "
            f"(${total_overcharge:,.2f} over {term} months)."
            if has_markup
            else f"✅ Clean Money Factor Verified: Implied MF {implied_mf:.5f} ({implied_apr:.2f}% APR) matches base rate."
        ),
    }

