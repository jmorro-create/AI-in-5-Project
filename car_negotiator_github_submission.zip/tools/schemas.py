"""
Explicit JSON & Pydantic Validation Schemas and Guided Error Recovery Engine.

Implements Category 1 (Explicit JSON Schemas & Guided Error Handling):
1. Strict Pydantic `BaseModel` input and output schemas constraining tool arguments and LLM responses.
2. `InventorySearchResponseSchema` & `ScrapedVehicleSchema` for structured LLM JSON generation (`response_schema`).
3. `build_guided_error` & `validate_tool_input` returning descriptive, actionable recovery instructions
   to the LLM instead of raising unhandled exceptions when invalid parameters are supplied.
"""

from typing import Any, Callable, Dict, List, Literal, Optional, Type, TypeVar, get_args, get_origin

try:
    from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator
except ImportError:

    class ValidationError(ValueError):
        """Pydantic v2-compatible ValidationError fallback when running in stdlib-only environments."""

        def __init__(self, errors: List[Dict[str, Any]]) -> None:
            self._errors = errors
            super().__init__(str(errors))

        def errors(self) -> List[Dict[str, Any]]:
            return self._errors

    def ConfigDict(**kwargs: Any) -> Dict[str, Any]:  # noqa: N802
        return dict(kwargs)

    class _FieldInfo:
        def __init__(
            self,
            default: Any = ...,
            *,
            default_factory: Optional[Callable[[], Any]] = None,
            gt: Optional[float] = None,
            ge: Optional[float] = None,
            lt: Optional[float] = None,
            le: Optional[float] = None,
            min_length: Optional[int] = None,
            max_length: Optional[int] = None,
            description: str = "",
        ) -> None:
            self.default = default
            self.default_factory = default_factory
            self.gt = gt
            self.ge = ge
            self.lt = lt
            self.le = le
            self.min_length = min_length
            self.max_length = max_length
            self.description = description

    def Field(  # noqa: N802
        default: Any = ...,
        *,
        default_factory: Optional[Callable[[], Any]] = None,
        gt: Optional[float] = None,
        ge: Optional[float] = None,
        lt: Optional[float] = None,
        le: Optional[float] = None,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        description: str = "",
    ) -> Any:
        return _FieldInfo(
            default=default,
            default_factory=default_factory,
            gt=gt,
            ge=ge,
            lt=lt,
            le=le,
            min_length=min_length,
            max_length=max_length,
            description=description,
        )

    def field_validator(*field_names: str) -> Callable[[Any], Any]:
        def decorator(fn: Any) -> Any:
            target = fn.__func__ if isinstance(fn, classmethod) else fn
            setattr(target, "__pydantic_validator_fields__", field_names)
            return classmethod(target)

        return decorator

    class BaseModel:
        """Pydantic v2-compatible BaseModel fallback supporting Field constraints, validators, model_validate, model_dump, and model_json_schema."""

        model_config: Dict[str, Any] = {"extra": "ignore"}

        def __init__(self, **data: Any) -> None:
            validated = self._validate_dict(data)
            for k, v in validated.items():
                setattr(self, k, v)

        @classmethod
        def _validate_dict(cls, data: Dict[str, Any]) -> Dict[str, Any]:
            annotations = getattr(cls, "__annotations__", {})
            errors: List[Dict[str, Any]] = []
            result: Dict[str, Any] = {}

            validators: Dict[str, List[Callable[..., Any]]] = {}
            for attr_name in dir(cls):
                attr_val = getattr(cls, attr_name, None)
                raw_fn = getattr(attr_val, "__func__", attr_val)
                v_fields = getattr(raw_fn, "__pydantic_validator_fields__", None)
                if v_fields and callable(raw_fn):
                    for f_name in v_fields:
                        validators.setdefault(f_name, []).append(raw_fn)

            for field_name, field_type in annotations.items():
                if field_name == "model_config":
                    continue
                class_default = getattr(cls, field_name, ...)
                field_info = class_default if isinstance(class_default, _FieldInfo) else None

                if field_name in data and data[field_name] is not None:
                    val = data[field_name]
                elif field_name in data and data[field_name] is None:
                    val = None
                elif field_info is not None:
                    if field_info.default_factory is not None:
                        val = field_info.default_factory()
                    elif field_info.default is not ...:
                        val = field_info.default
                    else:
                        errors.append(
                            {
                                "loc": (field_name,),
                                "msg": "Field required",
                                "input": None,
                            }
                        )
                        continue
                elif class_default is not ...:
                    val = class_default
                else:
                    errors.append(
                        {
                            "loc": (field_name,),
                            "msg": "Field required",
                            "input": None,
                        }
                    )
                    continue

                origin = get_origin(field_type)
                args = get_args(field_type)

                if origin is Literal and val not in args:
                    errors.append(
                        {
                            "loc": (field_name,),
                            "msg": f"Input should be one of {args}",
                            "input": val,
                        }
                    )
                    continue

                if val is not None:
                    if field_type is float or (origin is not None and float in args):
                        try:
                            val = float(val)
                        except (TypeError, ValueError):
                            errors.append(
                                {
                                    "loc": (field_name,),
                                    "msg": "Input should be a valid number",
                                    "input": val,
                                }
                            )
                            continue
                    elif field_type is int and not isinstance(val, bool):
                        try:
                            val = int(val)
                        except (TypeError, ValueError):
                            errors.append(
                                {
                                    "loc": (field_name,),
                                    "msg": "Input should be a valid integer",
                                    "input": val,
                                }
                            )
                            continue
                    elif field_type is str:
                        val = str(val)

                if field_info is not None and val is not None:
                    if field_info.gt is not None and not (val > field_info.gt):
                        errors.append(
                            {
                                "loc": (field_name,),
                                "msg": f"Input should be greater than {field_info.gt}",
                                "input": val,
                            }
                        )
                        continue
                    if field_info.ge is not None and not (val >= field_info.ge):
                        errors.append(
                            {
                                "loc": (field_name,),
                                "msg": f"Input should be greater than or equal to {field_info.ge}",
                                "input": val,
                            }
                        )
                        continue
                    if field_info.lt is not None and not (val < field_info.lt):
                        errors.append(
                            {
                                "loc": (field_name,),
                                "msg": f"Input should be less than {field_info.lt}",
                                "input": val,
                            }
                        )
                        continue
                    if field_info.le is not None and not (val <= field_info.le):
                        errors.append(
                            {
                                "loc": (field_name,),
                                "msg": f"Input should be less than or equal to {field_info.le}",
                                "input": val,
                            }
                        )
                        continue
                    if field_info.min_length is not None and hasattr(val, "__len__") and len(val) < field_info.min_length:
                        errors.append(
                            {
                                "loc": (field_name,),
                                "msg": f"String should have at least {field_info.min_length} characters",
                                "input": val,
                            }
                        )
                        continue
                    if field_info.max_length is not None and hasattr(val, "__len__") and len(val) > field_info.max_length:
                        errors.append(
                            {
                                "loc": (field_name,),
                                "msg": f"String should have at most {field_info.max_length} characters",
                                "input": val,
                            }
                        )
                        continue

                for v_fn in validators.get(field_name, []):
                    try:
                        val = v_fn(cls, val)
                    except ValueError as exc:
                        errors.append(
                            {
                                "loc": (field_name,),
                                "msg": str(exc),
                                "input": val,
                            }
                        )

                result[field_name] = val

            if errors:
                raise ValidationError(errors)

            if cls.model_config.get("extra") == "allow":
                for k, v in data.items():
                    if k not in result:
                        result[k] = v

            return result

        @classmethod
        def model_validate(cls: Type["TModel"], data: Dict[str, Any]) -> "TModel":
            obj = cls.__new__(cls)
            validated = cls._validate_dict(data)
            for k, v in validated.items():
                setattr(obj, k, v)
            return obj

        def model_dump(self) -> Dict[str, Any]:
            return dict(self.__dict__)

        @classmethod
        def model_json_schema(cls) -> Dict[str, Any]:
            annotations = getattr(cls, "__annotations__", {})
            props: Dict[str, Any] = {}
            required: List[str] = []
            for field_name, field_type in annotations.items():
                if field_name == "model_config":
                    continue
                class_default = getattr(cls, field_name, ...)
                field_info = class_default if isinstance(class_default, _FieldInfo) else None
                desc = field_info.description if field_info else ""
                props[field_name] = {"title": field_name, "description": desc, "type": str(field_type)}
                if (field_info is not None and field_info.default is ... and field_info.default_factory is None) or (
                    field_info is None and class_default is ...
                ):
                    required.append(field_name)
            return {
                "title": cls.__name__,
                "type": "object",
                "properties": props,
                "required": required,
            }


DealTypeLiteral = Literal["PURCHASE", "LEASE"]
ChannelLiteral = Literal["EMAIL", "SMS_PERSONAL", "SMS_TWILIO"]
AutonomyModeLiteral = Literal["FULL_AUTOPILOT", "SEMI_AUTO", "COPILOT"]
InventoryStatusLiteral = Literal["IN_TRANSIT", "ON_LOT", "SOLD"]

TModel = TypeVar("TModel", bound=BaseModel)


def build_guided_error(
    error_code: str = "",
    message: str = "",
    recovery_instructions: str = "",
    invalid_fields: Optional[Dict[str, Any]] = None,
    extra_context: Optional[Dict[str, Any]] = None,
    *,
    error_type: str = "",
    context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Constructs a standardized, LLM-guided error payload with actionable recovery instructions.

    Args:
        error_code (str): Machine-readable error code (e.g., 'INVALID_PARAMETER_RANGE', 'DEALER_NOT_FOUND').
        message (str): Clear human- and LLM-readable description of what went wrong.
        recovery_instructions (str): Step-by-step instructions telling the LLM how to fix its tool call.
        invalid_fields (Optional[Dict[str, Any]]): Map of offending field names to provided values.
        extra_context (Optional[Dict[str, Any]]): Additional keys required by callers (e.g. `approved_count=0`).
        error_type (str): Optional alias for `error_code`.
        context (Optional[Dict[str, Any]]): Optional alias for `extra_context`.

    Returns:
        Dict[str, Any]: Structured error dictionary containing `ok=False`, `error`, `error_type`, and `recovery_instructions`.
    """
    eff_code = error_code or error_type or "TOOL_EXECUTION_ERROR"
    eff_type = (
        error_type
        or ("SCHEMA_VALIDATION_ERROR" if eff_code.startswith("SCHEMA_VALIDATION_ERROR") else eff_code)
    )
    merged_ctx: Dict[str, Any] = {}
    if extra_context:
        merged_ctx.update(extra_context)
    if context:
        merged_ctx.update(context)
    payload: Dict[str, Any] = {
        "ok": False,
        "error_code": eff_code,
        "error_type": eff_type,
        "error": message,
        "recovery_instructions": recovery_instructions,
        "invalid_fields": invalid_fields or {},
        "context": merged_ctx,
    }
    if merged_ctx:
        payload.update(merged_ctx)
    return payload


class OTDCalculationInputSchema(BaseModel):
    """Strict input schema for `calculate_otd_price`."""

    model_config = ConfigDict(extra="ignore")

    msrp: float = Field(..., gt=0.0, le=250000.0, description="Vehicle sticker MSRP in USD (e.g. 53890.0).")
    selling_price: float = Field(..., gt=0.0, le=250000.0, description="Negotiated vehicle selling price before tax/fees in USD.")
    doc_fee: float = Field(default=499.0, ge=0.0, le=5000.0, description="Dealer documentation fee in USD.")
    gov_fees: float = Field(default=385.0, ge=0.0, le=5000.0, description="Government MVC registration and title fees in USD.")
    tax_rate_percent: float = Field(default=6.625, ge=0.0, le=25.0, description="Sales tax rate as a percentage (e.g. 6.625 for NJ).")
    dealer_addons_total: float = Field(default=0.0, ge=0.0, le=50000.0, description="Total dollar amount of dealer-installed add-ons.")
    rebates: float = Field(default=0.0, ge=0.0, le=50000.0, description="Manufacturer rebates and incentives in USD.")
    addon_descriptions: str = Field(default="", max_length=500, description="Comma-separated description of dealer add-ons.")
    prevailing_market_discount_pct: float = Field(default=3.8, ge=0.0, le=30.0, description="Prevailing NJ market discount percentage off MSRP.")
    stretch_counter_discount_pct: float = Field(default=5.0, ge=0.0, le=35.0, description="Stretch target discount percentage off MSRP.")
    invoice_below_msrp_pct: float = Field(default=3.8, ge=0.0, le=25.0, description="Dealer invoice percentage below MSRP.")

    @field_validator("tax_rate_percent")
    @classmethod
    def check_tax_not_decimal_fraction(cls, v: float) -> float:
        if 0.0 < v < 0.25:
            raise ValueError(
                f"tax_rate_percent={v} looks like a decimal ratio. Pass percentage points (e.g. 6.625 for 6.625% NJ tax)."
            )
        return v


class OTDCalculationOutputSchema(BaseModel):
    """Strict output schema for `calculate_otd_price`."""

    model_config = ConfigDict(extra="allow")

    deal_type: DealTypeLiteral = "PURCHASE"
    msrp: float
    selling_price: float
    discount_off_msrp: float
    discount_pct: float
    estimated_invoice_price: float
    prevailing_market_discount_pct: float
    prevailing_market_selling_price: float
    stretch_counter_discount_pct: float
    target_selling_price: float
    vs_prevailing_market_dollars: float
    rebates: float
    doc_fee: float
    gov_fees: float
    dealer_addons_total: float
    addon_descriptions: str
    tax_rate_percent: float
    sales_tax: float
    otd_total: float
    clean_otd_without_addons: float
    potential_addon_savings: float
    red_flags: List[str]


class ReverseOTDInputSchema(BaseModel):
    """Strict input schema for `calculate_monthly_from_otd`."""

    model_config = ConfigDict(extra="ignore")

    otd_price: float = Field(..., gt=0.0, le=300000.0, description="Negotiated or target Out-The-Door total price in USD.")
    msrp: float = Field(default=53890.0, gt=0.0, le=250000.0, description="Vehicle sticker MSRP in USD.")
    tax_rate_percent: float = Field(default=6.625, ge=0.0, le=25.0, description="Sales tax rate percentage (6.625 for NJ).")
    doc_fee: float = Field(default=499.0, ge=0.0, le=5000.0, description="Dealer doc fee in USD.")
    gov_fees: float = Field(default=385.0, ge=0.0, le=5000.0, description="Non-taxable government MVC fees in USD.")
    rebates: float = Field(default=500.0, ge=0.0, le=50000.0, description="Manufacturer rebates in USD.")
    cash_down_or_trade_equity: float = Field(default=0.0, ge=0.0, le=150000.0, description="Cash down or net trade equity in USD.")
    loan_apr_percent: float = Field(default=4.9, ge=0.0, le=35.0, description="Annual Percentage Rate (APR) for loan financing.")
    loan_term_months: int = Field(default=60, ge=12, le=96, description="Loan term in months (e.g. 48, 60, 72).")
    lease_term_months: int = Field(default=36, ge=12, le=60, description="Lease term in months (e.g. 24, 36, 39).")
    lease_annual_miles: int = Field(default=12000, ge=5000, le=30000, description="Annual lease mileage allowance (e.g. 10000, 12000, 15000).")
    residual_percent: float = Field(default=63.0, ge=20.0, le=90.0, description="Lease residual percentage of MSRP (e.g. 62.0 or 63.0).")
    money_factor: float = Field(default=0.00190, ge=0.0, le=0.02, description="Lease money factor (e.g. 0.00190 for 4.56% APR).")
    acquisition_fee: float = Field(default=650.0, ge=0.0, le=3000.0, description="Lease bank acquisition fee in USD.")

    @field_validator("residual_percent")
    @classmethod
    def check_residual_scale(cls, v: float) -> float:
        if 0.0 < v <= 1.0:
            raise ValueError(
                f"residual_percent={v} was passed as a decimal fraction. Pass percentage points between 20.0 and 90.0 (e.g. 62.0 for 62%)."
            )
        return v


class LeaseCalculationInputSchema(BaseModel):
    """Strict input schema for `calculate_lease_payment`."""

    model_config = ConfigDict(extra="ignore")

    msrp: float = Field(..., gt=0.0, le=250000.0, description="Vehicle MSRP in USD.")
    selling_price: float = Field(..., gt=0.0, le=250000.0, description="Agreed vehicle selling price (gross cap cost before add-ons) in USD.")
    residual_percent: float = Field(..., ge=20.0, le=90.0, description="Residual value percentage of MSRP (e.g. 62.0).")
    money_factor: float = Field(..., ge=0.0, le=0.02, description="Quoted lease money factor (e.g. 0.00190).")
    term_months: int = Field(default=36, ge=12, le=60, description="Lease term in months.")
    annual_miles: int = Field(default=12000, ge=5000, le=30000, description="Annual lease mileage allowance.")
    tax_rate_percent: float = Field(default=6.625, ge=0.0, le=25.0, description="Sales tax rate percentage (6.625 for NJ).")
    acquisition_fee: float = Field(default=650.0, ge=0.0, le=3000.0, description="Captive lease bank acquisition fee in USD.")
    doc_fee: float = Field(default=499.0, ge=0.0, le=5000.0, description="Dealer doc fee in USD.")
    gov_fees: float = Field(default=385.0, ge=0.0, le=5000.0, description="Government MVC title/registration fees in USD.")
    dealer_addons_total: float = Field(default=0.0, ge=0.0, le=50000.0, description="Dealer add-ons rolled into cap cost in USD.")
    rebates_and_lease_cash: float = Field(default=0.0, ge=0.0, le=50000.0, description="Manufacturer lease cash and rebates in USD.")
    cap_cost_reduction_down: float = Field(default=0.0, ge=0.0, le=100000.0, description="Upfront cap cost reduction cash down in USD.")
    base_buy_rate_mf: float = Field(default=0.00190, ge=0.0, le=0.02, description="Tier-1 base buy-rate money factor (0.00190 for KMF).")


class AuditDealerQuoteInputSchema(BaseModel):
    """Strict input schema for `audit_dealer_quote`."""

    model_config = ConfigDict(extra="ignore")

    deal_type: DealTypeLiteral = Field(..., description="Quote mode: 'PURCHASE' or 'LEASE'.")
    msrp: float = Field(..., gt=0.0, le=250000.0, description="Vehicle sticker MSRP in USD.")
    selling_price: float = Field(..., gt=0.0, le=250000.0, description="Dealer quoted selling price / cap cost in USD.")
    dealer_quoted_otd: Optional[float] = Field(default=0.0, ge=0.0, le=300000.0, description="Dealer's stated total Out-The-Door price in USD.")
    dealer_quoted_monthly: Optional[float] = Field(default=0.0, ge=0.0, le=10000.0, description="Dealer's stated monthly lease/loan payment in USD.")
    dealer_quoted_drive_off: Optional[float] = Field(default=0.0, ge=0.0, le=50000.0, description="Dealer's stated drive-off amount due at signing in USD.")
    residual_percent: float = Field(default=63.0, ge=20.0, le=90.0, description="Lease residual value percentage of MSRP.")
    money_factor: float = Field(default=0.00190, ge=0.0, le=0.02, description="Dealer quoted lease money factor.")
    base_buy_rate_mf: float = Field(default=0.00190, ge=0.0, le=0.02, description="Captive bank Tier-1 buy-rate money factor.")
    term_months: int = Field(default=36, ge=12, le=84, description="Lease or loan term in months.")
    annual_miles: int = Field(default=12000, ge=5000, le=30000, description="Annual lease mileage allowance.")
    doc_fee: float = Field(default=499.0, ge=0.0, le=5000.0, description="Dealer documentation fee in USD.")
    gov_fees: float = Field(default=385.0, ge=0.0, le=5000.0, description="Government MVC registration/title fees in USD.")
    acquisition_fee: float = Field(default=650.0, ge=0.0, le=3000.0, description="Lease acquisition fee in USD.")
    dealer_addons_total: float = Field(default=0.0, ge=0.0, le=50000.0, description="Dealer-installed add-ons total in USD.")
    rebates: float = Field(default=0.0, ge=0.0, le=50000.0, description="Manufacturer rebates in USD.")
    cap_cost_reduction_down: float = Field(default=0.0, ge=0.0, le=100000.0, description="Upfront cap cost reduction down payment in USD.")
    tax_rate_percent: float = Field(default=6.625, ge=0.0, le=25.0, description="Sales tax percentage (6.625 for NJ).")


class MarketBenchmarkUpdateInputSchema(BaseModel):
    """Strict input schema for `update_market_benchmark`."""

    model_config = ConfigDict(extra="ignore")

    prevailing_market_discount_pct: float = Field(default=3.8, ge=0.0, le=25.0, description="Prevailing NJ market discount % off MSRP.")
    stretch_target_discount_pct: float = Field(default=5.0, ge=0.0, le=30.0, description="Top-decile stretch counter target discount % off MSRP.")
    invoice_below_msrp_pct: float = Field(default=3.8, ge=0.0, le=20.0, description="Factory invoice percentage below MSRP.")
    dealer_holdback_pct: float = Field(default=2.0, ge=0.0, le=10.0, description="Manufacturer dealer holdback percentage of MSRP.")
    kia_incentives_rebates: float = Field(default=500.0, ge=0.0, le=25000.0, description="Current manufacturer rebates/incentives in USD.")
    market_intel_notes: str = Field(default="", max_length=2000, description="Optional notes summarizing new market comp findings.")


class QueueDealerMessageInputSchema(BaseModel):
    """Strict input schema for `queue_dealer_message`."""

    model_config = ConfigDict(extra="ignore")

    dealer_id: str = Field(..., min_length=2, max_length=120, description="Target dealer ID (e.g. 'dlr-raceway-kia-of-freehold').")
    body: str = Field(..., min_length=5, max_length=4000, description="Outbound negotiation SMS or email text.")
    channel: str = Field(default="SMS_PERSONAL", description="Communication channel: 'EMAIL', 'SMS_PERSONAL', or 'SMS_TWILIO'.")
    subject: str = Field(default="", max_length=300, description="Optional email subject line.")
    auto_dispatch: bool = Field(default=False, description="If False (Copilot mode), queues in PENDING_APPROVAL for human confirmation.")


class InboundDealerWebhookSchema(BaseModel):
    """Strict input schema for `ingest_live_dealer_message` (live SMS/Email webhook or inbox sync)."""

    model_config = ConfigDict(extra="ignore")

    dealer_id: str = Field(default="", max_length=120, description="Optional dealer ID if known (e.g. 'dlr-raceway-kia-of-freehold').")
    sender_contact: str = Field(default="", max_length=200, description="Sender phone number (e.g. '+17324624422') or email address.")
    channel: str = Field(default="SMS_PERSONAL", description="Inbound channel: 'EMAIL', 'SMS_PERSONAL', or 'SMS_TWILIO'.")
    raw_body: str = Field(..., min_length=2, max_length=15000, description="Raw inbound dealer SMS text or email body.")
    subject: str = Field(default="", max_length=400, description="Email subject line (for single-thread continuity).")
    external_message_id: str = Field(default="", max_length=300, description="RFC 5322 Message-ID or SMS gateway message ID.")
    thread_id: str = Field(default="", max_length=200, description="Gmail threadId or conversation thread identifier.")
    in_reply_to: str = Field(default="", max_length=300, description="RFC 5322 In-Reply-To header.")
    references: str = Field(default="", max_length=2000, description="RFC 5322 References header chain.")
    auto_draft_counter: bool = Field(default=True, description="If True, automatically generates a Copilot counter-offer in PENDING_APPROVAL.")


class UpdateDealerContactInputSchema(BaseModel):
    """Strict input schema for `update_dealer_contact_info`."""

    model_config = ConfigDict(extra="ignore")

    dealer_id: str = Field(..., min_length=2, max_length=120, description="Target dealer ID (e.g. 'dlr-raceway-kia-of-freehold').")
    contact_name: str = Field(default="", max_length=120, description="Real salesperson or Internet Director name.")
    contact_phone: str = Field(default="", max_length=40, description="Real salesperson mobile/SMS phone number.")
    contact_email: str = Field(default="", max_length=200, description="Real salesperson email address.")
    preferred_channel: str = Field(default="", max_length=40, description="Preferred channel ('SMS_PERSONAL', 'EMAIL', or 'SMS_TWILIO').")


class CalculateNJPaymentsInputSchema(BaseModel):
    """Strict input schema for `calculate_nj_payments` (V3 NJ Purchase + Lease + True Deal Score + $0 Sign & Drive)."""

    model_config = ConfigDict(extra="ignore")

    msrp: float = Field(..., gt=0.0, le=250000.0, description="Vehicle sticker MSRP in USD (e.g. 56035.0).")
    selling_price: float = Field(..., gt=0.0, le=250000.0, description="Quoted or target selling price before tax/fees in USD.")
    doc_fee: float = Field(default=749.0, ge=0.0, le=5000.0, description="NJ dealer documentation fee in USD.")
    addons: float = Field(default=0.0, ge=0.0, le=50000.0, description="Mandatory or quoted dealer add-ons in USD.")
    mv_tire_fees: float = Field(default=400.0, ge=0.0, le=5000.0, description="NJ MVC registration, title, and tire fees in USD.")
    rebates: float = Field(default=750.0, ge=0.0, le=50000.0, description="Stackable Kia factory rebates (e.g. $750 Loyalty/Conquest).")
    cash_down: float = Field(default=3000.0, ge=0.0, le=150000.0, description="Personal cash down / out-of-pocket in USD.")
    loan_apr: float = Field(default=4.49, ge=0.0, le=35.0, description="Loan APR percentage (e.g. 4.49).")
    loan_term: int = Field(default=60, ge=12, le=96, description="Loan term in months (default 60).")
    lease_mf: float = Field(default=0.00245, ge=0.0, le=0.02, description="Lease Money Factor (default 0.00245 ~ 5.88% APR).")
    lease_residual_pct: float = Field(default=0.62, gt=0.10, le=90.0, description="Lease residual ratio (e.g. 0.62 or 62.0).")
    lease_term: int = Field(default=36, ge=12, le=60, description="Lease term in months (default 36).")
    target_monthly_budget: float = Field(default=750.0, ge=0.0, le=10000.0, description="Target monthly lease/loan budget in USD.")


class AuditUploadedLeaseSheetInputSchema(BaseModel):
    """Strict input schema for `audit_uploaded_lease_sheet` (Mode 4 reverse-engineered Money Factor audit)."""

    model_config = ConfigDict(extra="ignore")

    msrp: float = Field(..., gt=0.0, le=250000.0, description="Vehicle sticker MSRP in USD.")
    adj_cap_cost: float = Field(..., gt=0.0, le=250000.0, description="Adjusted Capitalized Cost on dealer worksheet in USD.")
    residual_dollar: float = Field(..., gt=0.0, le=250000.0, description="Residual dollar value on dealer worksheet in USD.")
    quoted_monthly_payment: float = Field(..., gt=0.0, le=10000.0, description="Dealer's quoted monthly lease payment in USD.")
    term: int = Field(default=36, ge=12, le=60, description="Lease term in months (default 36).")
    base_mf: float = Field(default=0.00245, ge=0.0, le=0.02, description="Base Kia Tier 1 Money Factor (default 0.00245).")


def validate_tool_input(
    schema_cls: Type[TModel],
    raw_kwargs: Dict[str, Any],
    tool_name: str,
    recovery_hint: str,
) -> tuple[Optional[TModel], Optional[Dict[str, Any]]]:
    """Validates tool input arguments against a Pydantic schema and returns a guided error dict on failure.

    Args:
        schema_cls (Type[TModel]): Pydantic `BaseModel` class to validate against.
        raw_kwargs (Dict[str, Any]): Raw keyword arguments passed to the tool.
        tool_name (str): Name of the tool being called.
        recovery_hint (str): Specific guidance for the LLM on how to correct invalid inputs.

    Returns:
        tuple[Optional[TModel], Optional[Dict[str, Any]]]: `(validated_model, None)` on success, or `(None, guided_error_dict)` on validation error.
    """
    try:
        validated = schema_cls.model_validate(raw_kwargs)
        return validated, None
    except ValidationError as exc:
        bad_fields: Dict[str, Any] = {}
        err_Details: List[str] = []
        for err in exc.errors():
            loc = ".".join(str(x) for x in err.get("loc", ()))
            msg = err.get("msg", "Invalid value")
            inp = err.get("input")
            bad_fields[loc] = inp
            err_Details.append(f"{loc}: {msg} (received {inp!r})")
        return None, build_guided_error(
            error_code=f"SCHEMA_VALIDATION_ERROR_{tool_name.upper()}",
            message=f"Invalid input arguments for `{tool_name}`: {'; '.join(err_Details)}",
            recovery_instructions=recovery_hint,
            invalid_fields=bad_fields,
        )

