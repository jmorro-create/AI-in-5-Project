"""
Observability, Structured JSON Logging, Intent-vs-Outcome Capture, and Regex PII Redaction Layer.
"""

from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
import functools
import json
import logging
import os
import re
import time
from typing import Any, Callable, Dict, Iterator, List, Optional, TypeVar
import uuid

F = TypeVar("F", bound=Callable[..., Any])

# Context variables for trace correlation across HTTP -> ADK Runner -> Tools
_CURRENT_TRACE_ID: ContextVar[str] = ContextVar("current_trace_id", default="")
_CURRENT_SPAN_ID: ContextVar[str] = ContextVar("current_span_id", default="")
_CURRENT_SESSION_ID: ContextVar[str] = ContextVar("current_session_id", default="default-session")

# In-memory ring buffers for verification and test inspection
_STRUCTURED_LOG_BUFFER: List[Dict[str, Any]] = []
_INTENT_OUTCOME_AUDIT_BUFFER: List[Dict[str, Any]] = []
_RECORDED_SPANS_BUFFER: List[Dict[str, Any]] = []
_MAX_BUFFER_SIZE = 500

# Deterministic PII Regex Patterns (Phone, Email, SSN, Credit Card)
_PII_PATTERNS = [
    (
        re.compile(r"\b(?:\+?1[-.\s]?)?\(?([2-9][0-9]{2})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})\b"),
        "[REDACTED_PHONE]",
    ),
    (
        re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
        "[REDACTED_EMAIL]",
    ),
    (
        re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
        "[REDACTED_SSN]",
    ),
    (
        re.compile(r"\b(?:\d[ -]*?){13,16}\b"),
        "[REDACTED_CARD]",
    ),
]


def redact_pii(value: Any, project_id: Optional[str] = None) -> Any:
    """Recursively scrubs PII (phone numbers, emails, SSNs, credit cards) from strings, dicts, and lists using regex patterns.

    Args:
        value (Any): String, dictionary, list, or primitive value to sanitize.
        project_id (Optional[str]): Unused optional project ID parameter retained for signature compatibility.

    Returns:
        Any: Sanitized copy of `value` with PII replaced by redaction tokens.
    """
    if value is None or isinstance(value, (bool, int, float)):
        return value

    if isinstance(value, str):
        if not value:
            return value
        sanitized = value
        for pattern, replacement in _PII_PATTERNS:
            sanitized = pattern.sub(replacement, sanitized)
        return sanitized

    if isinstance(value, dict):
        redacted_dict: Dict[str, Any] = {}
        sensitive_keys = {
            "buyer_phone",
            "user_mobile",
            "credit_card",
            "ssn",
            "auth_token",
            "api_key",
            "password",
        }
        for k, v in value.items():
            k_str = str(k)
            if k_str.lower() in sensitive_keys and v:
                redacted_dict[k_str] = "[REDACTED_PII]"
            else:
                redacted_dict[k_str] = redact_pii(v, project_id=project_id)
        return redacted_dict

    if isinstance(value, (list, tuple)):
        return [redact_pii(item, project_id=project_id) for item in value]

    return str(value)


class StructuredJsonFormatter(logging.Formatter):
    """Formats Python log records as single-line Google Cloud Logging structured JSON objects."""

    def format(self, record: logging.LogRecord) -> str:
        trace_id = getattr(record, "trace_id", None) or _CURRENT_TRACE_ID.get() or uuid.uuid4().hex
        span_id = getattr(record, "span_id", None) or _CURRENT_SPAN_ID.get() or uuid.uuid4().hex[:16]
        session_id = getattr(record, "session_id", None) or _CURRENT_SESSION_ID.get()
        project_id = os.environ.get("FIRESTORE_PROJECT_ID", "agy-sandbox-22ebe")

        payload: Dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "severity": record.levelname,
            "logger": record.name,
            "message": redact_pii(record.getMessage()),
            "component": getattr(record, "component", "car_negotiator"),
            "event_type": getattr(record, "event_type", "GENERAL_LOG"),
            "session_id": session_id,
            "trace_id": trace_id,
            "span_id": span_id,
            "logging.googleapis.com/trace": f"projects/{project_id}/traces/{trace_id}",
            "logging.googleapis.com/spanId": span_id,
        }
        extra_meta = getattr(record, "metadata", None)
        if extra_meta is not None:
            payload["metadata"] = redact_pii(extra_meta)

        if len(_STRUCTURED_LOG_BUFFER) >= _MAX_BUFFER_SIZE:
            _STRUCTURED_LOG_BUFFER.pop(0)
        _STRUCTURED_LOG_BUFFER.append(payload)
        return json.dumps(payload, default=str)


def get_structured_logger(name: str = "car_negotiator") -> logging.Logger:
    """Returns a configured Python `Logger` emitting structured JSON records with PII redaction.

    Args:
        name (str): Logger name (defaults to 'car_negotiator').

    Returns:
        logging.Logger: Configured structured JSON logger instance.
    """
    logger = logging.getLogger(name)
    if not getattr(logger, "_car_negotiator_configured", False):
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler()
        handler.setFormatter(StructuredJsonFormatter())
        logger.handlers = [handler]
        logger.propagate = False
        setattr(logger, "_car_negotiator_configured", True)
    return logger


_LOGGER = get_structured_logger("car_negotiator.agentops")


def log_structured_event(
    event_type: str,
    message: str = "",
    severity: str = "INFO",
    component: str = "car_negotiator",
    metadata: Optional[Dict[str, Any]] = None,
    session_id: Optional[str] = None,
    level: Optional[str] = None,
    **extra_fields: Any,
) -> Dict[str, Any]:
    """Emits a structured JSON log entry with automatic PII scrubbing and trace correlation.

    Args:
        event_type (str): Categorized event identifier (e.g., 'TOOL_INTENT', 'TOOL_OUTCOME', 'GUARDRAIL_BLOCK').
        message (str): Human-readable summary of the event. Defaults to `event_type` when omitted.
        severity (str): Log severity ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL').
        component (str): Subsystem emitting the log.
        metadata (Optional[Dict[str, Any]]): Rich structured dictionary payload.
        session_id (Optional[str]): Optional session identifier override.
        level (Optional[str]): Optional alias for `severity`.
        **extra_fields (Any): Additional structured key-value fields merged into `metadata`.

    Returns:
        Dict[str, Any]: The structured, PII-redacted log record emitted.
    """
    eff_severity = (level or severity or "INFO").upper()
    log_level = getattr(logging, eff_severity, logging.INFO)
    merged_meta: Dict[str, Any] = dict(metadata or {})
    if extra_fields:
        merged_meta.update(extra_fields)
    eff_message = message or event_type
    extra = {
        "component": component,
        "event_type": event_type,
        "metadata": merged_meta,
        "session_id": session_id or _CURRENT_SESSION_ID.get(),
        "trace_id": _CURRENT_TRACE_ID.get() or uuid.uuid4().hex,
        "span_id": _CURRENT_SPAN_ID.get() or uuid.uuid4().hex[:16],
    }
    _LOGGER.log(log_level, eff_message, extra=extra)
    return _STRUCTURED_LOG_BUFFER[-1] if _STRUCTURED_LOG_BUFFER else extra


# ==============================================================================
# Lightweight Span Context Manager
# ==============================================================================
@contextmanager
def start_trace_span(
    span_name: str,
    attributes: Optional[Dict[str, Any]] = None,
    session_id: Optional[str] = None,
) -> Iterator[Dict[str, Any]]:
    """Records an in-memory execution span with correlation IDs (`trace_id` and `span_id`).

    Args:
        span_name (str): Name of the span (e.g., 'tool.calculate_monthly_from_otd').
        attributes (Optional[Dict[str, Any]]): Key-value metadata attributes to attach to the span.
        session_id (Optional[str]): Optional session ID to bind to the span context.

    Yields:
        Dict[str, Any]: Span context dictionary containing `trace_id`, `span_id`, `parent_span_id`, and `name`.
    """
    parent_trace_id = _CURRENT_TRACE_ID.get()
    parent_span_id = _CURRENT_SPAN_ID.get()
    trace_id = parent_trace_id or uuid.uuid4().hex
    span_id = uuid.uuid4().hex[:16]

    token_trace = _CURRENT_TRACE_ID.set(trace_id)
    token_span = _CURRENT_SPAN_ID.set(span_id)
    token_sess = _CURRENT_SESSION_ID.set(session_id) if session_id else None

    clean_attrs = redact_pii(attributes or {})
    start_ns = time.time_ns()
    span_info: Dict[str, Any] = {
        "name": span_name,
        "trace_id": trace_id,
        "span_id": span_id,
        "parent_span_id": parent_span_id or None,
        "attributes": clean_attrs,
        "start_time_ns": start_ns,
        "status": "OK",
    }

    try:
        yield span_info
    except Exception as exc:
        span_info["status"] = "ERROR"
        span_info["error"] = redact_pii(str(exc))
        raise
    finally:
        span_info["end_time_ns"] = time.time_ns()
        span_info["duration_ms"] = round((span_info["end_time_ns"] - start_ns) / 1_000_000.0, 3)
        if len(_RECORDED_SPANS_BUFFER) >= _MAX_BUFFER_SIZE:
            _RECORDED_SPANS_BUFFER.pop(0)
        _RECORDED_SPANS_BUFFER.append(dict(span_info))
        _CURRENT_TRACE_ID.reset(token_trace)
        _CURRENT_SPAN_ID.reset(token_span)
        if token_sess is not None:
            _CURRENT_SESSION_ID.reset(token_sess)


# ==============================================================================
# Intent vs. Outcome Capture
# ==============================================================================
def log_tool_intent(
    tool_name: str,
    arguments: Dict[str, Any],
    intent_rationale: str = "",
) -> Dict[str, Any]:
    """Explicitly records the agent's intended action and input parameters BEFORE tool execution.

    Args:
        tool_name (str): Name of the tool about to be executed.
        arguments (Dict[str, Any]): Input arguments supplied to the tool.
        intent_rationale (str): Optional description of why the tool is being invoked.

    Returns:
        Dict[str, Any]: Recorded intent audit entry.
    """
    sanitized_args = redact_pii(arguments)
    entry = {
        "phase": "INTENT_BEFORE_EXECUTION",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "tool_name": tool_name,
        "intended_arguments": sanitized_args,
        "intent_rationale": intent_rationale or f"Execute {tool_name} with validated parameters",
        "trace_id": _CURRENT_TRACE_ID.get() or uuid.uuid4().hex,
        "span_id": _CURRENT_SPAN_ID.get() or uuid.uuid4().hex[:16],
    }
    if len(_INTENT_OUTCOME_AUDIT_BUFFER) >= _MAX_BUFFER_SIZE:
        _INTENT_OUTCOME_AUDIT_BUFFER.pop(0)
    _INTENT_OUTCOME_AUDIT_BUFFER.append(entry)
    log_structured_event(
        event_type="AGENT_TOOL_INTENT",
        message=f"[INTENT] Invoking tool '{tool_name}'",
        component="tool_dispatcher",
        metadata=entry,
    )
    return entry


def log_tool_outcome(
    tool_name: str,
    outcome: Any,
    latency_ms: float,
    status: str = "SUCCESS",
    error_message: str = "",
) -> Dict[str, Any]:
    """Explicitly records the actual outcome, status, and latency AFTER tool execution.

    Args:
        tool_name (str): Name of the executed tool.
        outcome (Any): Return value from the tool execution.
        latency_ms (float): Execution duration in milliseconds.
        status (str): 'SUCCESS', 'GUIDED_ERROR', or 'EXCEPTION'.
        error_message (str): Error description if `status != 'SUCCESS'`.

    Returns:
        Dict[str, Any]: Recorded outcome audit entry.
    """
    if isinstance(outcome, dict) and (outcome.get("ok") is False or "error" in outcome):
        status = "GUIDED_ERROR"
        error_message = str(outcome.get("error") or error_message)

    summary_keys = list(outcome.keys())[:10] if isinstance(outcome, dict) else [type(outcome).__name__]
    entry = {
        "phase": "OUTCOME_AFTER_EXECUTION",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "tool_name": tool_name,
        "status": status,
        "latency_ms": round(latency_ms, 3),
        "outcome_keys": summary_keys,
        "error_message": redact_pii(error_message) if error_message else "",
        "outcome_preview": redact_pii(
            {
                k: outcome[k]
                for k in ("ok", "deal_type", "otd_total", "total_monthly_payment", "status", "error", "recovery_instructions")
                if isinstance(outcome, dict) and k in outcome
            }
        ),
        "trace_id": _CURRENT_TRACE_ID.get() or uuid.uuid4().hex,
        "span_id": _CURRENT_SPAN_ID.get() or uuid.uuid4().hex[:16],
    }
    if len(_INTENT_OUTCOME_AUDIT_BUFFER) >= _MAX_BUFFER_SIZE:
        _INTENT_OUTCOME_AUDIT_BUFFER.pop(0)
    _INTENT_OUTCOME_AUDIT_BUFFER.append(entry)
    log_structured_event(
        event_type="AGENT_TOOL_OUTCOME",
        message=f"[OUTCOME] Completed tool '{tool_name}' ({status}) in {latency_ms:.2f}ms",
        severity="WARNING" if status != "SUCCESS" else "INFO",
        component="tool_dispatcher",
        metadata=entry,
    )
    return entry


def instrument_tool(func: F) -> F:
    """Decorator that wraps a tool with an OpenTelemetry span and pre/post Intent vs. Outcome logging.

    Args:
        func (F): Tool function to instrument.

    Returns:
        F: Wrapped function preserving original name, docstring, and type annotations for Google ADK.
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        tool_name = func.__name__
        bound_args = {"args": list(args), **kwargs} if args else dict(kwargs)
        with start_trace_span(f"tool.{tool_name}", attributes={"tool.name": tool_name}):
            log_tool_intent(tool_name=tool_name, arguments=bound_args)
            t0 = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                elapsed_ms = (time.perf_counter() - t0) * 1000.0
                log_tool_outcome(tool_name=tool_name, outcome=result, latency_ms=elapsed_ms)
                return result
            except Exception as exc:
                elapsed_ms = (time.perf_counter() - t0) * 1000.0
                log_tool_outcome(
                    tool_name=tool_name,
                    outcome=None,
                    latency_ms=elapsed_ms,
                    status="EXCEPTION",
                    error_message=str(exc),
                )
                raise

    return wrapper  # type: ignore[return-value]


def get_observability_snapshot() -> Dict[str, Any]:
    """Returns recent structured logs, intent-vs-outcome audit events, and OpenTelemetry spans.

    Returns:
        Dict[str, Any]: Snapshot of recorded logs, intent/outcome pairs, and trace spans.
    """
    return {
        "structured_logs_count": len(_STRUCTURED_LOG_BUFFER),
        "intent_outcome_events_count": len(_INTENT_OUTCOME_AUDIT_BUFFER),
        "recorded_spans_count": len(_RECORDED_SPANS_BUFFER),
        "recent_structured_logs": list(_STRUCTURED_LOG_BUFFER[-25:]),
        "recent_intent_outcome_events": list(_INTENT_OUTCOME_AUDIT_BUFFER[-25:]),
        "recent_spans": list(_RECORDED_SPANS_BUFFER[-25:]),
    }


def get_trace_history(limit: int = 25) -> List[Dict[str, Any]]:
    """Returns the most recent OpenTelemetry / distributed trace spans recorded by the agent.

    Args:
        limit (int): Maximum number of spans to return. Defaults to 25.

    Returns:
        List[Dict[str, Any]]: List of PII-scrubbed recorded trace span dictionaries.
    """
    return list(_RECORDED_SPANS_BUFFER[-max(1, int(limit)):])


def clear_observability_buffers() -> None:
    """Clears in-memory log, intent/outcome, and trace buffers (useful for deterministic test assertions).

    Returns:
        None
    """
    _STRUCTURED_LOG_BUFFER.clear()
    _INTENT_OUTCOME_AUDIT_BUFFER.clear()
    _RECORDED_SPANS_BUFFER.clear()
