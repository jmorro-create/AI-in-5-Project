"""
Context Bloat Management (Sliding-Window History Compaction), Persistent Session Service,
and Local Semantic Deal Memory Store.

Implements Category 2 of the AgentOps Code Review Matrix:
1. History Compaction (`compact_conversation_history`, ADK `EventsCompactionConfig`, and local
   context cache metadata digest via `create_or_get_gemini_context_cache`).
2. Persistent Session State (`PersistentFirestoreSessionService` + `SemanticDealMemoryStore`
   persisted in `data/vector_memory.json` and Cloud Firestore).
3. Memory Consolidation (`consolidate_session_memory_async` and `schedule_async_memory_consolidation`).
"""

from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import re
import threading
from typing import Any, Dict, List, Optional

try:
    from google.adk.apps.app import App, EventsCompactionConfig  # type: ignore[import-untyped]
    from google.adk.agents.context_cache_config import ContextCacheConfig  # type: ignore[import-untyped]
    from google.adk.sessions import InMemorySessionService  # type: ignore[import-untyped]

    HAS_ADK_CONTEXT_TOOLS = True
except ImportError:
    App = None  # type: ignore[assignment]
    EventsCompactionConfig = None  # type: ignore[assignment]
    ContextCacheConfig = None  # type: ignore[assignment]
    InMemorySessionService = None  # type: ignore[assignment]
    HAS_ADK_CONTEXT_TOOLS = False

from .firestore_sync import (
    DATA_DIR,
    fetch_doc_from_firestore,
    load_state,
    upsert_document,
)
from .observability import (
    instrument_tool,
    log_structured_event,
    redact_pii,
    start_trace_span,
)

VECTOR_STORE_FILE = str(Path(DATA_DIR) / "vector_memory.json")
_MEMORY_LOCK = threading.RLock()
_CONTEXT_CACHE_REGISTRY: Dict[str, Dict[str, Any]] = {}


def estimate_token_count(text: str) -> int:
    """Estimates the LLM token count for a string (~4 characters per token heuristic).

    Args:
        text (str): Input string to measure.

    Returns:
        int: Estimated token count.
    """
    if not text:
        return 0
    return max(1, math.ceil(len(text) / 4.0))


def build_adk_events_compaction_config(
    compaction_interval: int = 5,
    overlap_size: int = 2,
) -> Any:
    """Builds a Google ADK `EventsCompactionConfig` object for sliding-window event compaction.

    Args:
        compaction_interval (int): Number of invocations before triggering compaction. Defaults to 5.
        overlap_size (int): Number of recent invocations retained verbatim. Defaults to 2.

    Returns:
        Any: Configured `EventsCompactionConfig` instance or None if ADK class is unavailable.
    """
    if EventsCompactionConfig is not None:
        try:
            return EventsCompactionConfig(
                compaction_interval=compaction_interval,
                overlap_size=overlap_size,
            )
        except Exception:
            return None
    return None


def build_adk_context_cache_config(
    min_tokens: int = 1024,
    ttl_seconds: int = 1800,
    cache_intervals: int = 5,
) -> Any:
    """Builds a Google ADK `ContextCacheConfig` object for prompt caching configuration.

    Args:
        min_tokens (int): Minimum token count before activating context caching. Defaults to 1024.
        ttl_seconds (int): Cache time-to-live in seconds. Defaults to 1800.
        cache_intervals (int): Number of invocations before refreshing cache. Defaults to 5.

    Returns:
        Any: Configured `ContextCacheConfig` instance or None if ADK class is unavailable.
    """
    if ContextCacheConfig is not None:
        try:
            return ContextCacheConfig(
                min_tokens=min_tokens,
                ttl_seconds=ttl_seconds,
                cache_intervals=cache_intervals,
            )
        except Exception:
            return None
    return None


def create_or_get_gemini_context_cache(
    cache_key: str = "camp-2027-kia-telluride-hybrid-nj",
    system_instruction: str = "",
    static_context_text: str = "",
    benchmark_payload: Optional[Dict[str, Any]] = None,
    model: str = "gemini-2.5-flash",
    ttl_seconds: int = 1800,
) -> Dict[str, Any]:
    """Creates or retrieves a local Context Cache metadata digest for static campaign knowledge.

    Args:
        cache_key (str): Logical key identifying the cached campaign context.
        system_instruction (str): System constitution instructions to track.
        static_context_text (str): Static NJ tax, trim MSRP, and dealer benchmark context.
        benchmark_payload (Optional[Dict[str, Any]]): Optional benchmark dictionary to serialize into cached context.
        model (str): Target Gemini model for the context cache.
        ttl_seconds (int): Cache time-to-live in seconds.

    Returns:
        Dict[str, Any]: Metadata dictionary describing the context cache digest entry.
    """
    eff_static = static_context_text or (
        json.dumps(benchmark_payload, sort_keys=True) if benchmark_payload else ""
    )
    with _MEMORY_LOCK:
        existing = _CONTEXT_CACHE_REGISTRY.get(cache_key)
        if existing:
            return existing

        cache_record: Dict[str, Any] = {
            "cache_key": cache_key,
            "model": model,
            "estimated_tokens": estimate_token_count(system_instruction + eff_static),
            "ttl_seconds": ttl_seconds,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "provider": "local_memory_cache_digest",
            "cache_name": f"caches/{cache_key}",
        }
        _CONTEXT_CACHE_REGISTRY[cache_key] = cache_record
        return cache_record


def compact_conversation_history(
    turns: List[Dict[str, str]],
    max_recent_turns: int = 4,
    max_token_budget: int = 1600,
    existing_summary: str = "",
) -> Dict[str, Any]:
    """Compacts multi-turn conversation history via token-based truncation, sliding window, and summarization.

    Older turns outside the sliding window (`max_recent_turns`) or exceeding `max_token_budget`
    are consolidated into a structured `Compacted Session Context` digest preserving key quoted
    prices, VINs, and dealer concessions while preventing context window bloat.

    Args:
        turns (List[Dict[str, str]]): Chronological list of `{"user": ..., "agent": ...}` turns.
        max_recent_turns (int): Maximum number of verbatim recent turns to keep in the active window.
        max_token_budget (int): Maximum token budget allowed for the active conversation history block.
        existing_summary (str): Previously compacted summary digest to merge with newly evicted turns.

    Returns:
        Dict[str, Any]: Dictionary containing `compacted_summary`, `recent_turns`, `evicted_turns_count`,
            `compacted_turn_count`, `tokens_before`, `tokens_after`, and `formatted_context_block`.
    """
    with start_trace_span(
        "memory.compact_conversation_history",
        attributes={"turns_input_count": len(turns), "max_recent_turns": max_recent_turns},
    ):
        raw_text_all = "\n".join(
            f"User: {t.get('user', '')}\nAgent: {t.get('agent', '')}" for t in turns
        )
        tokens_before = estimate_token_count(raw_text_all)

        if len(turns) <= max_recent_turns and tokens_before <= max_token_budget:
            formatted = "\n".join(
                f"User: {t.get('user', '')}\nAgent: {t.get('agent', '')}" for t in turns
            )
            return {
                "compacted_summary": existing_summary,
                "recent_turns": list(turns),
                "evicted_turns_count": 0,
                "compacted_turn_count": 0,
                "tokens_before": tokens_before,
                "tokens_after": tokens_before,
                "formatted_context_block": formatted,
            }

        evicted = turns[:-max_recent_turns] if max_recent_turns > 0 else list(turns)
        recent = list(turns[-max_recent_turns:]) if max_recent_turns > 0 else []

        extracted_facts: List[str] = []
        price_re = re.compile(r"\$\d{1,3}(?:,\d{3})+(?:\.\d{2})?")
        vin_re = re.compile(r"\b5XY[A-HJ-NPR-Z0-9]{14}\b")

        for idx, turn in enumerate(evicted, start=1):
            combined = f"{turn.get('user', '')} {turn.get('agent', '')}"
            prices = price_re.findall(combined)
            vins = vin_re.findall(combined)
            snippet = redact_pii(turn.get("user", ""))[:100].strip()
            fact_parts = [f"Turn {idx}: {snippet}"]
            if prices:
                fact_parts.append(f"Prices={','.join(sorted(set(prices))[:3])}")
            if vins:
                fact_parts.append(f"VINs={','.join(sorted(set(vins))[:2])}")
            extracted_facts.append(" | ".join(fact_parts))

        summary_lines = ["=== Compacted Session Context (Prior Turns Digest) ==="]
        if existing_summary:
            summary_lines.append(existing_summary.strip())
        summary_lines.extend(f"- {fact}" for fact in extracted_facts[-10:])
        compacted_summary = "\n".join(summary_lines)

        recent_block = "\n".join(
            f"User: {redact_pii(t.get('user', ''))}\nAgent: {redact_pii(t.get('agent', ''))}"
            for t in recent
        )
        formatted_block = f"{compacted_summary}\n\n=== Recent Verbatim Turns ===\n{recent_block}".strip()
        tokens_after = estimate_token_count(formatted_block)

        return {
            "compacted_summary": compacted_summary,
            "recent_turns": recent,
            "evicted_turns_count": len(evicted),
            "compacted_turn_count": len(evicted),
            "tokens_before": tokens_before,
            "tokens_after": tokens_after,
            "formatted_context_block": formatted_block,
        }


class PersistentFirestoreSessionService:
    """Persistent conversational session service backed by local JSON state and Cloud Firestore."""

    def __init__(self, max_recent_turns: int = 6) -> None:
        self.max_recent_turns = max_recent_turns
        self._adk_in_memory = InMemorySessionService() if InMemorySessionService is not None else None

    def get_or_create_session(
        self,
        session_id: str,
        user_id: str = "buyer_nj_monmouth",
    ) -> Dict[str, Any]:
        """Loads an existing session from local state / Firestore or initializes a new session record.

        Args:
            session_id (str): Unique conversational session identifier.
            user_id (str): User identifier. Defaults to 'buyer_nj_monmouth'.

        Returns:
            Dict[str, Any]: Session dictionary containing `id`, `user_id`, `history`, and `compacted_summary`.
        """
        state = load_state()
        sessions = state.get("chat_sessions", {})
        if session_id in sessions:
            return sessions[session_id]

        remote_doc = fetch_doc_from_firestore("chat_sessions", session_id)
        if remote_doc and isinstance(remote_doc, dict):
            upsert_document("chat_sessions", session_id, remote_doc)
            return remote_doc

        new_sess: Dict[str, Any] = {
            "id": session_id,
            "user_id": user_id,
            "history": [],
            "compacted_summary": "",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        upsert_document("chat_sessions", session_id, new_sess)
        return new_sess

    def append_turn(
        self,
        session_id: str,
        user_message: str,
        agent_reply: str,
        user_id: str = "buyer_nj_monmouth",
    ) -> Dict[str, Any]:
        """Appends a PII-scrubbed conversational turn, compacts history if needed, and persists to Firestore.

        Args:
            session_id (str): Unique session identifier.
            user_message (str): User's message text.
            agent_reply (str): Agent's reply text.
            user_id (str): User identifier.

        Returns:
            Dict[str, Any]: Updated session record.
        """
        sess = self.get_or_create_session(session_id=session_id, user_id=user_id)
        clean_turn = {
            "user": str(redact_pii(user_message)),
            "agent": str(redact_pii(agent_reply)),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        history = list(sess.get("history", []))
        history.append(clean_turn)

        if len(history) > self.max_recent_turns:
            compacted = compact_conversation_history(
                turns=history,
                max_recent_turns=self.max_recent_turns,
                existing_summary=str(sess.get("compacted_summary", "")),
            )
            sess["compacted_summary"] = compacted["compacted_summary"]
            sess["history"] = compacted["recent_turns"]
        else:
            sess["history"] = history

        sess["updated_at"] = datetime.now(timezone.utc).isoformat()
        upsert_document("chat_sessions", session_id, sess)
        return sess


class SemanticDealMemoryStore:
    """Persistent semantic memory store (`data/vector_memory.json`) for NJ Telluride Hybrid deal facts."""

    def __init__(self, store_path: str = VECTOR_STORE_FILE) -> None:
        self.store_path = store_path
        self._ensure_seeded()

    def _tokenize(self, text: str) -> List[str]:
        return re.findall(r"[a-z0-9]{2,}", (text or "").lower())

    def _ensure_seeded(self) -> None:
        os.makedirs(os.path.dirname(self.store_path), exist_ok=True)
        if os.path.exists(self.store_path):
            return
        seed_entries = [
            {
                "id": "mem-nj-telluride-hybrid-invoice-holdback",
                "title": "2027 Kia Telluride Hybrid NJ Invoice & Holdback Benchmark",
                "content": (
                    "Monmouth & Ocean County NJ 2027 Kia Telluride Hybrid SX X-Line ($53,890 MSRP), "
                    "SX Prestige ($55,590 MSRP), and SX Prestige X-Line ($56,985 MSRP) carry ~4.0% dealer "
                    "invoice-to-MSRP spread plus 2% Kia holdback. Target pure dealer discount is 5.5% to 7.0% "
                    "off MSRP with $0 mandatory add-ons and 6.625% NJ sales tax."
                ),
                "tags": ["monmouth", "ocean", "telluride", "hybrid", "invoice", "holdback", "discount", "sx", "x-line"],
            },
            {
                "id": "mem-nj-five-dealer-doc-fees",
                "title": "Monmouth & Ocean County 5-Dealer Doc Fee Directory",
                "content": (
                    "Raceway Kia of Freehold ($799 doc fee), Sansone Jr's 66 Automall Kia ($895 doc fee), "
                    "Matt Blatt Kia of Toms River ($799 doc fee), DiFeo Kia of Lakewood ($749 doc fee), "
                    "and Manahawkin Kia ($699 doc fee). Always evaluate by True Deal Score = "
                    "(Selling Price - MSRP) + Doc Fee + Mandatory Add-ons."
                ),
                "tags": ["raceway", "sansone", "matt blatt", "difeo", "manahawkin", "doc fee", "true deal score"],
            },
            {
                "id": "mem-two-stage-squeeze-playbook",
                "title": "Two-Stage Negotiation Squeeze & Trade-In Secrecy Protocol",
                "content": (
                    "Stage 1 (Opening Anchor): Request itemized OTD breakdown at 6.5%-7.0% off MSRP with $0 add-ons. "
                    "Stage 2 (Sweet-Spot Counter): Concede $250-$400 to lock 5.5%-6.0% off MSRP today. "
                    "Never disclose trade-in vehicle or expiring lease until OTD is locked in writing."
                ),
                "tags": ["squeeze", "otd", "trade-in", "lease", "counter", "stage"],
            },
        ]
        self._save_entries(seed_entries)

    def _load_entries(self) -> List[Dict[str, Any]]:
        try:
            with open(self.store_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, list) else []
        except Exception:
            return []

    def _save_entries(self, entries: List[Dict[str, Any]]) -> None:
        os.makedirs(os.path.dirname(self.store_path), exist_ok=True)
        with open(self.store_path, "w", encoding="utf-8") as f:
            json.dump(entries, f, indent=2)

    def add_memory(self, memory_id: str, title: str, content: str, tags: Optional[List[str]] = None) -> Dict[str, Any]:
        """Adds or updates a semantic memory entry in the persistent JSON store."""
        with _MEMORY_LOCK:
            entries = [e for e in self._load_entries() if e.get("id") != memory_id]
            record = {
                "id": memory_id,
                "title": str(redact_pii(title)),
                "content": str(redact_pii(content)),
                "tags": list(tags or []),
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            entries.append(record)
            self._save_entries(entries)
            return record

    def search(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """Ranks stored negotiation memories against `query` using token overlap & cosine similarity."""
        q_tokens = set(self._tokenize(query))
        entries = self._load_entries()
        scored: List[Dict[str, Any]] = []
        for item in entries:
            doc_text = f"{item.get('title', '')} {item.get('content', '')} {' '.join(item.get('tags', []))}"
            d_tokens = set(self._tokenize(doc_text))
            if not d_tokens:
                continue
            overlap = len(q_tokens & d_tokens)
            denom = math.sqrt(max(1, len(q_tokens)) * len(d_tokens))
            score = round(overlap / denom, 4) if q_tokens else 0.1
            scored.append({**item, "similarity_score": score})
        scored.sort(key=lambda x: x.get("similarity_score", 0.0), reverse=True)
        return scored[: max(1, int(top_k))]


_SEMANTIC_STORE_SINGLETON: Optional[SemanticDealMemoryStore] = None


def get_semantic_memory_store() -> SemanticDealMemoryStore:
    """Returns the singleton `SemanticDealMemoryStore` instance."""
    global _SEMANTIC_STORE_SINGLETON
    if _SEMANTIC_STORE_SINGLETON is None:
        _SEMANTIC_STORE_SINGLETON = SemanticDealMemoryStore()
    return _SEMANTIC_STORE_SINGLETON


@instrument_tool
def search_negotiation_memory(
    query: str,
    top_k: int = 3,
) -> Dict[str, Any]:
    """Searches persistent semantic negotiation memory for historical dealer quotes, NJ fee benchmarks, and playbook rules.

    Args:
        query (str): Natural-language search query (e.g., 'Monmouth County Telluride Hybrid invoice holdback').
        top_k (int): Maximum number of matching memory records to return. Defaults to 3.

    Returns:
        Dict[str, Any]: Dictionary containing `ok`, `query`, `results_count`, and `matches`.
    """
    store = get_semantic_memory_store()
    matches = store.search(query=query, top_k=top_k)
    return {
        "ok": True,
        "query": query,
        "results_count": len(matches),
        "matches": matches,
    }


def consolidate_session_memory_async(
    session_id: str,
    turns: List[Dict[str, str]],
    dealer_id: str = "",
) -> Dict[str, Any]:
    """Consolidates recent conversational turns into a persistent session memory digest.

    Args:
        session_id (str): Active session identifier.
        turns (List[Dict[str, str]]): Conversation turns to summarize.
        dealer_id (str): Optional dealer identifier associated with the conversation.

    Returns:
        Dict[str, Any]: Persisted memory digest record.
    """
    compacted = compact_conversation_history(turns=turns, max_recent_turns=4)
    digest_doc = {
        "id": f"digest-{session_id}",
        "session_id": session_id,
        "dealer_id": dealer_id,
        "compacted_summary": compacted["compacted_summary"],
        "tokens_after": compacted["tokens_after"],
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    upsert_document("memory_digests", digest_doc["id"], digest_doc, async_remote_sync=False)
    return digest_doc


def schedule_async_memory_consolidation(
    session_id: str,
    turns: List[Dict[str, str]],
    dealer_id: str = "",
) -> Dict[str, Any]:
    """Updates the persistent session memory digest for the given session.

    Args:
        session_id (str): Active session identifier.
        turns (List[Dict[str, str]]): Conversation turns to consolidate.
        dealer_id (str): Optional dealer ID.

    Returns:
        Dict[str, Any]: Consolidated memory digest record.
    """
    return consolidate_session_memory_async(
        session_id=session_id,
        turns=turns,
        dealer_id=dealer_id,
    )