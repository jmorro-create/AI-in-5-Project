"""
Phase 2 Live Personal Gmail & Personal Mobile SMS Negotiation Connector.

Provides:
1. Dual Personal Gmail Integration:
   - 60-Second Google App Password (`GMAIL_USER_EMAIL` + `GMAIL_APP_PASSWORD`) via SMTP SSL (`smtp.gmail.com:465`)
     and IMAP SSL (`imap.gmail.com:993`).
   - Gmail OAuth2 REST API (`GMAIL_OAUTH_CLIENT_ID`, `GMAIL_OAUTH_CLIENT_SECRET`, `GMAIL_OAUTH_REFRESH_TOKEN`).
   - Strict RFC 5322 Thread Continuity (`Message-ID`, `In-Reply-To`, `References`, `threadId`, and `Re:` subject lines)
     so all back-and-forth emails with each dealership stay in a single continuous Gmail thread.
2. Dual-Mode Personal Mobile SMS Integration:
   - 1-Tap Native Mobile Deep Links (`sms:+1732...?body=...` and `mailto:sales@...?subject=...&body=...`).
   - Automated Personal Mobile SMS Gateway Webhook (`PERSONAL_SMS_GATEWAY_URL` supporting Android SMS Gateway
     `capcom6/android-sms-gateway` and generic iOS Shortcuts / Tasker payloads).
   - Inbound SMS & Email Webhook Ingestion (`ingest_live_dealer_message`) that parses real dealer quotes,
     audits OTD / Doc Fee / Add-Ons / Money Factor, updates the leaderboard, and queues a Copilot counter-offer.
3. Simulation vs. Live Transport Mode Switch (`SIMULATION` vs. `LIVE`) & Real-Contact Safety Guardrails.
"""

import base64
import email
from email.header import decode_header
from email.message import EmailMessage
from email.utils import parseaddr
import html
import imaplib
import json
import os
import re
import smtplib
import ssl
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .firestore_sync import load_state, upsert_document
from .observability import instrument_tool, log_structured_event, redact_pii, start_trace_span
from .schemas import (
    InboundDealerWebhookSchema,
    UpdateDealerContactInputSchema,
    build_guided_error,
    validate_tool_input,
)
from .secret_manager import get_secret


def _normalize_phone_digits(phone: str) -> str:
    """Extracts digits from a phone string for reliable matching across formats."""
    digits = re.sub(r"\D+", "", str(phone or ""))
    if len(digits) == 11 and digits.startswith("1"):
        return digits[1:]
    return digits


def build_personal_email_deep_link(to_email: str, subject: str, body: str) -> str:
    """Generates a `mailto:` deep link so a user on Mobile Chrome or Desktop can open their native Gmail/Mail app with 1 tap.

    Args:
        to_email (str): Target salesperson email address.
        subject (str): Email subject line (preserving `Re:` thread subject).
        body (str): Pre-filled counter-offer body text.

    Returns:
        str: RFC 6068 `mailto:` URI with URL-encoded `subject` and `body`.
    """
    clean_to = (to_email or "").strip()
    subj_enc = urllib.parse.quote(subject or "", safe="")
    body_enc = urllib.parse.quote(body or "", safe="")
    return f"mailto:{clean_to}?subject={subj_enc}&body={body_enc}"


def is_placeholder_contact(contact: str, channel: str = "SMS_PERSONAL") -> bool:
    """Checks whether a phone number or email address is a seeded demo placeholder (`555` phone or `.example.com` email).

    Args:
        contact (str): Phone number or email address to inspect.
        channel (str): Communication channel ('EMAIL', 'SMS_PERSONAL', or 'SMS_TWILIO').

    Returns:
        bool: True if the contact is a synthetic demo placeholder that must not be dispatched in LIVE mode.
    """
    raw = (contact or "").strip().lower()
    if not raw:
        return True
    if channel.upper() == "EMAIL" or "@" in raw:
        return (
            raw.endswith(".example.com")
            or raw.endswith("@example.com")
            or raw.endswith(".test")
            or raw.endswith(".invalid")
            or "dealer.example.com" in raw
        )
    digits = _normalize_phone_digits(raw)
    if len(digits) < 10:
        return True
    # North American 555-01XX fictional/demo exchange or 555 prefix
    if digits[:3] == "555" or digits[3:6] == "555":
        return True
    return False


def get_transport_mode() -> str:
    """Returns the active negotiation transport mode ('SIMULATION' or 'LIVE').

    Checks the active campaign document in `state.json` first, falling back to the
    `NEGOTIATION_TRANSPORT_MODE` environment variable (defaulting to `'SIMULATION'`).

    Returns:
        str: `'LIVE'` or `'SIMULATION'`.
    """
    state = load_state()
    camp_id = state.get("active_campaign_id")
    if camp_id and camp_id in state.get("campaigns", {}):
        camp_mode = str(state["campaigns"][camp_id].get("transport_mode", "")).strip().upper()
        if camp_mode in ("LIVE", "SIMULATION"):
            return camp_mode
    env_mode = os.environ.get("NEGOTIATION_TRANSPORT_MODE", "SIMULATION").strip().upper()
    return "LIVE" if env_mode == "LIVE" else "SIMULATION"


@instrument_tool
def set_transport_mode(mode: str = "SIMULATION") -> Dict[str, Any]:
    """Switches the campaign transport mode between `SIMULATION` (practice/mock dealer replies) and `LIVE` (real Gmail & Personal Mobile SMS).

    Args:
        mode (str): Target transport mode: `'SIMULATION'` or `'LIVE'`.

    Returns:
        Dict[str, Any]: Updated transport mode status and live credential readiness summary.
    """
    mode_norm = (mode or "").strip().upper()
    if mode_norm not in ("SIMULATION", "LIVE"):
        return build_guided_error(
            error_code="INVALID_TRANSPORT_MODE",
            message=f"Unsupported transport mode '{mode}'. Must be 'SIMULATION' or 'LIVE'.",
            recovery_instructions="Call `set_transport_mode(mode='LIVE')` for real Gmail/SMS negotiations or `set_transport_mode(mode='SIMULATION')` for simulated dealer replies.",
            invalid_fields={"mode": mode},
        )

    os.environ["NEGOTIATION_TRANSPORT_MODE"] = mode_norm
    state = load_state()
    camp_id = state.get("active_campaign_id") or "camp-default"
    campaign = state.get("campaigns", {}).get(camp_id, {"id": camp_id})
    campaign["transport_mode"] = mode_norm
    upsert_document("negotiation_campaigns", camp_id, campaign)

    status = get_live_comms_configuration_status()
    return {
        "ok": True,
        "transport_mode": mode_norm,
        "simulated_replies_enabled": mode_norm == "SIMULATION",
        "comms_status": status,
    }


@instrument_tool
def get_live_comms_configuration_status() -> Dict[str, Any]:
    """Inspects live Personal Gmail and Personal Mobile SMS configuration and returns connection readiness.

    Args:
        None

    Returns:
        Dict[str, Any]: Dictionary detailing `transport_mode`, `gmail_ready`, `gmail_auth_method`,
            `gmail_user_email`, `personal_sms_gateway_ready`, `native_deep_links_ready`, and setup hints.
    """
    gmail_user = get_secret("GMAIL_USER_EMAIL", "").strip()
    gmail_app_pw = get_secret("GMAIL_APP_PASSWORD", "").strip()
    gmail_oauth_token = get_secret("GMAIL_OAUTH_REFRESH_TOKEN", "").strip()
    gmail_client_id = get_secret("GMAIL_OAUTH_CLIENT_ID", "").strip()
    gmail_client_secret = get_secret("GMAIL_OAUTH_CLIENT_SECRET", "").strip()

    oauth_ready = bool(gmail_oauth_token and gmail_client_id and gmail_client_secret)
    app_pw_ready = bool(gmail_user and gmail_app_pw)
    gmail_ready = bool(app_pw_ready or oauth_ready)

    if app_pw_ready and oauth_ready:
        gmail_auth_method = "DUAL_APP_PASSWORD_AND_OAUTH2"
    elif app_pw_ready:
        gmail_auth_method = "GMAIL_APP_PASSWORD_SMTP_IMAP"
    elif oauth_ready:
        gmail_auth_method = "GMAIL_OAUTH2_REST_API"
    else:
        gmail_auth_method = "MAILTO_DEEP_LINK_ONLY"

    sms_gw_url = get_secret("PERSONAL_SMS_GATEWAY_URL", "").strip()
    buyer_phone = get_secret("BUYER_PERSONAL_PHONE", "").strip()
    twilio_ready = bool(
        get_secret("TWILIO_ACCOUNT_SID", "").strip()
        and get_secret("TWILIO_AUTH_TOKEN", "").strip()
        and get_secret("TWILIO_FROM_NUMBER", "").strip()
    )

    mode = get_transport_mode()
    return {
        "ok": True,
        "transport_mode": mode,
        "simulated_replies_enabled": mode == "SIMULATION",
        "gmail_ready": gmail_ready,
        "gmail_auth_method": gmail_auth_method,
        "gmail_user_email": gmail_user or "(not set — using 1-tap mailto: deep links)",
        "personal_sms_gateway_ready": bool(sms_gw_url),
        "personal_sms_gateway_url_configured": bool(sms_gw_url),
        "buyer_personal_phone": buyer_phone or "(using phone native SMS app)",
        "twilio_ready": twilio_ready,
        "native_deep_links_ready": True,
        "thread_continuity_enabled": True,
    }


def configure_personal_comms_credentials(
    gmail_user_email: str = "",
    gmail_app_password: str = "",
    personal_sms_gateway_url: str = "",
    personal_sms_gateway_token: str = "",
    buyer_personal_phone: str = "",
    transport_mode: str = "",
) -> Dict[str, Any]:
    """Updates runtime Personal Gmail App Password and Personal Mobile SMS Gateway settings from the UI modal.

    Credentials are stored in process memory (`os.environ`) for immediate use without writing plaintext secrets to git.

    Args:
        gmail_user_email (str): Buyer's personal Gmail address (e.g., 'alex@gmail.com').
        gmail_app_password (str): 16-character Google Account App Password.
        personal_sms_gateway_url (str): Optional Android SMS Gateway or iOS Shortcut webhook URL.
        personal_sms_gateway_token (str): Optional Bearer token for the personal SMS gateway.
        buyer_personal_phone (str): Buyer's personal mobile number in E.164 format.
        transport_mode (str): Optional transport mode override ('SIMULATION' or 'LIVE').

    Returns:
        Dict[str, Any]: Updated live communications status dictionary.
    """
    if gmail_user_email.strip():
        os.environ["GMAIL_USER_EMAIL"] = gmail_user_email.strip()
    if gmail_app_password.strip():
        # Google displays 16-char app passwords with spaces (e.g. 'abcd efgh ijkl mnop'); strip internal spaces
        os.environ["GMAIL_APP_PASSWORD"] = gmail_app_password.replace(" ", "").strip()
    if personal_sms_gateway_url.strip():
        os.environ["PERSONAL_SMS_GATEWAY_URL"] = personal_sms_gateway_url.strip()
    if personal_sms_gateway_token.strip():
        os.environ["PERSONAL_SMS_GATEWAY_TOKEN"] = personal_sms_gateway_token.strip()
    if buyer_personal_phone.strip():
        os.environ["BUYER_PERSONAL_PHONE"] = buyer_personal_phone.strip()
    if transport_mode.strip().upper() in ("SIMULATION", "LIVE"):
        set_transport_mode(transport_mode.strip().upper())

    log_structured_event(
        event_type="PERSONAL_COMMS_CONFIGURED",
        message="Updated runtime personal Gmail / Mobile SMS configuration",
        component="live_comms_connector",
        metadata={
            "gmail_configured": bool(os.environ.get("GMAIL_USER_EMAIL") and os.environ.get("GMAIL_APP_PASSWORD")),
            "sms_gateway_configured": bool(os.environ.get("PERSONAL_SMS_GATEWAY_URL")),
            "transport_mode": get_transport_mode(),
        },
    )
    return get_live_comms_configuration_status()


@instrument_tool
def update_dealer_contact_info(
    dealer_id: str,
    contact_name: str = "",
    contact_phone: str = "",
    contact_email: str = "",
    preferred_channel: str = "",
) -> Dict[str, Any]:
    """Updates a dealership lead with the real salesperson's name, mobile phone number, and email address.

    Also refreshes `to_contact`, `sms_deep_link`, and `email_deep_link` on any `PENDING_APPROVAL`
    draft messages for that dealership so 1-tap sending and Live Gmail/SMS dispatch immediately target
    the updated salesperson contact.

    Args:
        dealer_id (str): Dealership lead ID (e.g. 'dlr-raceway-kia-of-freehold').
        contact_name (str): Real salesperson or Internet Manager name (e.g. 'Mike Russo').
        contact_phone (str): Real salesperson mobile/SMS phone number (e.g. '+17324624422').
        contact_email (str): Real salesperson email address (e.g. 'mrusso@racewaykia.com').
        preferred_channel (str): Optional preferred channel ('SMS_PERSONAL', 'EMAIL', or 'SMS_TWILIO').

    Returns:
        Dict[str, Any]: Updated dealer lead record and count of refreshed pending drafts.
    """
    validated, err = validate_tool_input(
        UpdateDealerContactInputSchema,
        {
            "dealer_id": dealer_id,
            "contact_name": contact_name,
            "contact_phone": contact_phone,
            "contact_email": contact_email,
            "preferred_channel": preferred_channel,
        },
        tool_name="update_dealer_contact_info",
        recovery_hint="Pass a valid `dealer_id` (e.g. 'dlr-raceway-kia-of-freehold') and at least one contact field (`contact_name`, `contact_phone`, or `contact_email`).",
    )
    if err:
        return err
    assert validated is not None

    state = load_state()
    leads = state.get("dealer_leads", {})
    lead = leads.get(validated.dealer_id)
    if not lead:
        return build_guided_error(
            error_code="DEALER_NOT_FOUND",
            message=f"Dealer '{validated.dealer_id}' not found in active campaign.",
            recovery_instructions=f"Call `get_negotiation_dashboard()` to view valid dealer IDs: {list(leads.keys())}.",
            invalid_fields={"dealer_id": validated.dealer_id},
        )

    if validated.contact_name.strip():
        lead["contact_name"] = validated.contact_name.strip()
    if validated.contact_phone.strip():
        lead["contact_phone"] = validated.contact_phone.strip()
    if validated.contact_email.strip():
        lead["contact_email"] = validated.contact_email.strip()
    if validated.preferred_channel.strip().upper() in ("SMS_PERSONAL", "EMAIL", "SMS_TWILIO"):
        lead["preferred_channel"] = validated.preferred_channel.strip().upper()

    lead["has_real_contact"] = not (
        is_placeholder_contact(lead.get("contact_phone", ""), "SMS_PERSONAL")
        and is_placeholder_contact(lead.get("contact_email", ""), "EMAIL")
    )
    saved_lead = upsert_document("dealer_leads", validated.dealer_id, lead)

    # Refresh any PENDING_APPROVAL drafts for this dealer
    refreshed_drafts = 0
    queue = load_state().get("message_queue", {})
    for m_id, msg in queue.items():
        if msg.get("dealer_id") == validated.dealer_id and msg.get("status") == "PENDING_APPROVAL":
            chan = str(msg.get("channel", "SMS_PERSONAL")).upper()
            phone = saved_lead.get("contact_phone", "+15550101001")
            email_addr = saved_lead.get("contact_email", "sales@dealer.example.com")
            body = msg.get("body", "")
            subj = msg.get("subject", "")
            msg["to_contact"] = email_addr if chan == "EMAIL" else phone
            msg["sms_deep_link"] = f"sms:{phone.strip()}?body={urllib.parse.quote(body, safe='')}"
            msg["email_deep_link"] = build_personal_email_deep_link(email_addr, subj, body)
            upsert_document("message_queue", m_id, msg)
            refreshed_drafts += 1

    return {
        "ok": True,
        "dealer_id": validated.dealer_id,
        "dealer_lead": saved_lead,
        "refreshed_pending_drafts": refreshed_drafts,
    }


def _exchange_gmail_refresh_token() -> Optional[str]:
    """Exchanges `GMAIL_OAUTH_REFRESH_TOKEN` for a short-lived Google OAuth2 access token."""
    client_id = get_secret("GMAIL_OAUTH_CLIENT_ID", "").strip()
    client_secret = get_secret("GMAIL_OAUTH_CLIENT_SECRET", "").strip()
    refresh_token = get_secret("GMAIL_OAUTH_REFRESH_TOKEN", "").strip()
    if not (client_id and client_secret and refresh_token):
        return None
    payload = urllib.parse.urlencode(
        {
            "client_id": client_id,
            "client_secret": client_secret,
            "refresh_token": refresh_token,
            "grant_type": "refresh_token",
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        "https://oauth2.googleapis.com/token",
        data=payload,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("access_token")
    except Exception as exc:
        log_structured_event(
            event_type="GMAIL_OAUTH_TOKEN_EXCHANGE_FAILED",
            message=f"Gmail OAuth2 refresh failed: {exc}",
            severity="WARNING",
            component="live_comms_connector",
        )
        return None


def ensure_reply_subject(subject: str, existing_thread_subject: str = "") -> str:
    """Ensures follow-up emails in an existing dealer thread keep an exact `Re: <subject>` line so Gmail threads them."""
    base = (existing_thread_subject or subject or "").strip()
    if not base:
        return "2027 Kia Telluride Hybrid Quote & OTD Inquiry"
    if existing_thread_subject and not base.lower().startswith("re:"):
        return f"Re: {base}"
    return base


@instrument_tool
def send_via_personal_gmail(
    to_email: str,
    subject: str,
    body: str,
    thread_id: str = "",
    in_reply_to: str = "",
    references: str = "",
) -> Dict[str, Any]:
    """Dispatches an outbound negotiation email from the buyer's personal Gmail account with single-thread continuity.

    Supports two authentication methods:
    1. Google Account App Password (`GMAIL_USER_EMAIL` + `GMAIL_APP_PASSWORD`) via `smtp.gmail.com:465` (SSL).
    2. Gmail OAuth2 REST API (`GMAIL_OAUTH_REFRESH_TOKEN`) via `https://gmail.googleapis.com/gmail/v1/users/me/messages/send`.

    Automatically sets RFC 5322 `Message-ID`, `In-Reply-To`, and `References` headers so every email
    to and from the dealership stays inside a single continuous Gmail conversation thread.

    Args:
        to_email (str): Target dealership salesperson email address.
        subject (str): Email subject line (automatically prefixed with `Re:` when continuing a thread).
        body (str): Plain-text negotiation email body.
        thread_id (str): Optional Gmail `threadId` from prior messages in the conversation.
        in_reply_to (str): Optional RFC 5322 `Message-ID` of the last email in the thread.
        references (str): Optional space-separated chain of RFC 5322 `Message-ID`s in the thread.

    Returns:
        Dict[str, Any]: Transport metadata containing `live_dispatched`, `provider`, `message_id`,
            `thread_id`, `in_reply_to`, `references`, `subject`, and `email_deep_link`.
    """
    gmail_user = get_secret("GMAIL_USER_EMAIL", "").strip()
    gmail_app_pw = get_secret("GMAIL_APP_PASSWORD", "").replace(" ", "").strip()
    generated_msg_id = f"<car-neg-{uuid.uuid4().hex}@gmail.com>"

    eff_subject = ensure_reply_subject(subject, subject if in_reply_to else "")
    eff_references = references.strip()
    if in_reply_to.strip() and in_reply_to.strip() not in eff_references:
        eff_references = f"{eff_references} {in_reply_to.strip()}".strip()

    msg = EmailMessage()
    msg["To"] = to_email.strip()
    msg["From"] = gmail_user or "buyer@gmail.com"
    msg["Subject"] = eff_subject
    msg["Message-ID"] = generated_msg_id
    if in_reply_to.strip():
        msg["In-Reply-To"] = in_reply_to.strip()
    if eff_references:
        msg["References"] = eff_references
    msg.set_content(body)

    email_deep_link = build_personal_email_deep_link(to_email, eff_subject, body)

    # Path 1: Gmail App Password via SMTP SSL (smtp.gmail.com:465)
    if gmail_user and gmail_app_pw:
        with start_trace_span("gmail.smtp_send", {"to": redact_pii(to_email), "threaded": bool(in_reply_to)}):
            try:
                context = ssl.create_default_context()
                with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context, timeout=10) as smtp:
                    smtp.login(gmail_user, gmail_app_pw)
                    smtp.send_message(msg)
                eff_thread_id = thread_id or generated_msg_id.strip("<>")
                return {
                    "live_dispatched": True,
                    "provider": "personal_gmail_app_password_smtp",
                    "from": gmail_user,
                    "to": to_email,
                    "subject": eff_subject,
                    "message_id": generated_msg_id,
                    "thread_id": eff_thread_id,
                    "in_reply_to": in_reply_to,
                    "references": f"{eff_references} {generated_msg_id}".strip(),
                    "email_deep_link": email_deep_link,
                }
            except Exception as exc:
                return {
                    "live_dispatched": False,
                    "provider": "personal_gmail_app_password_smtp_error",
                    "error": str(exc),
                    "message_id": generated_msg_id,
                    "thread_id": thread_id or generated_msg_id.strip("<>"),
                    "in_reply_to": in_reply_to,
                    "references": f"{eff_references} {generated_msg_id}".strip(),
                    "subject": eff_subject,
                    "email_deep_link": email_deep_link,
                }

    # Path 2: Gmail OAuth2 REST API
    access_token = _exchange_gmail_refresh_token()
    if access_token:
        with start_trace_span("gmail.oauth_rest_send", {"to": redact_pii(to_email), "threaded": bool(thread_id)}):
            try:
                raw_b64 = base64.urlsafe_b64encode(msg.as_bytes()).decode("ascii")
                payload_dict: Dict[str, Any] = {"raw": raw_b64}
                if thread_id:
                    payload_dict["threadId"] = thread_id
                req = urllib.request.Request(
                    "https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
                    data=json.dumps(payload_dict).encode("utf-8"),
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "Content-Type": "application/json",
                    },
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=10) as resp:
                    resp_data = json.loads(resp.read().decode("utf-8"))
                return {
                    "live_dispatched": True,
                    "provider": "personal_gmail_oauth2_rest_api",
                    "from": gmail_user or "me",
                    "to": to_email,
                    "subject": eff_subject,
                    "message_id": generated_msg_id,
                    "gmail_api_id": resp_data.get("id", ""),
                    "thread_id": resp_data.get("threadId", thread_id or generated_msg_id.strip("<>")),
                    "in_reply_to": in_reply_to,
                    "references": f"{eff_references} {generated_msg_id}".strip(),
                    "email_deep_link": email_deep_link,
                }
            except Exception as exc:
                return {
                    "live_dispatched": False,
                    "provider": "personal_gmail_oauth2_error",
                    "error": str(exc),
                    "message_id": generated_msg_id,
                    "thread_id": thread_id or generated_msg_id.strip("<>"),
                    "in_reply_to": in_reply_to,
                    "references": f"{eff_references} {generated_msg_id}".strip(),
                    "subject": eff_subject,
                    "email_deep_link": email_deep_link,
                }

    # Path 3: 1-Tap mailto: deep link fallback (when no App Password / OAuth token is configured yet)
    return {
        "live_dispatched": False,
        "provider": "personal_email_deep_link_ready",
        "to": to_email,
        "subject": eff_subject,
        "message_id": generated_msg_id,
        "thread_id": thread_id or generated_msg_id.strip("<>"),
        "in_reply_to": in_reply_to,
        "references": f"{eff_references} {generated_msg_id}".strip(),
        "email_deep_link": email_deep_link,
        "note": "Set GMAIL_USER_EMAIL + GMAIL_APP_PASSWORD in Campaign Settings for 1-click background Gmail send, or tap 'Open in Gmail/Mail' to send from your phone.",
    }


def _match_dealer_lead_by_contact_or_text(
    dealer_id: str = "",
    sender_contact: str = "",
    subject: str = "",
    raw_body: str = "",
) -> Optional[Dict[str, Any]]:
    """Resolves an inbound SMS or email to the matching dealership lead in `state.json`."""
    state = load_state()
    leads: Dict[str, Dict[str, Any]] = state.get("dealer_leads", {})
    if dealer_id and dealer_id in leads:
        return leads[dealer_id]

    sender_clean = (sender_contact or "").strip().lower()
    sender_digits = _normalize_phone_digits(sender_clean)
    _, parsed_email = parseaddr(sender_clean)
    parsed_email = parsed_email.lower().strip()

    # 1. Exact phone or email match
    for lead in leads.values():
        lead_phone_digits = _normalize_phone_digits(lead.get("contact_phone", ""))
        lead_email = str(lead.get("contact_email", "")).strip().lower()
        if sender_digits and len(sender_digits) >= 10 and sender_digits == lead_phone_digits:
            return lead
        if parsed_email and "@" in parsed_email and parsed_email == lead_email:
            return lead

    # 2. Match by VIN (5XYP...) in subject or body
    combined = f"{subject} {raw_body}".upper()
    for lead in leads.values():
        vin = str(lead.get("vin", "")).strip().upper()
        if vin and len(vin) >= 10 and vin in combined:
            return lead

    # 3. Match by dealership name keywords in sender email domain, subject, or body
    combined_low = f"{sender_clean} {subject} {raw_body}".lower()
    for lead in leads.values():
        d_name = str(lead.get("dealer_name", "")).lower()
        for token in ("raceway", "sansone", "matt blatt", "difeo", "manahawkin"):
            if token in d_name and token in combined_low:
                return lead

    # Default to top lead if available
    return next(iter(leads.values()), None)


@instrument_tool
def ingest_live_dealer_message(
    dealer_id: str = "",
    sender_contact: str = "",
    channel: str = "SMS_PERSONAL",
    raw_body: str = "",
    subject: str = "",
    external_message_id: str = "",
    thread_id: str = "",
    in_reply_to: str = "",
    references: str = "",
    auto_draft_counter: bool = True,
) -> Dict[str, Any]:
    """Ingests a real inbound SMS or Gmail reply from a car dealer, extracts pricing, updates the leaderboard, and drafts a Copilot counter-offer.

    Preserves RFC 5322 email threading metadata (`external_message_id`, `thread_id`, `references`, `subject`)
    on the dealer lead so the buyer's next counter-offer is threaded into the exact same email chain.

    Args:
        dealer_id (str): Optional dealer ID (if omitted, automatically matched by phone, email, VIN, or dealer name).
        sender_contact (str): Dealer salesperson's phone number or email address.
        channel (str): Inbound channel ('SMS_PERSONAL', 'EMAIL', or 'SMS_TWILIO').
        raw_body (str): Full text of the dealer's SMS or email reply.
        subject (str): Email subject line (for `EMAIL` channel thread continuity).
        external_message_id (str): RFC 5322 `Message-ID` or SMS gateway message ID.
        thread_id (str): Gmail `threadId` or SMS conversation ID.
        in_reply_to (str): RFC 5322 `In-Reply-To` header from the dealer's email.
        references (str): RFC 5322 `References` header chain from the dealer's email.
        auto_draft_counter (bool): If True (default), automatically generates and queues a 2-sentence Copilot counter-offer in `PENDING_APPROVAL`.

    Returns:
        Dict[str, Any]: Ingestion report containing `ok`, `dealer_id`, `dealer_name`, `parsed_quote`,
            `inbound_message`, `auto_drafted_counter`, and `thread_continuity`.
    """
    validated, err = validate_tool_input(
        InboundDealerWebhookSchema,
        {
            "dealer_id": dealer_id,
            "sender_contact": sender_contact,
            "channel": channel,
            "raw_body": raw_body,
            "subject": subject,
            "external_message_id": external_message_id,
            "thread_id": thread_id,
            "in_reply_to": in_reply_to,
            "references": references,
            "auto_draft_counter": auto_draft_counter,
        },
        tool_name="ingest_live_dealer_message",
        recovery_hint="Provide `raw_body` containing the dealer's message text and either `dealer_id` or `sender_contact`.",
    )
    if err:
        return err
    assert validated is not None

    from .comms_tools import generate_natural_buyer_counter, queue_dealer_message
    from .deal_tracker import get_best_competing_offer, parse_and_log_dealer_reply

    matched_lead = _match_dealer_lead_by_contact_or_text(
        dealer_id=validated.dealer_id,
        sender_contact=validated.sender_contact,
        subject=validated.subject,
        raw_body=validated.raw_body,
    )
    if not matched_lead:
        return build_guided_error(
            error_code="UNMATCHED_INBOUND_DEALER",
            message=f"Could not match inbound message from '{validated.sender_contact}' to any active dealer lead.",
            recovery_instructions="Pass an explicit `dealer_id` (e.g. 'dlr-raceway-kia-of-freehold') or update the dealer's contact info via `update_dealer_contact_info`.",
            invalid_fields={"sender_contact": validated.sender_contact, "dealer_id": validated.dealer_id},
        )

    eff_dealer_id = str(matched_lead["id"])
    chan_norm = validated.channel.strip().upper()
    if chan_norm not in ("EMAIL", "SMS_PERSONAL", "SMS_TWILIO"):
        chan_norm = "EMAIL" if "@" in validated.sender_contact else "SMS_PERSONAL"

    # Update real contact info & RFC 5322 thread continuity state on the dealer lead
    if validated.sender_contact.strip():
        if "@" in validated.sender_contact:
            _, addr = parseaddr(validated.sender_contact)
            if addr and not is_placeholder_contact(addr, "EMAIL"):
                matched_lead["contact_email"] = addr
        else:
            if not is_placeholder_contact(validated.sender_contact, "SMS_PERSONAL"):
                matched_lead["contact_phone"] = validated.sender_contact.strip()

    eff_msg_id = validated.external_message_id.strip() or f"<dealer-in-{uuid.uuid4().hex[:10]}@dealer>"
    eff_thread_id = (
        validated.thread_id.strip()
        or str(matched_lead.get("email_thread_id", "")).strip()
        or eff_msg_id.strip("<>")
    )
    prev_refs = str(matched_lead.get("email_references", "")).strip()
    incoming_refs = validated.references.strip() or prev_refs
    if eff_msg_id not in incoming_refs:
        incoming_refs = f"{incoming_refs} {eff_msg_id}".strip()

    if chan_norm == "EMAIL":
        matched_lead["email_thread_id"] = eff_thread_id
        matched_lead["last_email_message_id"] = eff_msg_id
        matched_lead["email_references"] = incoming_refs
        if validated.subject.strip():
            matched_lead["email_thread_subject"] = ensure_reply_subject(
                validated.subject.strip(),
                str(matched_lead.get("email_thread_subject", "")),
            )
    upsert_document("dealer_leads", eff_dealer_id, matched_lead)

    # Parse financial figures & log the inbound message via deal_tracker
    inbound_msg_doc = {
        "id": f"msg-in-{uuid.uuid4().hex[:10]}",
        "campaign_id": matched_lead.get("campaign_id", "camp-2027-kia-telluride-hybrid-nj"),
        "dealer_id": eff_dealer_id,
        "dealer_name": matched_lead.get("dealer_name", eff_dealer_id),
        "from_contact": validated.sender_contact,
        "direction": "INBOUND",
        "channel": chan_norm,
        "status": "RECEIVED",
        "round": int(matched_lead.get("round", 1)),
        "subject": validated.subject or str(matched_lead.get("email_thread_subject", "")),
        "thread_id": eff_thread_id,
        "external_message_id": eff_msg_id,
        "in_reply_to": validated.in_reply_to,
        "references": incoming_refs,
        "body": validated.raw_body,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "sent_at": datetime.now(timezone.utc).isoformat(),
    }
    upsert_document("message_queue", inbound_msg_doc["id"], inbound_msg_doc)

    parsed_res = parse_and_log_dealer_reply(
        dealer_id=eff_dealer_id,
        reply_text=validated.raw_body,
        channel=chan_norm,
        auto_draft_counter=False,
    )

    # Attach threading metadata to the latest inbound message in message_queue
    state_after = load_state()
    updated_lead = state_after.get("dealer_leads", {}).get(eff_dealer_id, matched_lead)
    if chan_norm == "EMAIL":
        updated_lead["email_thread_id"] = eff_thread_id
        updated_lead["last_email_message_id"] = eff_msg_id
        updated_lead["email_references"] = incoming_refs
        if validated.subject.strip():
            updated_lead["email_thread_subject"] = ensure_reply_subject(
                validated.subject.strip(),
                str(updated_lead.get("email_thread_subject", "")),
            )
        upsert_document("dealer_leads", eff_dealer_id, updated_lead)

    drafted_counter_msg = None
    if validated.auto_draft_counter:
        best_comp = get_best_competing_offer(exclude_dealer_id=eff_dealer_id)
        best_lead = (best_comp or {}).get("best_lead") or {}
        comp_otd = float(best_lead.get("otd_total") or updated_lead.get("target_otd") or 54800.0)
        target_otd = round(min(comp_otd - 250.0, float(updated_lead.get("otd_total") or 55300.0) - 350.0), 0)

        counter_gen = generate_natural_buyer_counter(
            dealer_lead=updated_lead,
            target_otd=target_otd,
            competing_best_otd=comp_otd,
            competing_dealer_name=str(best_lead.get("dealer_name") or "a competing Monmouth County Kia dealer"),
            round_number=int(updated_lead.get("round", 1)) + 1,
            dealer_inbound_text=validated.raw_body,
        )
        reply_subj = ensure_reply_subject(
            validated.subject or str(updated_lead.get("email_thread_subject", "")),
            str(updated_lead.get("email_thread_subject", "")),
        )
        drafted_counter_msg = queue_dealer_message(
            dealer_id=eff_dealer_id,
            body=counter_gen["script"],
            channel=chan_norm,
            subject=reply_subj,
            auto_dispatch=False,
        )

    return {
        "ok": True,
        "dealer_id": eff_dealer_id,
        "dealer_name": updated_lead.get("dealer_name"),
        "channel": chan_norm,
        "parsed_quote": parsed_res,
        "auto_drafted_counter": drafted_counter_msg,
        "thread_continuity": {
            "thread_id": eff_thread_id,
            "last_message_id": eff_msg_id,
            "references": incoming_refs,
            "subject": updated_lead.get("email_thread_subject", validated.subject),
        },
    }


def _strip_html_tags(raw_html: str) -> str:
    """Converts an HTML email body into clean plain text for quote extraction."""
    txt = re.sub(r"<style[^>]*>.*?</style>", " ", raw_html, flags=re.DOTALL | re.IGNORECASE)
    txt = re.sub(r"<script[^>]*>.*?</script>", " ", txt, flags=re.DOTALL | re.IGNORECASE)
    txt = re.sub(r"<br\s*/?>|</p>|</div>|</tr>|</li>", "\n", txt, flags=re.IGNORECASE)
    txt = re.sub(r"<[^>]+>", " ", txt)
    txt = html.unescape(txt)
    return re.sub(r"[ \t]+", " ", txt).strip()


def _extract_text_from_email_message(msg_obj: email.message.Message) -> str:
    """Extracts plain text and HTML/text attachment content from a parsed RFC 5322 email."""
    plain_parts: List[str] = []
    html_parts: List[str] = []
    if msg_obj.is_multipart():
        for part in msg_obj.walk():
            ctype = part.get_content_type()
            disp = str(part.get("Content-Disposition") or "")
            if ctype == "text/plain" and "attachment" not in disp.lower():
                payload = part.get_payload(decode=True)
                if payload:
                    plain_parts.append(payload.decode(part.get_content_charset() or "utf-8", errors="replace"))
            elif ctype == "text/html" and "attachment" not in disp.lower():
                payload = part.get_payload(decode=True)
                if payload:
                    html_parts.append(
                        _strip_html_tags(payload.decode(part.get_content_charset() or "utf-8", errors="replace"))
                    )
    else:
        payload = msg_obj.get_payload(decode=True)
        if payload:
            raw_text = payload.decode(msg_obj.get_content_charset() or "utf-8", errors="replace")
            if msg_obj.get_content_type() == "text/html":
                html_parts.append(_strip_html_tags(raw_text))
            else:
                plain_parts.append(raw_text)

    combined = "\n".join(plain_parts).strip()
    if not combined and html_parts:
        combined = "\n".join(html_parts).strip()
    return combined


def _decode_mime_header(raw_header: str) -> str:
    """Decodes an RFC 2047 MIME-encoded email header (e.g. Subject or From)."""
    if not raw_header:
        return ""
    parts = decode_header(raw_header)
    decoded_chunks: List[str] = []
    for content, charset in parts:
        if isinstance(content, bytes):
            decoded_chunks.append(content.decode(charset or "utf-8", errors="replace"))
        else:
            decoded_chunks.append(str(content))
    return "".join(decoded_chunks).strip()


@instrument_tool
def poll_personal_gmail_inbox(
    max_messages: int = 10,
    dealer_email_filter: str = "",
) -> Dict[str, Any]:
    """Polls the buyer's personal Gmail inbox for new dealer replies, extracts pricing, and queues Copilot counter-offers.

    Supports both Google Account App Password (`GMAIL_USER_EMAIL` + `GMAIL_APP_PASSWORD` over IMAP SSL `imap.gmail.com:993`)
    and Gmail OAuth2 REST API (`GMAIL_OAUTH_REFRESH_TOKEN`). Automatically preserves RFC 5322 `Message-ID`,
    `In-Reply-To`, and `References` headers so the buyer's next reply stays in the same Gmail thread.

    Args:
        max_messages (int): Maximum number of recent unread messages to inspect (default 10).
        dealer_email_filter (str): Optional dealer email address filter.

    Returns:
        Dict[str, Any]: Sync summary with `ok`, `provider`, `ingested_count`, and `ingested_messages`.
    """
    gmail_user = get_secret("GMAIL_USER_EMAIL", "").strip()
    gmail_app_pw = get_secret("GMAIL_APP_PASSWORD", "").replace(" ", "").strip()

    state = load_state()
    known_msg_ids = {
        str(m.get("external_message_id", ""))
        for m in state.get("message_queue", {}).values()
        if m.get("external_message_id")
    }

    if gmail_user and gmail_app_pw:
        with start_trace_span("gmail.imap_poll", {"user": redact_pii(gmail_user), "max_messages": max_messages}):
            try:
                ingested = []
                with imaplib.IMAP4_SSL("imap.gmail.com", 993) as imap:
                    imap.login(gmail_user, gmail_app_pw)
                    imap.select("INBOX")
                    search_criteria = (
                        f'(UNSEEN FROM "{dealer_email_filter.strip()}")'
                        if dealer_email_filter.strip()
                        else '(UNSEEN)'
                    )
                    status, data = imap.search(None, search_criteria)
                    if status == "OK" and data and data[0]:
                        msg_nums = data[0].split()[-max(1, int(max_messages)) :]
                        for num in reversed(msg_nums):
                            f_stat, msg_data = imap.fetch(num, "(RFC822)")
                            if f_stat != "OK" or not msg_data or not isinstance(msg_data[0], tuple):
                                continue
                            raw_bytes = msg_data[0][1]
                            parsed_email = email.message_from_bytes(raw_bytes)
                            msg_id_hdr = str(parsed_email.get("Message-ID") or "").strip()
                            if msg_id_hdr and msg_id_hdr in known_msg_ids:
                                continue
                            from_hdr = _decode_mime_header(str(parsed_email.get("From") or ""))
                            subj_hdr = _decode_mime_header(str(parsed_email.get("Subject") or ""))
                            in_reply_hdr = str(parsed_email.get("In-Reply-To") or "").strip()
                            refs_hdr = str(parsed_email.get("References") or "").strip()
                            body_txt = _extract_text_from_email_message(parsed_email)
                            if not body_txt:
                                continue

                            # Match against known dealer leads or Telluride keywords
                            matched = _match_dealer_lead_by_contact_or_text(
                                sender_contact=from_hdr,
                                subject=subj_hdr,
                                raw_body=body_txt,
                            )
                            if matched:
                                res = ingest_live_dealer_message(
                                    dealer_id=str(matched["id"]),
                                    sender_contact=from_hdr,
                                    channel="EMAIL",
                                    raw_body=body_txt,
                                    subject=subj_hdr,
                                    external_message_id=msg_id_hdr,
                                    in_reply_to=in_reply_hdr,
                                    references=refs_hdr,
                                    auto_draft_counter=True,
                                )
                                ingested.append(res)
                return {
                    "ok": True,
                    "provider": "personal_gmail_imap_ssl",
                    "ingested_count": len(ingested),
                    "ingested_messages": ingested,
                }
            except Exception as exc:
                return build_guided_error(
                    error_code="GMAIL_IMAP_SYNC_FAILED",
                    message=f"Could not poll Gmail IMAP inbox: {exc}",
                    recovery_instructions="Verify `GMAIL_USER_EMAIL` and your 16-character `GMAIL_APP_PASSWORD` in Campaign Settings or `.env`, or paste the dealer's email reply directly into the AI Chat Agent.",
                )

    return {
        "ok": True,
        "provider": "manual_or_webhook_mode",
        "ingested_count": 0,
        "ingested_messages": [],
        "message": (
            "No Gmail App Password configured yet. Enter your Gmail address + 16-letter Google App Password in "
            "Campaign Settings -> Live Gmail & Mobile Setup to enable 1-click inbox sync, or paste any dealer reply directly into the Chat Agent."
        ),
    }


@instrument_tool
def get_dealer_conversation_thread(dealer_id: str) -> Dict[str, Any]:
    """Retrieves the unified, chronological single-thread conversation history (Emails & SMS) for a dealership.

    Args:
        dealer_id (str): Dealership lead ID (e.g. 'dlr-raceway-kia-of-freehold').

    Returns:
        Dict[str, Any]: Dictionary containing `dealer_id`, `dealer_name`, `contact_name`, `contact_phone`,
            `contact_email`, `email_thread_subject`, `email_thread_id`, and `messages` sorted chronologically.
    """
    state = load_state()
    lead = state.get("dealer_leads", {}).get(dealer_id)
    if not lead:
        return build_guided_error(
            error_code="DEALER_NOT_FOUND",
            message=f"Dealer '{dealer_id}' not found.",
            recovery_instructions="Call `get_negotiation_dashboard()` to inspect valid dealer IDs.",
            invalid_fields={"dealer_id": dealer_id},
        )

    all_msgs = [
        m
        for m in state.get("message_queue", {}).values()
        if m.get("dealer_id") == dealer_id
    ]
    all_msgs.sort(key=lambda m: str(m.get("sent_at") or m.get("created_at") or ""))

    return {
        "ok": True,
        "dealer_id": dealer_id,
        "dealer_name": lead.get("dealer_name"),
        "contact_name": lead.get("contact_name"),
        "contact_phone": lead.get("contact_phone"),
        "contact_email": lead.get("contact_email"),
        "has_real_contact": not (
            is_placeholder_contact(lead.get("contact_phone", ""), "SMS_PERSONAL")
            and is_placeholder_contact(lead.get("contact_email", ""), "EMAIL")
        ),
        "email_thread_id": lead.get("email_thread_id", ""),
        "email_thread_subject": lead.get("email_thread_subject", ""),
        "last_email_message_id": lead.get("last_email_message_id", ""),
        "message_count": len(all_msgs),
        "messages": all_msgs,
    }
