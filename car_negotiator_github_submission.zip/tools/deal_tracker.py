"""
Multi-Dealer CRM & Quote Comparison State Tracker.
Configured for Monmouth County, NJ Buyer:
- Strictly NJ dealerships only, prioritizing Monmouth & Ocean Counties, NJ (6.625% NJ Sales Tax)
- Powertrain Requirement: 2027 Kia Telluride Hybrid ONLY (Hybrid is a strict requirement)
- Trim Priority Order:
  (1) 2027 Kia Telluride Hybrid SX X-Line ($53,890 MSRP)
  (2) 2027 Kia Telluride Hybrid SX Prestige ($55,590 MSRP)
  (3) 2027 Kia Telluride Hybrid SX Prestige X-Line ($56,985 MSRP)
- Interior Preference: Non-Black Interior Preferred (~$295 factory option; Black accepted if OTD deal is stronger)
- Negotiates strictly on OTD Price with dealers, while automatically computing Reverse OTD -> Monthly Finance & Lease Payments for the buyer.
"""

from datetime import datetime, timezone
import re
from typing import Any, Dict, List
import uuid

from .context_memory import get_semantic_memory_store
from .finance_tools import (
    audit_dealer_quote,
    calculate_color_parity_benchmark,
    calculate_monthly_from_otd,
    calculate_nj_payments,
)
from .firestore_sync import load_state, upsert_document
from .guardrails import require_human_confirmation_hook
from .market_research_tools import (
    DEFAULT_MARKET_BENCHMARK,
    get_prevailing_market_benchmark,
)
from .observability import instrument_tool
from .schemas import build_guided_error

TRIM_PRIORITY_ORDER = [
    "2027 Kia Telluride Hybrid SX X-Line",
    "2027 Kia Telluride Hybrid SX Prestige",
    "2027 Kia Telluride Hybrid SX Prestige X-Line",
]


def _slugify(text: str) -> str:
    """Converts a dealership name or string into a URL/Firestore-safe slug.

    Args:
        text (str): Raw text to slugify.

    Returns:
        str: Lowercase hyphenated identifier.
    """
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug or f"id-{uuid.uuid4().hex[:6]}"


@instrument_tool
def get_trim_priority_rank(trim_level: str) -> int:
    """Computes the buyer's trim priority rank for a 2027 Kia Telluride Hybrid trim.

    Args:
        trim_level (str): Vehicle trim name (e.g., `'2027 Kia Telluride Hybrid SX X-Line'`).

    Returns:
        int: `1` for Hybrid SX X-Line, `2` for Hybrid SX Prestige, `3` for Hybrid SX Prestige X-Line,
        or `4` for any other trim.
    """
    norm = trim_level.lower()
    if "prestige" in norm and "x-line" in norm:
        return 3
    if "prestige" in norm:
        return 2
    if "x-line" in norm and "sx" in norm:
        return 1
    return 4


@instrument_tool
def create_or_update_campaign(
    vehicle: str = "2027 Kia Telluride Hybrid (Priority: #1 Hybrid SX X-Line, #2 Hybrid SX Prestige, #3 Hybrid SX Prestige X-Line — Non-Black Interior Nice-to-Have)",
    deal_type: str = "PURCHASE",
    target_msrp: float = 53890.0,
    target_otd_or_monthly: float = 54800.0,
    zip_code: str = "07724",
    tax_rate_percent: float = 6.625,
    term_months: int = 36,
    annual_miles: int = 12000,
    base_buy_rate_mf: float = 0.00190,
    residual_percent: float = 63.0,
    buyer_name: str = "Alex",
    buyer_phone: str = "",
    target_delivery_window: str = "End of December 2026",
    inventory_preference: str = "IN_TRANSIT_DECEMBER_DELIVERY",
    interior_preference: str = "Non-Black Interior Nice-to-Have Tiebreaker (~$295 factory option; Black accepted if OTD deal is stronger)",
    dealer_region_rule: str = "NJ Only — Priority #1: Monmouth & Ocean Counties, NJ",
    trade_in_secrecy_active: bool = True,
    autonomy_mode: str = "COPILOT",
) -> Dict[str, Any]:
    """Creates or updates the active 2027 Kia Telluride Hybrid campaign and syncs to Firestore.

    Args:
        vehicle (str): Target vehicle description and trim priority order.
        deal_type (str): Deal structure mode (`'PURCHASE'` or `'LEASE'`). Defaults to `'PURCHASE'`.
        target_msrp (float): Primary target trim MSRP in USD. Defaults to 53890.0.
        target_otd_or_monthly (float): Target Out-The-Door price (PURCHASE) or monthly payment (LEASE).
            Defaults to 54800.0.
        zip_code (str): Buyer's New Jersey ZIP code. Defaults to `'07724'`.
        tax_rate_percent (float): Applicable state sales tax percentage. Defaults to 6.625.
        term_months (int): Target lease term in months. Defaults to 36.
        annual_miles (int): Target annual lease mileage allowance. Defaults to 12000.
        base_buy_rate_mf (float): Kia Finance Tier 1 base buy-rate money factor. Defaults to 0.00190.
        residual_percent (float): Kia Finance residual value percentage of MSRP. Defaults to 63.0.
        buyer_name (str): Buyer's first name used in outbound scripts. Defaults to `'Alex'`.
        buyer_phone (str): Optional buyer phone number. Defaults to `''`.
        target_delivery_window (str): Desired vehicle delivery window. Defaults to `'End of December 2026'`.
        inventory_preference (str): Inventory status preference. Defaults to `'IN_TRANSIT_DECEMBER_DELIVERY'`.
        interior_preference (str): Interior color preference note.
        dealer_region_rule (str): Geographic dealership filter rule.
        trade_in_secrecy_active (bool): Whether to enforce the Phase 1 Trade-In Secrecy Gag Order.
            Defaults to True.
        autonomy_mode (str): Execution autonomy level (`'COPILOT'`, `'SEMI_AUTO'`, or `'FULL_AUTOPILOT'`).
            Defaults to `'COPILOT'`.

    Returns:
        Dict[str, Any]: Persisted campaign configuration dictionary synced to Firestore.
    """
    campaign_id = "camp-2027-kia-telluride-hybrid-nj"
    deal_type_norm = deal_type.strip().upper()
    if deal_type_norm not in ("PURCHASE", "LEASE"):
        deal_type_norm = "PURCHASE"

    state = load_state()
    existing_camp = state.get("campaigns", {}).get(campaign_id, {})
    market_bench = existing_camp.get("market_benchmark") or DEFAULT_MARKET_BENCHMARK

    campaign = {
        "id": campaign_id,
        "vehicle": vehicle,
        "powertrain_requirement": "HYBRID_ONLY",
        "trim_priority_order": TRIM_PRIORITY_ORDER,
        "interior_preference": interior_preference,
        "dealer_region_rule": dealer_region_rule,
        "buyer_county": "Monmouth County, NJ",
        "deal_type": deal_type_norm,
        "target_msrp": round(float(target_msrp), 2),
        "target_otd_or_monthly": round(float(target_otd_or_monthly), 2),
        "zip_code": str(zip_code),
        "tax_rate_percent": float(tax_rate_percent),
        "term_months": int(term_months),
        "annual_miles": int(annual_miles),
        "base_buy_rate_mf": float(base_buy_rate_mf),
        "residual_percent": float(residual_percent),
        "buyer_name": buyer_name,
        "buyer_phone": buyer_phone,
        "target_delivery_window": target_delivery_window,
        "inventory_preference": inventory_preference,
        "trade_in_secrecy_active": bool(trade_in_secrecy_active),
        "trade_in_policy_note": "STRICT: Zero mention of trade-in or current lease expiration until 2027 Kia Telluride Hybrid OTD deal is secured in writing (Checkbox #2).",
        "market_benchmark": market_bench,
        "autonomy_mode": autonomy_mode or existing_camp.get("autonomy_mode", "COPILOT"),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    return upsert_document("negotiation_campaigns", campaign_id, campaign)


@instrument_tool
def upsert_dealer_lead(
    dealer_name: str,
    contact_name: str = "Internet Sales Manager",
    contact_email: str = "",
    contact_phone: str = "",
    preferred_channel: str = "SMS_PERSONAL",
    vin: str = "",
    stock_number: str = "",
    msrp: float = 53890.0,
    persona: str = "volume_dealer",
    inventory_status: str = "IN_TRANSIT",
    eta_delivery: str = "Dec 22–Dec 29, 2026",
    trim_level: str = "2027 Kia Telluride Hybrid SX X-Line",
    exterior_color: str = "Wolf Gray",
    interior_color: str = "Terracotta Brown Leather (Preferred +$295)",
    city: str = "Freehold",
    county: str = "Monmouth County",
    state: str = "NJ",
) -> Dict[str, Any]:
    """Registers or updates a New Jersey dealership in the negotiation tracker and syncs to Firestore.

    Args:
        dealer_name (str): Full dealership name (e.g., `'Raceway Kia of Freehold'`).
        contact_name (str): Sales contact name or title. Defaults to `'Internet Sales Manager'`.
        contact_email (str): Dealership BDC/Internet Sales email address.
        contact_phone (str): Dealership contact phone number in E.164 format.
        preferred_channel (str): Preferred outreach channel (`'SMS_PERSONAL'`, `'SMS_TWILIO'`, or `'EMAIL'`).
            Defaults to `'SMS_PERSONAL'`.
        vin (str): 17-character Vehicle Identification Number (`5XYP...`).
        stock_number (str): Dealership stock number.
        msrp (float): Vehicle window sticker MSRP in USD. Defaults to 53890.0.
        persona (str): Simulated dealer negotiation persona (`'volume_dealer'`, `'high_markup_dealer'`,
            or `'old_school_dealer'`). Defaults to `'volume_dealer'`.
        inventory_status (str): Lot status (`'IN_TRANSIT'` or `'ON_LOT'`). Defaults to `'IN_TRANSIT'`.
        eta_delivery (str): Estimated arrival window for incoming units. Defaults to `'Dec 22–Dec 29, 2026'`.
        trim_level (str): Vehicle trim string. Defaults to `'2027 Kia Telluride Hybrid SX X-Line'`.
        exterior_color (str): Exterior paint color. Defaults to `'Wolf Gray'`.
        interior_color (str): Interior upholstery color. Defaults to `'Terracotta Brown Leather (Preferred +$295)'`.
        city (str): Dealership city. Defaults to `'Freehold'`.
        county (str): Dealership NJ county (`'Monmouth County'` or `'Ocean County'`). Defaults to `'Monmouth County'`.
        state (str): Two-letter state code. Defaults to `'NJ'`.

    Returns:
        Dict[str, Any]: Upserted dealer lead record with county priority tier, trim rank, and market benchmarks.
    """
    state_code = state.strip().upper()
    county_norm = county.strip()
    is_priority_county = any(c in county_norm.lower() for c in ("monmouth", "ocean"))
    county_priority_tier = (
        1
        if (state_code == "NJ" and is_priority_county)
        else (2 if state_code == "NJ" else 9)
    )

    trim_rank = get_trim_priority_rank(trim_level)
    is_hybrid = "hybrid" in trim_level.lower()
    has_black_interior = (
        "black" in interior_color.lower()
        and "non-black" not in interior_color.lower()
    )
    trim_bench = get_prevailing_market_benchmark(trim_level=trim_level, msrp=msrp)

    app_state = load_state()
    campaign_id = (
        app_state.get("active_campaign_id") or "camp-2027-kia-telluride-hybrid-nj"
    )
    dealer_id = f"dlr-{_slugify(dealer_name)}"
    existing = app_state.get("dealer_leads", {}).get(dealer_id, {})

    lead = {
        **existing,
        "id": dealer_id,
        "campaign_id": campaign_id,
        "dealer_name": dealer_name,
        "city": city,
        "county": county_norm,
        "state": state_code,
        "county_priority_tier": county_priority_tier,
        "location_label": f"{city}, {county_norm}, {state_code}",
        "contact_name": contact_name,
        "contact_email": contact_email
        or existing.get("contact_email", f"sales@{_slugify(dealer_name)}.example.com"),
        "contact_phone": contact_phone or existing.get("contact_phone", "+17325550101"),
        "preferred_channel": preferred_channel.upper(),
        "vin": vin or existing.get("vin", f"5XYP5DGC{dealer_id[-4:].upper()}27H01"),
        "stock_number": stock_number
        or existing.get("stock_number", f"KIA-{dealer_id[-4:].upper()}"),
        "trim_level": trim_level,
        "is_hybrid": is_hybrid,
        "trim_priority_rank": trim_rank,
        "exterior_color": exterior_color,
        "interior_color": interior_color,
        "is_non_black_interior": not has_black_interior,
        "interior_preference_note": (
            "Matches Non-Black Preference (includes ~$295 factory color option)"
            if not has_black_interior
            else "Standard Black Interior ($0 factory color charge — eligible if OTD savings outweigh preference)"
        ),
        "msrp": round(float(msrp), 2),
        "invoice_price": trim_bench["estimated_invoice_price"],
        "dealer_holdback_amount": trim_bench["dealer_holdback_amount"],
        "prevailing_market_discount_pct": trim_bench["prevailing_market_discount_pct"],
        "prevailing_market_selling_price": trim_bench[
            "prevailing_market_selling_price"
        ],
        "stretch_target_discount_pct": trim_bench["stretch_target_discount_pct"],
        "persona": persona,
        "inventory_status": inventory_status.upper(),
        "eta_delivery": eta_delivery,
        "stage": existing.get("stage", "NEW_LEAD"),
        "round": existing.get("round", 0),
        "selling_price": existing.get("selling_price", round(float(msrp), 2)),
        "otd_total": existing.get("otd_total", 0.0),
        "monthly_payment": existing.get("monthly_payment", 0.0),
        "drive_off": existing.get("drive_off", 0.0),
        "money_factor": existing.get("money_factor", 0.0),
        "residual_percent": existing.get("residual_percent", 63.0),
        "dealer_addons_total": existing.get("dealer_addons_total", 0.0),
        "addon_descriptions": existing.get("addon_descriptions", ""),
        "doc_fee": existing.get("doc_fee", 499.0),
        "gov_fees": existing.get("gov_fees", 385.0),
        "rebates": existing.get("rebates", 0.0),
        "red_flags": existing.get("red_flags", []),
        "last_dealer_message": existing.get("last_dealer_message", ""),
    }
    return upsert_document("dealer_leads", dealer_id, lead)


@instrument_tool
def record_dealer_quote(
    dealer_id: str,
    selling_price: float,
    dealer_quoted_otd: float = 0.0,
    dealer_quoted_monthly: float = 0.0,
    dealer_quoted_drive_off: float = 0.0,
    money_factor: float = 0.00190,
    residual_percent: float = 63.0,
    dealer_addons_total: float = 0.0,
    addon_descriptions: str = "",
    doc_fee: float = 499.0,
    gov_fees: float = 385.0,
    rebates: float = 0.0,
    cap_cost_reduction_down: float = 0.0,
    raw_dealer_message: str = "",
) -> Dict[str, Any]:
    """Records an inbound dealer quote, audits it against prevailing NJ Hybrid deals, and computes Reverse OTD -> Monthly payments.

    Args:
        dealer_id (str): Dealership identifier or name.
        selling_price (float): Quoted vehicle selling price before taxes and fees in USD.
        dealer_quoted_otd (float): Optional total Out-The-Door price quoted by the dealer. Defaults to 0.0.
        dealer_quoted_monthly (float): Optional monthly payment quoted by the dealer. Defaults to 0.0.
        dealer_quoted_drive_off (float): Optional total due at signing quoted by the dealer. Defaults to 0.0.
        money_factor (float): Lease money factor quoted by the dealer. Defaults to 0.00190.
        residual_percent (float): Residual value percentage of MSRP. Defaults to 63.0.
        dealer_addons_total (float): Total mandatory/optional dealer add-ons in USD. Defaults to 0.0.
        addon_descriptions (str): Description of dealer add-ons (e.g., `'VIN Etch, Nitrogen'`). Defaults to `''`.
        doc_fee (float): Dealer documentation fee in USD. Defaults to 499.0.
        gov_fees (float): NJ MVC registration/title fees in USD. Defaults to 385.0.
        rebates (float): Applicable manufacturer rebates in USD. Defaults to 0.0.
        cap_cost_reduction_down (float): Cash down or trade equity applied in USD. Defaults to 0.0.
        raw_dealer_message (str): Raw text of the dealer's quote or message. Defaults to `''`.

    Returns:
        Dict[str, Any]: Dictionary containing `dealer_lead`, `financial_audit`, and `reverse_otd`.
    """
    state = load_state()
    if not dealer_id.startswith("dlr-"):
        dealer_id = f"dlr-{_slugify(dealer_id)}"

    lead = state.get("dealer_leads", {}).get(dealer_id)
    if not lead:
        lead = upsert_dealer_lead(
            dealer_name=dealer_id.replace("dlr-", "").replace("-", " ").title()
        )

    camp_id = lead.get("campaign_id") or state.get("active_campaign_id")
    campaign = state.get("campaigns", {}).get(camp_id, {})
    deal_type = campaign.get("deal_type", "PURCHASE")
    msrp = float(lead.get("msrp") or campaign.get("target_msrp") or 53890.0)
    trim_level = lead.get("trim_level", "2027 Kia Telluride Hybrid SX X-Line")
    tax_rate = float(campaign.get("tax_rate_percent", 6.625))
    term_months = int(campaign.get("term_months", 36))
    annual_miles = int(campaign.get("annual_miles", 12000))
    base_mf = float(campaign.get("base_buy_rate_mf", 0.00190))

    trim_bench = get_prevailing_market_benchmark(trim_level=trim_level, msrp=msrp)
    prevailing_pct = trim_bench["prevailing_market_discount_pct"]
    stretch_pct = trim_bench["stretch_target_discount_pct"]
    invoice_pct = trim_bench["invoice_below_msrp_pct"]

    audit = audit_dealer_quote(
        deal_type=deal_type,
        msrp=msrp,
        selling_price=selling_price,
        dealer_quoted_otd=dealer_quoted_otd if dealer_quoted_otd > 0 else None,
        dealer_quoted_monthly=dealer_quoted_monthly
        if dealer_quoted_monthly > 0
        else None,
        dealer_quoted_drive_off=dealer_quoted_drive_off
        if dealer_quoted_drive_off > 0
        else None,
        residual_percent=residual_percent,
        money_factor=money_factor,
        base_buy_rate_mf=base_mf,
        term_months=term_months,
        annual_miles=annual_miles,
        doc_fee=doc_fee,
        gov_fees=gov_fees,
        dealer_addons_total=dealer_addons_total,
        rebates=rebates,
        cap_cost_reduction_down=cap_cost_reduction_down,
        tax_rate_percent=tax_rate,
        prevailing_market_discount_pct=prevailing_pct,
        stretch_counter_discount_pct=stretch_pct,
        invoice_below_msrp_pct=invoice_pct,
    )

    if not lead.get("is_hybrid", "hybrid" in trim_level.lower()):
        audit["red_flags"].insert(
            0,
            f"POWERTRAIN VIOLATION: Unit '{trim_level}' is not a Hybrid! Buyer strictly requires the 2027 Kia Telluride Hybrid.",
        )
    if lead.get("state", "NJ") != "NJ":
        audit["red_flags"].insert(
            0,
            f"LOCATION VIOLATION: Dealer is in {lead.get('state')}. Buyer only considers NJ dealerships (prioritizing Monmouth & Ocean Counties).",
        )
    if not lead.get("is_non_black_interior", True):
        audit["red_flags"].append(
            "INTERIOR NOTE: Unit has Standard Black interior (Non-Black is preferred, though Black saves ~$295 factory option fee on MSRP)."
        )
    if lead.get("inventory_status") == "IN_TRANSIT" and dealer_addons_total > 0:
        audit["red_flags"].insert(
            0,
            f"IN-TRANSIT VIOLATION: Unit is still in transit ({lead.get('eta_delivery')}), so ${dealer_addons_total:,.0f} add-ons have NOT been installed yet! Demand a PDI Hold with $0 add-ons.",
        )

    # Always compute OTD even in LEASE mode so we can work backward from OTD for both modes
    otd_calc = audit_dealer_quote(
        deal_type="PURCHASE",
        msrp=msrp,
        selling_price=selling_price,
        dealer_quoted_otd=dealer_quoted_otd if dealer_quoted_otd > 0 else None,
        doc_fee=doc_fee,
        gov_fees=gov_fees,
        dealer_addons_total=dealer_addons_total,
        rebates=rebates,
        tax_rate_percent=tax_rate,
        prevailing_market_discount_pct=prevailing_pct,
        stretch_counter_discount_pct=stretch_pct,
        invoice_below_msrp_pct=invoice_pct,
    )

    effective_otd = (
        dealer_quoted_otd
        if dealer_quoted_otd > 0
        else otd_calc.get("otd_total", 0.0)
    )

    # Work backward from OTD price to calculate monthly finance & lease payments for the buyer!
    reverse_otd = calculate_monthly_from_otd(
        otd_price=effective_otd,
        msrp=msrp,
        tax_rate_percent=tax_rate,
        doc_fee=doc_fee,
        gov_fees=gov_fees,
        rebates=rebates,
        cash_down_or_trade_equity=cap_cost_reduction_down,
        loan_apr_percent=4.9,
        loan_term_months=60,
        lease_term_months=term_months,
        lease_annual_miles=annual_miles,
        residual_percent=residual_percent,
        money_factor=money_factor,
    )

    effective_monthly = (
        dealer_quoted_monthly
        if dealer_quoted_monthly > 0
        else reverse_otd["lease_from_otd_cap_cost"]["monthly_lease_payment_with_fees_upfront"]
    )
    effective_drive_off = (
        dealer_quoted_drive_off
        if dealer_quoted_drive_off > 0
        else reverse_otd["lease_from_otd_cap_cost"]["drive_off_due_at_signing"]
    )

    color_parity = calculate_color_parity_benchmark(
        msrp=msrp,
        selling_price=selling_price,
        otd_total=effective_otd,
        is_non_black_interior=bool(lead.get("is_non_black_interior", True)),
        competing_black_otd=0.0,
        competing_black_msrp=msrp,
        competing_black_discount_pct=stretch_pct,
        tax_rate_percent=tax_rate,
        residual_percent=residual_percent,
        lease_term_months=term_months,
        money_factor=money_factor,
    )

    # Track multi-round quote history and price drop progress
    quote_history: List[Dict[str, Any]] = list(lead.get("quote_history") or [])
    current_round_num = max(1, int(lead.get("round") or len(quote_history) + 1))
    history_entry = {
        "round": current_round_num,
        "selling_price": round(selling_price, 2),
        "discount_pct": audit.get("discount_pct", 0.0),
        "otd_total": round(effective_otd, 2),
        "dealer_addons_total": round(dealer_addons_total, 2),
        "doc_fee": round(doc_fee, 2),
        "money_factor": money_factor,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    if not quote_history or abs(float(quote_history[-1].get("otd_total", 0)) - effective_otd) > 1.0:
        quote_history.append(history_entry)

    opening_otd = float(
        lead.get("opening_otd")
        or (quote_history[0]["otd_total"] if quote_history else effective_otd)
    )
    total_otd_savings = max(0.0, round(opening_otd - effective_otd, 2))

    # V3 Herbie NJ Payments & True Deal Score calculation
    nj_pay = calculate_nj_payments(
        msrp=msrp,
        selling_price=selling_price,
        doc_fee=doc_fee,
        mandatory_addons=dealer_addons_total,
        rebates=rebates if rebates > 0 else 750.0,
        cash_down=cap_cost_reduction_down if cap_cost_reduction_down > 0 else 3000.0,
        target_monthly_budget=750.0,
        loan_apr_percent=4.49,
        loan_term_months=60,
        lease_term_months=term_months,
        residual_percent=residual_percent,
        base_mf=money_factor if money_factor >= 0.00200 else 0.00245,
        mv_tire_fees=gov_fees if gov_fees > 0 else 400.0,
    )

    from .inventory_scraper import MONMOUTH_OCEAN_KIA_DEALERS
    base_name = _normalize_dealer_group_name(lead.get("base_dealer_name") or lead.get("dealer_name", ""))
    dealer_meta = next(
        (m for m in MONMOUTH_OCEAN_KIA_DEALERS if m["dealer_name"] == base_name),
        {},
    )

    # Preserve stage if OTD is already locked (Gate #2)
    current_stage = (
        "DEAL_SECURED"
        if lead.get("otd_locked_in_writing") or lead.get("stage") == "DEAL_SECURED"
        else "QUOTE_AUDITED"
    )

    lead.update(
        {
            "stage": current_stage,
            "negotiation_status": current_stage,
            "round_Number": current_round_num,
            "stock_status": lead.get("inventory_status", "IN_TRANSIT"),
            "display_name": dealer_meta.get("display_name") or base_name,
            "quirk_note": dealer_meta.get("quirk_note", ""),
            "bidding_strategy": dealer_meta.get("bidding_strategy", ""),
            "location_label": f"{lead.get('city', 'Freehold')}, {lead.get('county', 'Monmouth County')}",
            "selling_price": round(selling_price, 2),
            "invoice_price": trim_bench["estimated_invoice_price"],
            "dealer_holdback_amount": trim_bench["dealer_holdback_amount"],
            "prevailing_market_discount_pct": prevailing_pct,
            "prevailing_market_selling_price": trim_bench[
                "prevailing_market_selling_price"
            ],
            "stretch_target_discount_pct": stretch_pct,
            "vs_prevailing_market_dollars": audit.get(
                "vs_prevailing_market_dollars", 0.0
            ),
            "price_vs_trim_invoice": audit.get(
                "vs_prevailing_market_dollars", 0.0
            ),
            "discount_off_msrp": audit.get("discount_off_msrp", 0.0),
            "discount_pct": audit.get("discount_pct", 0.0),
            "discount_off_msrp_pct": audit.get("discount_pct", 0.0),
            "otd_total": round(effective_otd, 2),
            "opening_otd": round(opening_otd, 2),
            "total_otd_savings": total_otd_savings,
            "quote_history": quote_history,
            "color_parity_benchmark": color_parity,
            "color_parity_otd": color_parity["color_parity_otd"],
            "otd_color_delta": color_parity["otd_color_delta"],
            "monthly_payment": round(effective_monthly, 2),
            "drive_off": round(effective_drive_off, 2),
            "implied_finance_60mo": reverse_otd["finance_purchase_from_otd"]["monthly_60mo"],
            "finance_monthly_60m": reverse_otd["finance_purchase_from_otd"]["monthly_60mo"],
            "implied_finance_72mo": reverse_otd["finance_purchase_from_otd"]["monthly_72mo"],
            "implied_lease_36mo": reverse_otd["lease_from_otd_cap_cost"]["monthly_lease_payment_with_fees_upfront"],
            "lease_monthly_36m": reverse_otd["lease_from_otd_cap_cost"]["monthly_lease_payment_with_fees_upfront"],
            "implied_sign_and_drive_lease_36mo": reverse_otd["lease_from_otd_cap_cost"]["sign_and_drive_zero_due_monthly"],
            "reverse_otd_breakdown": reverse_otd,
            "true_deal_score": nj_pay.get("true_deal_score", 0.0),
            "pure_dealer_discount": nj_pay.get("pure_dealer_discount", 0.0),
            "purchase_otd": nj_pay.get("purchase_otd", round(effective_otd, 2)),
            "loan_monthly_60mo": nj_pay.get("loan_monthly_60mo", 0.0),
            "loan_monthly_60mo_zero_down": nj_pay.get("loan_monthly_60mo_zero_down", 0.0),
            "lease_monthly_36mo": nj_pay.get("lease_monthly_36mo", 0.0),
            "lease_monthly_36mo_sign_and_drive": nj_pay.get("lease_monthly_36mo_sign_and_drive", 0.0),
            "extra_discount_to_hit_lease_budget": nj_pay.get("extra_discount_to_hit_lease_budget", 0.0),
            "nj_payments_breakdown": nj_pay,
            "deflection_strikes": int(lead.get("deflection_strikes", 0)),
            "active_operating_mode": lead.get("active_operating_mode", "MODE_2_DEALER_OFFER_RECEIVED"),
            "negotiation_stage": (
                "STAGE_2_LOT_RAID"
                if str(lead.get("inventory_status", "IN_TRANSIT")).upper() == "ON_LOT"
                else "STAGE_1_RESERVE"
            ),
            "effective_monthly_cost": audit.get(
                "effective_monthly_cost", round(effective_monthly, 2)
            ),
            "money_factor": money_factor,
            "equivalent_apr": audit.get("equivalent_apr", round(money_factor * 2400, 2)),
            "residual_percent": residual_percent,
            "dealer_addons_total": round(dealer_addons_total, 2),
            "addon_descriptions": addon_descriptions,
            "doc_fee": round(doc_fee, 2),
            "gov_fees": round(gov_fees, 2),
            "rebates": round(rebates, 2),
            "red_flags": audit.get("red_flags", []),
            "recommended_counter_selling_price": otd_calc.get(
                "recommended_counter_selling_price",
                trim_bench["stretch_counter_selling_price"],
            ),
            "recommended_counter_otd": otd_calc.get("recommended_counter_otd", 0.0),
            "recommended_counter_monthly": audit.get(
                "recommended_counter_monthly", 0.0
            ),
            "one_percent_rule_ratio": audit.get("one_percent_rule_ratio", 0.0),
            "leasehackr_score_years": audit.get("leasehackr_score_years", 0.0),
            "last_dealer_message": raw_dealer_message
            or lead.get("last_dealer_message", ""),
        }
    )

    saved = upsert_document("dealer_leads", dealer_id, lead)

    # Index quote in semantic memory store for RAG retrieval
    try:
        mem_store = get_semantic_memory_store()
        mem_store.upsert_memory_entry(
            entry_id=f"quote-{dealer_id}-r{current_round_num}",
            category="dealer_quote",
            text=(
                f"{saved.get('dealer_name')} ({saved.get('location_label')}) quoted "
                f"${saved.get('otd_total', 0):,.2f} OTD (${saved.get('selling_price', 0):,.2f} selling price, "
                f"{saved.get('discount_pct', 0)}% off ${saved.get('msrp', 0):,.0f} MSRP, "
                f"${saved.get('dealer_addons_total', 0):,.0f} add-ons) on {saved.get('trim_level')} "
                f"VIN {saved.get('vin')} in {saved.get('interior_color')}. "
                f"Red flags: {'; '.join(saved.get('red_flags', [])) or 'None'}."
            ),
            metadata={
                "dealer_id": dealer_id,
                "dealer_name": saved.get("dealer_name"),
                "otd_total": saved.get("otd_total"),
                "selling_price": saved.get("selling_price"),
                "discount_pct": saved.get("discount_pct"),
                "vin": saved.get("vin"),
            },
        )
    except Exception:
        pass

    return {"dealer_lead": saved, "financial_audit": audit, "reverse_otd": reverse_otd}


@instrument_tool
def get_best_competing_offer(exclude_dealer_id: str = "") -> Dict[str, Any]:
    """Finds the best verified NJ Hybrid dealer quote across all dealers to use as competitive leverage.

    Args:
        exclude_dealer_id (str): Optional dealer ID to exclude when searching for competing quotes.

    Returns:
        Dict[str, Any]: Best competing offer summary including `has_competing_offer`, `best_dealer_name`,
        `best_otd_total`, `best_discount_pct`, and a ready-to-use `leverage_script`.
    """
    state = load_state()
    camp_id = state.get("active_campaign_id")
    campaign = state.get("campaigns", {}).get(camp_id, {})
    deal_type = campaign.get("deal_type", "PURCHASE")

    leads = [
        d
        for d in state.get("dealer_leads", {}).values()
        if d.get("state", "NJ") == "NJ"
        and d.get("is_hybrid", True)
        and (not exclude_dealer_id or d.get("id") != exclude_dealer_id)
    ]
    quoted_leads = [
        d
        for d in leads
        if (deal_type == "LEASE" and d.get("monthly_payment", 0) > 0)
        or (deal_type == "PURCHASE" and d.get("otd_total", 0) > 0)
    ]

    if not quoted_leads:
        return {
            "has_competing_offer": False,
            "deal_type": deal_type,
            "message": "No itemized Monmouth/Ocean County NJ Hybrid dealer quotes recorded yet.",
        }

    # Sort primarily by county priority, % off MSRP (cross-trim normalized), and OTD
    quoted_leads.sort(
        key=lambda d: (
            d.get("county_priority_tier", 1),
            -float(d.get("discount_pct", 0.0)),
            0 if d.get("is_non_black_interior", True) else 1,
            d.get("trim_priority_rank", 1),
        )
    )
    best = quoted_leads[0]
    trim_detail = best.get("trim_level", "2027 Kia Telluride Hybrid SX X-Line")
    short_trim = trim_detail.replace("2027 Kia ", "")
    interior_detail = best.get("interior_color", "Terracotta Brown Leather")
    best_otd = float(best.get("otd_total") or 55303.0)
    target_beat_otd = round(best_otd - 400.0, 0)

    return {
        "has_competing_offer": True,
        "deal_type": deal_type,
        "best_lead": best,
        "best_dealer_id": best["id"],
        "best_dealer_name": best["dealer_name"],
        "best_dealer_county": f"{best.get('city', '')}, {best.get('county', 'Monmouth County')}, NJ",
        "best_trim_level": trim_detail,
        "best_interior_color": interior_detail,
        "best_selling_price": best.get("selling_price"),
        "best_discount_pct": best.get("discount_pct"),
        "best_otd_total": best.get("otd_total"),
        "best_monthly_payment": best.get("monthly_payment"),
        "best_drive_off": best.get("drive_off"),
        "best_implied_finance_60mo": best.get("implied_finance_60mo"),
        "best_implied_lease_36mo": best.get("implied_lease_36mo"),
        "leverage_script": (
            f"I have a written local offer on an incoming December {short_trim} at ${best_otd:,.0f} Out-The-Door with no dealer add-ons. "
            f"I'm fine taking a Black interior at that price, or if you can do ${target_beat_otd:,.0f} OTD on your incoming December VIN with nothing added when it comes off the truck, "
            f"I'll put a deposit down today and pick it up within 24 hours of arrival."
        ),
    }


@instrument_tool
def set_dealer_trade_in_gate(
    dealer_id: str,
    private_preview_enabled: bool | None = None,
    otd_locked_in_writing: bool | None = None,
    private_preview_confirmed: bool | None = None,
    otd_locked_confirmed: bool | None = None,
    locked_otd_amount: float = 0.0,
) -> Dict[str, Any]:
    """Updates the Two-Stage Affirmative Trade-In Gates on a dealer lead.

    - Gate #1 (`private_preview_enabled=True` / `private_preview_confirmed=True`): Enables private monthly payment & NJ tax credit preview.
      Outbound dealer messages still enforce the strict Trade-In Secrecy Gag Order.
    - Gate #2 (`otd_locked_in_writing=True` / `otd_locked_confirmed=True`): Confirms OTD is locked in writing (`DEAL_SECURED`),
      unlocking Phase 2 outbound dealer trade-in negotiation for this specific dealer.

    Args:
        dealer_id (str): Dealership ID or name (e.g., `'dlr-raceway-kia-of-freehold'`).
        private_preview_enabled (bool | None): Checkbox #1 state for private trade-in math preview.
        otd_locked_in_writing (bool | None): Checkbox #2 state confirming written OTD buyer's order lock.
        private_preview_confirmed (bool | None): Alias for `private_preview_enabled`.
        otd_locked_confirmed (bool | None): Alias for `otd_locked_in_writing`.
        locked_otd_amount (float): Locked Out-The-Door price in USD when Gate #2 is confirmed. Defaults to 0.0.

    Returns:
        Dict[str, Any]: Updated gate status including `outbound_dealer_gag_active` and `stage`.
    """
    state = load_state()
    if not dealer_id.startswith("dlr-"):
        dealer_id = f"dlr-{_slugify(dealer_id)}"
    all_leads = state.get("dealer_leads", {})
    lead = all_leads.get(dealer_id)
    if not lead:
        lead = ensure_dealer_lead_from_inventory(dealer_id)
    if not lead:
        return build_guided_error(
            error_type="DEALER_NOT_FOUND",
            message=f"Dealer '{dealer_id}' not found in active campaign state.",
            recovery_instructions=(
                "Call `get_negotiation_dashboard()` to inspect valid `dealer_id` values or call "
                "`upsert_dealer_lead(dealer_name=...)` to register the dealership before setting trade-in gates."
            ),
            context={"available_dealer_ids": list(all_leads.keys())},
        )

    eff_preview = (
        bool(private_preview_confirmed)
        if private_preview_confirmed is not None
        else bool(private_preview_enabled if private_preview_enabled is not None else True)
    )
    eff_locked = (
        bool(otd_locked_confirmed)
        if otd_locked_confirmed is not None
        else bool(otd_locked_in_writing if otd_locked_in_writing is not None else False)
    )

    lead["private_trade_preview_enabled"] = eff_preview
    lead["otd_locked_in_writing"] = eff_locked
    if locked_otd_amount > 0:
        lead["locked_otd_amount"] = round(float(locked_otd_amount), 2)
    elif eff_locked and lead.get("otd_total"):
        lead["locked_otd_amount"] = round(float(lead["otd_total"]), 2)

    if eff_locked:
        lead["stage"] = "DEAL_SECURED"
        lead["negotiation_status"] = "DEAL_SECURED"
    elif lead.get("stage") == "DEAL_SECURED":
        lead["stage"] = "QUOTE_AUDITED"
        lead["negotiation_status"] = "QUOTE_AUDITED"

    saved = upsert_document("dealer_leads", dealer_id, lead)
    return {
        "ok": True,
        "dealer_id": dealer_id,
        "private_trade_preview_enabled": saved["private_trade_preview_enabled"],
        "otd_locked_in_writing": saved["otd_locked_in_writing"],
        "locked_otd_amount": saved.get("locked_otd_amount", 0.0),
        "stage": saved["stage"],
        "outbound_dealer_gag_active": not saved["otd_locked_in_writing"],
    }


@instrument_tool
def parse_and_log_dealer_reply(
    dealer_id: str,
    raw_dealer_text: str = "",
    raw_reply_text: str = "",
    reply_text: str = "",
    channel: str = "",
    fallback_otd: float = 0.0,
    fallback_selling_price: float = 0.0,
    auto_draft_counter: bool = True,
    auto_dispatch: bool = False,
) -> Dict[str, Any]:
    """Parses an unstructured dealer SMS/email or worksheet text, records the updated quote in the leaderboard,
    detects whether the dealer initiated accounting jargon ('invoice', 'holdback', 'floorplan', 'money factor'),
    and generates a natural 2-3 sentence buyer counter-offer.

    Args:
        dealer_id (str): Dealership ID or name (e.g., `'dlr-raceway-kia-of-freehold'`).
        raw_dealer_text (str): Unstructured text of the dealer's reply or quote worksheet.
        raw_reply_text (str): Alias for `raw_dealer_text`.
        reply_text (str): Alias for `raw_dealer_text`.
        channel (str): Optional channel identifier ('EMAIL', 'SMS_PERSONAL', 'SMS_TWILIO').
        fallback_otd (float): Optional fallback OTD price if no OTD number is found in text. Defaults to 0.0.
        fallback_selling_price (float): Optional fallback selling price if none is parsed. Defaults to 0.0.
        auto_draft_counter (bool): Whether to automatically queue a counter-offer draft. Defaults to True.
        auto_dispatch (bool): Whether to auto-dispatch the counter-offer (`False` defaults to `PENDING_APPROVAL`).
            Defaults to False.

    Returns:
        Dict[str, Any]: Dictionary containing `dealer_lead`, `financial_audit`, `parsed_extraction`,
        `generated_counter`, `queued_message`, and `natural_counter_script`.
    """
    from .comms_tools import (
        dealer_initiated_accounting_jargon,
        generate_natural_buyer_counter,
        queue_dealer_message,
    )

    eff_text = (raw_reply_text or raw_dealer_text or reply_text or "").strip()
    state = load_state()
    if not dealer_id.startswith("dlr-"):
        dealer_id = f"dlr-{_slugify(dealer_id)}"
    lead = state.get("dealer_leads", {}).get(dealer_id)
    if not lead:
        lead = ensure_dealer_lead_from_inventory(dealer_id)
    if not lead:
        lead = upsert_dealer_lead(
            dealer_name=dealer_id.replace("dlr-", "").replace("-", " ").title()
        )
    state = load_state()

    msrp = float(lead.get("msrp") or 53890.0)
    doc_fee = float(lead.get("doc_fee") or 499.0)
    gov_fees = float(lead.get("gov_fees") or 385.0)
    rebates = float(lead.get("rebates") or 500.0)
    addons_total = float(lead.get("dealer_addons_total") or 0.0)
    mf = float(lead.get("money_factor") or 0.00190)
    rv = float(lead.get("residual_percent") or 62.0)

    text_low = eff_text.lower()
    raw_matches = re.findall(
        r"\$?\s*([0-9]{2},[0-9]{3}(?:\.[0-9]{1,2})?|\b[456][0-9]{4}\b|[1-9],[0-9]{3}|\b[3-9][0-9]{2}\b)",
        eff_text,
    )
    nums = [float(m.replace(",", "")) for m in raw_matches]

    detected_otd = fallback_otd
    detected_selling = fallback_selling_price

    otd_pattern = re.search(
        r"\$?\s*([456][0-9],?[0-9]{3}(?:\.[0-9]{1,2})?)\s*(?:otd|out[-\s]the[-\s]door|all[-\s]in|total)",
        text_low,
    )
    if otd_pattern:
        detected_otd = float(otd_pattern.group(1).replace(",", ""))

    sell_pattern = re.search(
        r"(?:selling\s*price|cap\s*cost|sale\s*price|at)\s*(?:of|is|:)?\s*\$?\s*([456][0-9],?[0-9]{3}(?:\.[0-9]{1,2})?)",
        text_low,
    )
    if sell_pattern:
        detected_selling = float(sell_pattern.group(1).replace(",", ""))

    for val in nums:
        if 46000 <= val <= 68000:
            if detected_otd <= 0 and ("otd" in text_low or "door" in text_low or val >= msrp * 1.005):
                detected_otd = val
            elif detected_selling <= 0:
                detected_selling = val

    if any(p in text_low for p in ["$0 add", "no add-ons", "no addons", "removed the", "waive the", "zero add"]):
        addons_total = 0.0
    else:
        addon_match = re.search(
            r"\$\s*([1-2],?[0-9]{3}|[3-9][0-9]{2})\s*(?:add[-\s]?on|tint|etch|protection|appearance|package|lojack)",
            text_low,
        )
        if addon_match:
            addons_total = float(addon_match.group(1).replace(",", ""))

    doc_match = re.search(
        r"\$\s*([3-9][0-9]{2})\s*(?:doc|documentation)", text_low
    )
    if doc_match:
        doc_fee = float(doc_match.group(1).replace(",", ""))

    mf_match = re.search(r"\b(0\.00[123][0-9]{2})\b", text_low)
    if mf_match:
        mf = float(mf_match.group(1))

    if detected_otd > 0 and detected_selling <= 0:
        rev_calc = calculate_monthly_from_otd(
            otd_price=detected_otd,
            msrp=msrp,
            tax_rate_percent=6.625,
            doc_fee=doc_fee,
            gov_fees=gov_fees,
            rebates=rebates,
        )
        detected_selling = float(
            rev_calc["reverse_otd_breakdown"]["implied_selling_price_cap_cost"]
        ) - addons_total
    elif detected_selling <= 0:
        detected_selling = float(lead.get("selling_price") or round(msrp * 0.962, 0))

    lead["round"] = int(lead.get("round") or 0) + 1
    upsert_document("dealer_leads", dealer_id, lead)

    recorded = record_dealer_quote(
        dealer_id=dealer_id,
        selling_price=detected_selling,
        dealer_quoted_otd=detected_otd,
        money_factor=mf,
        residual_percent=rv,
        dealer_addons_total=addons_total,
        doc_fee=doc_fee,
        gov_fees=gov_fees,
        rebates=rebates,
        raw_dealer_message=eff_text,
    )
    updated_lead = recorded["dealer_lead"]
    best_comp = get_best_competing_offer()
    best_otd = float(best_comp.get("best_otd_total") or updated_lead.get("otd_total") or 55303.0)

    stretch_otd = float(updated_lead.get("recommended_counter_otd") or round(msrp * 1.0055, 0))
    target_counter_otd = round(min(stretch_otd, best_otd - 350.0), 0)
    target_counter_selling = float(
        updated_lead.get("recommended_counter_selling_price") or round(msrp * 0.95, 0)
    )

    jargon_detected = dealer_initiated_accounting_jargon(eff_text)
    counter_gen = generate_natural_buyer_counter(
        dealer_lead=updated_lead,
        target_otd=target_counter_otd,
        target_selling_price=target_counter_selling,
        competing_best_otd=best_otd,
        competing_discount_pct=float(best_comp.get("best_discount_pct") or 4.5),
        round_number=int(updated_lead.get("round") or 2),
        dealer_objection_text=eff_text,
    )

    queued_msg = None
    if auto_draft_counter:
        queued_msg = queue_dealer_message(
            dealer_id=dealer_id,
            body=counter_gen["script"],
            channel=updated_lead.get("preferred_channel", "SMS_PERSONAL"),
            auto_dispatch=auto_dispatch,
        )

    return {
        "ok": True,
        "dealer_lead": updated_lead,
        "financial_audit": recorded["financial_audit"],
        "dealer_initiated_accounting_jargon": jargon_detected,
        "parsed_extraction": {
            "jargon_detected": jargon_detected,
            "selling_price": updated_lead.get("selling_price"),
            "otd_total": updated_lead.get("otd_total"),
            "dealer_addons_total": updated_lead.get("dealer_addons_total"),
            "doc_fee": updated_lead.get("doc_fee"),
            "money_factor": updated_lead.get("money_factor"),
        },
        "generated_counter": counter_gen,
        "queued_message": queued_msg,
        "recommended_counter_otd": target_counter_otd,
        "natural_counter_script": counter_gen["script"],
        "counter_tone_mode": counter_gen["tone_mode"],
        "objection_handled": counter_gen["objection_handled"],
    }


@instrument_tool
def run_autonomous_multi_dealer_negotiation(
    dealer_ids: List[str] | None = None,
    max_rounds: int = 3,
    autonomy_mode: str = "COPILOT",
    auto_simulate_replies: bool = True,
) -> Dict[str, Any]:
    """Runs an automated multi-round kickoff and 'Beat-It' back-and-forth negotiation loop across up to 3 selected vehicles.

    Features:
    - Accommodates different trims side-by-side (e.g. SX X-Line vs SX Prestige vs SX Prestige X-Line)
      by normalizing leverage via % Off Specific Trim MSRP and Color-Parity OTD.
    - Follows Zero-Buzzword Default in Round 1/2 outreach and automatically switches to Reactive Insider Mirror
      if a dealer brings up invoice/holdback/floorplan/money factor.
    - Enforces IN-TRANSIT December delivery lock and strict Trade-In / Lease-Expiry Secrecy.
    - Enforces Human-in-the-Loop confirmation (`COPILOT` -> `PENDING_APPROVAL`) by default unless
      `autonomy_mode` is explicitly set to `'FULL_AUTOPILOT'` or `'SEMI_AUTO'`.

    Args:
        dealer_ids (List[str] | None): Optional list of up to 3 dealer IDs to include in the bidding war.
            Defaults to the top 3 ranked dealers when None.
        max_rounds (int): Maximum number of negotiation rounds to execute (1-3). Defaults to 3.
        autonomy_mode (str): Execution autonomy level (`'COPILOT'`, `'SEMI_AUTO'`, or `'FULL_AUTOPILOT'`).
            Defaults to `'COPILOT'`.
        auto_simulate_replies (bool): Whether to simulate dealer responses in autopilot mode. Defaults to True.

    Returns:
        Dict[str, Any]: Multi-round negotiation summary containing `round_by_round_log`,
        `side_by_side_comparison`, `winning_recommendation`, and `next_step_banner`.
    """
    from .comms_tools import generate_natural_buyer_counter, queue_dealer_message

    state = load_state()
    all_leads = state.get("dealer_leads", {})
    if not dealer_ids:
        ranked = get_negotiation_dashboard().get("dealers_ranked", [])
        dealer_ids = [d["id"] for d in ranked[:3]]
    else:
        dealer_ids = [
            (d if d.startswith("dlr-") else f"dlr-{_slugify(d)}")
            for d in dealer_ids[:3]
        ]

    for cand_id in dealer_ids:
        if cand_id not in all_leads:
            ensured = ensure_dealer_lead_from_inventory(cand_id)
            if ensured:
                all_leads = load_state().get("dealer_leads", {})

    selected_ids = [d_id for d_id in dealer_ids if d_id in all_leads]
    if not selected_ids:
        return build_guided_error(
            error_type="NO_VALID_DEALER_IDS",
            message="No valid dealer IDs selected for auto-negotiation.",
            recovery_instructions=(
                "Call `get_negotiation_dashboard()` to list valid `dealer_id` keys or call "
                "`seed_telluride_campaign()` / `scrape_monmouth_ocean_kia_inventory()` first to populate NJ dealers."
            ),
            context={
                "requested_dealer_ids": dealer_ids,
                "available_dealer_ids": list(all_leads.keys()),
            },
        )

    starting_otd_map: Dict[str, float] = {}
    tone_modes_by_dealer: Dict[str, List[str]] = {}
    for d_id in selected_ids:
        d_init = all_leads.get(d_id, {})
        starting_otd_map[d_id] = float(
            d_init.get("opening_otd") or d_init.get("otd_total") or 55303.11
        )
        tone_modes_by_dealer[d_id] = []

    mode_norm = (autonomy_mode or "COPILOT").strip().upper()
    confirmation_gate = require_human_confirmation_hook(
        action_name="run_autonomous_multi_dealer_negotiation",
        action_payload={"dealer_ids": selected_ids, "max_rounds": max_rounds},
        autonomy_mode=mode_norm,
        explicit_auto_dispatch=(mode_norm in ("FULL_AUTOPILOT", "SEMI_AUTO")),
    )
    auto_send = bool(confirmation_gate["approved"]) and bool(auto_simulate_replies)
    rounds_to_run = max(1, min(int(max_rounds or 2), 3))

    camp_id = state.get("active_campaign_id") or "camp-2027-kia-telluride-hybrid-nj"
    campaign = state.get("campaigns", {}).get(camp_id, {})
    campaign["autonomy_mode"] = mode_norm
    upsert_document("negotiation_campaigns", camp_id, campaign)
    buyer_name = campaign.get("buyer_name", "Alex")

    round_logs: List[Dict[str, Any]] = []

    for r_idx in range(1, rounds_to_run + 1):
        best_comp = get_best_competing_offer()
        best_otd = float(best_comp.get("best_otd_total") or 55303.0)
        best_disc_pct = float(best_comp.get("best_discount_pct") or 3.8)

        for d_id in selected_ids:
            lead = load_state().get("dealer_leads", {}).get(d_id, {})
            if not lead:
                continue

            lead_round = int(lead.get("round") or 0) + 1
            msrp = float(lead.get("msrp") or 53890.0)
            stretch_pct = float(lead.get("stretch_target_discount_pct") or 5.0)
            target_disc_pct = min(stretch_pct + 0.3, max(stretch_pct, best_disc_pct + 0.5))
            target_selling = round(msrp * (1.0 - target_disc_pct / 100.0), 0)
            target_otd = round(
                (target_selling + 499.0 - float(lead.get("rebates") or 500.0)) * 1.06625 + 385.0,
                0,
            )

            gen = generate_natural_buyer_counter(
                dealer_lead=lead,
                target_otd=target_otd,
                target_selling_price=target_selling,
                competing_best_otd=best_otd,
                competing_discount_pct=best_disc_pct,
                buyer_name=buyer_name,
                round_number=lead_round,
                dealer_objection_text=str(lead.get("last_dealer_message") or ""),
            )
            if gen["tone_mode"] not in tone_modes_by_dealer[d_id]:
                tone_modes_by_dealer[d_id].append(gen["tone_mode"])

            otd_before = float(lead.get("otd_total") or 0.0)
            msg_res = queue_dealer_message(
                dealer_id=d_id,
                body=gen["script"],
                channel=lead.get("preferred_channel", "SMS_PERSONAL"),
                auto_dispatch=auto_send,
            )

            updated_lead = load_state().get("dealer_leads", {}).get(d_id, lead)
            otd_after = float(updated_lead.get("otd_total") or otd_before)
            round_logs.append(
                {
                    "step_round": r_idx,
                    "dealer_id": d_id,
                    "dealer_name": updated_lead.get("dealer_name"),
                    "trim_level": updated_lead.get("trim_level"),
                    "vin": updated_lead.get("vin"),
                    "interior_color": updated_lead.get("interior_color"),
                    "tone_mode": gen["tone_mode"],
                    "dealer_initiated_jargon": gen["dealer_initiated_jargon"],
                    "outbound_message": gen["script"],
                    "dispatched_automatically": auto_send,
                    "otd_before": round(otd_before, 2),
                    "otd_after": round(otd_after, 2),
                    "round_savings": max(0.0, round(otd_before - otd_after, 2))
                    if otd_before > 0
                    else 0.0,
                    "discount_pct_after": updated_lead.get("discount_pct", 0.0),
                    "dealer_reply_preview": str(
                        updated_lead.get("last_dealer_message") or ""
                    )[:220],
                    "message_status": msg_res.get("status"),
                }
            )

            if (
                mode_norm == "SEMI_AUTO"
                and float(updated_lead.get("discount_pct") or 0.0) >= stretch_pct
                and float(updated_lead.get("dealer_addons_total") or 0.0) == 0.0
            ):
                break

        if not auto_send:
            break

    final_state = load_state()
    compared_vehicles = []
    dealer_run_summaries = []
    for d_id in selected_ids:
        d = final_state.get("dealer_leads", {}).get(d_id)
        if not d:
            continue
        start_otd = starting_otd_map.get(d_id, float(d.get("opening_otd") or d.get("otd_total") or 0.0))
        end_otd = float(d.get("otd_total") or start_otd)
        saved_otd = max(0.0, round(start_otd - end_otd, 2))
        ready_lock = (
            float(d.get("discount_pct", 0.0)) >= 4.5
            and float(d.get("dealer_addons_total", 0.0)) == 0.0
        )
        neg_status = "DEAL_SECURED" if (ready_lock or d.get("otd_locked_in_writing")) else "COUNTER_SENT"
        d["negotiation_status"] = neg_status
        upsert_document("dealer_leads", d_id, d)

        summary_obj = {
            "dealer_id": d["id"],
            "dealer_name": d.get("dealer_name"),
            "trim_level": d.get("trim_level"),
            "vin": d.get("vin"),
            "interior_color": d.get("interior_color"),
            "is_non_black_interior": d.get("is_non_black_interior", True),
            "inventory_status": d.get("inventory_status", "IN_TRANSIT"),
            "eta_delivery": d.get("eta_delivery", "Late Dec 2026"),
            "msrp": d.get("msrp"),
            "selling_price": d.get("selling_price"),
            "discount_pct": d.get("discount_pct"),
            "starting_otd": round(start_otd, 2),
            "opening_otd": round(start_otd, 2),
            "ending_otd": round(end_otd, 2),
            "otd_total": round(end_otd, 2),
            "total_otd_saved": saved_otd,
            "total_otd_savings": saved_otd,
            "dealer_addons_total": d.get("dealer_addons_total", 0.0),
            "implied_finance_60mo": d.get("implied_finance_60mo"),
            "implied_lease_36mo": d.get("implied_lease_36mo"),
            "rounds_completed": d.get("round", 1),
            "negotiation_status": neg_status,
            "tone_modes_used": " → ".join(tone_modes_by_dealer.get(d_id) or ["ZERO_BUZZWORD_NATURAL"]),
            "ready_for_deposit_lock": ready_lock,
        }
        compared_vehicles.append(summary_obj)
        dealer_run_summaries.append(summary_obj)

    compared_vehicles.sort(
        key=lambda x: (-float(x.get("discount_pct") or 0.0), float(x.get("otd_total") or 999999))
    )
    winner = compared_vehicles[0] if compared_vehicles else {}
    best_offer_after = get_best_competing_offer()

    return {
        "ok": True,
        "autonomy_mode": mode_norm,
        "human_confirmation_gate": confirmation_gate,
        "selected_dealer_ids": selected_ids,
        "vehicles_selected_count": len(selected_ids),
        "rounds_executed": rounds_to_run if auto_send else 1,
        "round_by_round_log": round_logs,
        "dealer_run_summaries": dealer_run_summaries,
        "side_by_side_comparison": compared_vehicles,
        "best_offer_after_run": best_offer_after,
        "winning_recommendation": winner,
        "next_step_banner": (
            f"✅ Auto-Negotiation Complete ({mode_norm}): {winner.get('dealer_name', 'Top Dealer')} leads at "
            f"${float(winner.get('otd_total') or 0):,.2f} OTD ({winner.get('discount_pct', 0)}% off MSRP, $0 add-ons) "
            f"on IN-TRANSIT VIN {winner.get('vin', '')} for December delivery. Ready to lock OTD in writing or preview Trade-In (Checkbox #1)."
            if auto_send
            else "✋ Copilot Mode: Outbound counter-offers have been queued in PENDING_APPROVAL for your review."
        ),
    }


def _normalize_dealer_group_name(raw_name: str) -> str:
    """Normalizes a dealership name to its canonical franchise name without parenthetical VIN/trim suffixes.

    Args:
        raw_name (str): Raw dealership name string.

    Returns:
        str: Canonical dealership name.
    """
    low = (raw_name or "").lower()
    if "raceway" in low:
        return "Raceway Kia of Freehold"
    if "sansone" in low or "66" in low:
        return "Sansone Jr's 66 Automall Kia"
    if "matt blatt" in low:
        return "Matt Blatt Kia of Toms River"
    if "difeo" in low:
        return "DiFeo Kia of Lakewood"
    if "manahawkin" in low:
        return "Manahawkin Kia"
    return re.sub(r"\s*\([^)]*\)\s*$", "", str(raw_name or "").strip()) or "Monmouth County Kia"


def ensure_dealer_lead_from_inventory(dealer_id_or_vin: str) -> Dict[str, Any] | None:
    """Materializes a vehicle from `VERIFIED_LIVE_DEALERON_VEHICLES` into `dealer_leads` if not already present.

    Args:
        dealer_id_or_vin (str): Dealer vehicle ID or 17-character VIN.

    Returns:
        Dict[str, Any] | None: Persisted dealer lead dictionary if matched in verified inventory, else None.
    """
    from .inventory_scraper import MONMOUTH_OCEAN_KIA_DEALERS, VERIFIED_LIVE_DEALERON_VEHICLES

    state = load_state()
    existing_leads = state.get("dealer_leads", {})
    if dealer_id_or_vin in existing_leads:
        return existing_leads[dealer_id_or_vin]

    target = None
    for snap in VERIFIED_LIVE_DEALERON_VEHICLES:
        if snap.get("dealer_id") == dealer_id_or_vin or snap.get("vin") == dealer_id_or_vin:
            target = snap
            break
    if not target:
        return None

    base_name = _normalize_dealer_group_name(target.get("dealer_name", "Raceway Kia of Freehold"))
    dealer_meta = next(
        (d for d in MONMOUTH_OCEAN_KIA_DEALERS if d["dealer_name"] == base_name),
        MONMOUTH_OCEAN_KIA_DEALERS[0],
    )
    vin = str(target.get("vin") or "5XYPDESA8VG041820")
    msrp = float(target.get("msrp") or 56890.0)
    selling = float(target.get("selling_price") or round(msrp * 0.962, 0))
    doc_fee = float(target.get("doc_fee") or dealer_meta["doc_fee"])
    rebates = float(target.get("rebates") or 500.0)
    status = str(target.get("inventory_status") or "ON_LOT").upper()
    eta = str(target.get("eta_delivery") or ("Late Dec 2026" if status == "IN_TRANSIT" else "On Lot Now"))
    trim = str(target.get("trim_level") or "2027 Kia Telluride Hybrid SX X-Line")

    lead_id = str(target.get("dealer_id") or f"dlr-{_slugify(base_name)}-{vin[-6:].lower()}")
    lead = upsert_dealer_lead(
        dealer_name=lead_id.replace("dlr-", ""),
        city=str(target.get("city") or dealer_meta["city"]),
        county=str(target.get("county") or dealer_meta["county"]),
        state="NJ",
        contact_phone=dealer_meta["phone"],
        vin=vin,
        stock_number=str(target.get("stock_number") or f"KIA-{vin[-6:]}"),
        trim_level=trim,
        exterior_color=str(target.get("exterior_color") or "Wolf Gray"),
        interior_color=str(target.get("interior_color") or "Terracotta Brown Leather"),
        msrp=msrp,
        persona=dealer_meta["persona"],
        inventory_status=status,
        eta_delivery=eta,
    )
    lead["id"] = lead_id
    lead["dealer_name"] = base_name
    lead["base_dealer_name"] = base_name
    lead["base_dealer_id"] = str(target.get("base_dealer_id") or dealer_meta["dealer_id"])
    lead["data_source"] = str(target.get("data_source") or "LIVE_DEALER_SITE")
    lead["source_url"] = str(target.get("source_url") or dealer_meta["inventory_urls"][0])
    upsert_document("dealer_leads", lead_id, lead)

    rec = record_dealer_quote(
        dealer_id=lead_id,
        selling_price=selling,
        doc_fee=doc_fee,
        gov_fees=385.0,
        rebates=rebates,
        raw_dealer_message=(
            f"[Dealer Inventory Quote] {base_name} — {trim} (VIN {vin}, Stock #{target.get('stock_number')}, "
            f"MSRP ${msrp:,.0f}, Selling ${selling:,.0f}, Doc Fee ${doc_fee:,.0f})"
        ),
    )
    rec_lead = rec["dealer_lead"]
    rec_lead["dealer_name"] = base_name
    rec_lead["base_dealer_name"] = base_name
    rec_lead["base_dealer_id"] = str(target.get("base_dealer_id") or dealer_meta["dealer_id"])
    rec_lead["data_source"] = str(target.get("data_source") or "LIVE_DEALER_SITE")
    rec_lead["source_url"] = str(target.get("source_url") or dealer_meta["inventory_urls"][0])
    return upsert_document("dealer_leads", lead_id, rec_lead)


def build_enriched_dealer_inventory(
    state: Dict[str, Any] | None = None,
    filter_dealer: str = "",
    filter_trim: str = "",
    filter_interior: str = "",
    filter_status: str = "",
    sort_by: str = "otd_asc",
) -> List[Dict[str, Any]]:
    """Builds the complete enriched dealer inventory list across all 5 Monmouth & Ocean County Kia dealerships,
    combining active campaign leads and verified dealer inventory with optional dealer/trim/interior/status filtering and sorting.

    Args:
        state (Dict[str, Any] | None): Optional loaded state dictionary.
        filter_dealer (str): Optional dealer name or ID filter (e.g., `'Raceway Kia of Freehold'`).
        filter_trim (str): Optional trim level filter (e.g., `'2027 Kia Telluride Hybrid SX X-Line'`).
        filter_interior (str): Optional interior filter (`'ALL'`, `'NON_BLACK'`, or `'BLACK'`).
        filter_status (str): Optional lot status filter (`'ALL'`, `'IN_TRANSIT'`, or `'ON_LOT'`).
        sort_by (str): Sort key (`'deal_score_asc'`, `'otd_asc'`, `'otd_desc'`, `'discount_desc'`, `'trim_asc'`,
            `'trim_desc'`, `'dealer_asc'`, `'dealer_desc'`, `'lease_asc'`, `'msrp_asc'`, `'msrp_desc'`,
            `'status_in_transit'`, `'status_on_lot'`, `'priority_non_black'`).

    Returns:
        List[Dict[str, Any]]: Enriched, filtered, and sorted list of dealer inventory vehicles.
    """
    from .inventory_scraper import MONMOUTH_OCEAN_KIA_DEALERS, VERIFIED_LIVE_DEALERON_VEHICLES

    if state is None:
        state = load_state()

    inventory_by_vin: Dict[str, Dict[str, Any]] = {}
    active_leads = list(state.get("dealer_leads", {}).values())

    for d in active_leads:
        if d.get("state", "NJ") != "NJ" or not d.get("is_hybrid", True):
            continue
        item = dict(d)
        base_name = _normalize_dealer_group_name(item.get("base_dealer_name") or item.get("dealer_name", ""))
        dealer_meta = next(
            (m for m in MONMOUTH_OCEAN_KIA_DEALERS if m["dealer_name"] == base_name),
            MONMOUTH_OCEAN_KIA_DEALERS[0],
        )
        item["base_dealer_name"] = base_name
        item["dealer_name"] = base_name
        item["display_name"] = dealer_meta.get("display_name") or base_name
        item["quirk_note"] = dealer_meta.get("quirk_note", "")
        item["bidding_strategy"] = dealer_meta.get("bidding_strategy", "")
        item["trim_priority_rank"] = get_trim_priority_rank(item.get("trim_level", ""))
        item["in_active_campaign"] = True
        if "true_deal_score" not in item:
            msrp_v = float(item.get("msrp") or 56035.0)
            sell_v = float(item.get("selling_price") or msrp_v)
            doc_v = float(item.get("doc_fee") or dealer_meta.get("doc_fee", 749.0))
            addons_v = float(item.get("dealer_addons_total") or 0.0)
            nj_pay = calculate_nj_payments(
                msrp=msrp_v,
                selling_price=sell_v,
                doc_fee=doc_v,
                mandatory_addons=addons_v,
                rebates=float(item.get("rebates") or 750.0),
                cash_down=3000.0,
                target_monthly_budget=750.0,
            )
            item["true_deal_score"] = nj_pay["true_deal_score"]
            item["pure_dealer_discount"] = nj_pay["pure_dealer_discount"]
            item["purchase_otd"] = nj_pay["purchase_otd"]
            item["loan_monthly_60mo"] = nj_pay["loan_monthly_60mo"]
            item["loan_monthly_60mo_zero_down"] = nj_pay["loan_monthly_60mo_zero_down"]
            item["lease_monthly_36mo"] = nj_pay["lease_monthly_36mo"]
            item["lease_monthly_36mo_sign_and_drive"] = nj_pay["lease_monthly_36mo_sign_and_drive"]
            item["extra_discount_to_hit_lease_budget"] = nj_pay["extra_discount_to_hit_lease_budget"]
            item["nj_payments_breakdown"] = nj_pay
        vin_key = str(item.get("vin") or item.get("id"))
        inventory_by_vin[vin_key] = item

    for snap in VERIFIED_LIVE_DEALERON_VEHICLES:
        vin_key = str(snap.get("vin") or "")
        if not vin_key or vin_key in inventory_by_vin:
            continue

        base_name = _normalize_dealer_group_name(snap.get("dealer_name", "Raceway Kia of Freehold"))
        dealer_meta = next(
            (m for m in MONMOUTH_OCEAN_KIA_DEALERS if m["dealer_name"] == base_name),
            MONMOUTH_OCEAN_KIA_DEALERS[0],
        )
        msrp = float(snap.get("msrp") or 56035.0)
        selling = float(snap.get("selling_price") or round(msrp * 0.962, 0))
        doc_fee = float(snap.get("doc_fee") or dealer_meta["doc_fee"])
        gov_fees = 400.0
        rebates = float(snap.get("rebates") or 750.0)
        addons = float(snap.get("dealer_addons_total") or dealer_meta.get("mandatory_addons_avg", 0.0))
        discount_off = round(msrp - selling, 2)
        discount_pct = round((discount_off / msrp) * 100.0, 2) if msrp > 0 else 0.0
        invoice_price = round(msrp * 0.962, 2)
        vs_invoice = round(selling - invoice_price, 2)

        nj_pay = calculate_nj_payments(
            msrp=msrp,
            selling_price=selling,
            doc_fee=doc_fee,
            mandatory_addons=addons,
            rebates=rebates,
            cash_down=3000.0,
            target_monthly_budget=750.0,
            mv_tire_fees=gov_fees,
        )
        otd_total = nj_pay["purchase_otd"]

        interior_color = str(snap.get("interior_color") or "Saddle Brown & Millstone (Priority Non-Black)")
        is_non_black = bool(
            snap.get(
                "is_priority_non_black",
                "all-black" not in interior_color.lower()
                and not (
                    interior_color.lower().startswith("black")
                    and "millstone" not in interior_color.lower()
                ),
            )
        )
        otd_color_delta = 314.54 if is_non_black else 0.0
        color_parity_otd = round(otd_total - otd_color_delta, 2)

        rev = calculate_monthly_from_otd(
            otd_price=otd_total,
            msrp=msrp,
            tax_rate_percent=6.625,
            doc_fee=doc_fee,
            gov_fees=gov_fees,
            rebates=rebates,
            loan_apr_percent=4.49,
            loan_term_months=60,
            lease_term_months=36,
            lease_annual_miles=12000,
            residual_percent=62.0,
            money_factor=0.00245,
        )
        rec_selling = round(msrp * 0.95, 0)
        rec_otd = round((rec_selling + doc_fee - rebates) * 1.06625 + gov_fees, 2)
        trim_level = str(snap.get("trim_level") or "2027 Kia Telluride Hybrid SX X-Line")
        trim_rank = get_trim_priority_rank(trim_level)
        status = str(snap.get("inventory_status") or "ON_LOT").upper()
        eta = str(snap.get("eta_delivery") or ("Late Dec 2026" if status == "IN_TRANSIT" else "On Lot Now"))
        city = str(snap.get("city") or dealer_meta["city"])
        county = str(snap.get("county") or dealer_meta["county"])
        lead_id = str(snap.get("dealer_id") or f"dlr-{_slugify(base_name)}-{vin_key[-6:].lower()}")

        inventory_by_vin[vin_key] = {
            "id": lead_id,
            "dealer_id": lead_id,
            "base_dealer_id": str(snap.get("base_dealer_id") or dealer_meta["dealer_id"]),
            "dealer_name": base_name,
            "base_dealer_name": base_name,
            "display_name": dealer_meta.get("display_name") or base_name,
            "quirk_note": dealer_meta.get("quirk_note", ""),
            "bidding_strategy": dealer_meta.get("bidding_strategy", ""),
            "city": city,
            "county": county,
            "state": "NJ",
            "county_priority_tier": 1,
            "location_label": f"{city}, {county}",
            "contact_name": "Internet Sales Manager",
            "contact_email": f"sales@{_slugify(base_name)}.example.com",
            "contact_phone": dealer_meta["phone"],
            "preferred_channel": "SMS_PERSONAL",
            "vin": vin_key,
            "stock_number": str(snap.get("stock_number") or vin_key[-8:]),
            "trim_level": trim_level,
            "trim_priority_rank": trim_rank,
            "is_hybrid": True,
            "exterior_color": str(snap.get("exterior_color") or "Wolf Gray"),
            "interior_color": interior_color,
            "is_non_black_interior": is_non_black,
            "is_priority_non_black": is_non_black,
            "msrp": msrp,
            "selling_price": selling,
            "invoice_price": invoice_price,
            "price_vs_trim_invoice": vs_invoice,
            "vs_prevailing_market_dollars": vs_invoice,
            "discount_off_msrp": discount_off,
            "discount_pct": discount_pct,
            "discount_off_msrp_pct": discount_pct,
            "otd_total": otd_total,
            "purchase_otd": otd_total,
            "opening_otd": otd_total,
            "total_otd_savings": 0.0,
            "color_parity_otd": color_parity_otd,
            "otd_color_delta": otd_color_delta,
            "doc_fee": doc_fee,
            "gov_fees": gov_fees,
            "rebates": rebates,
            "dealer_addons_total": addons,
            "addon_descriptions": "",
            "money_factor": 0.00245,
            "residual_percent": 62.0,
            "true_deal_score": nj_pay["true_deal_score"],
            "pure_dealer_discount": nj_pay["pure_dealer_discount"],
            "loan_monthly_60mo": nj_pay["loan_monthly_60mo"],
            "loan_monthly_60mo_zero_down": nj_pay["loan_monthly_60mo_zero_down"],
            "lease_monthly_36mo": nj_pay["lease_monthly_36mo"],
            "lease_monthly_36mo_sign_and_drive": nj_pay["lease_monthly_36mo_sign_and_drive"],
            "extra_discount_to_hit_lease_budget": nj_pay["extra_discount_to_hit_lease_budget"],
            "nj_payments_breakdown": nj_pay,
            "monthly_payment": nj_pay["lease_monthly_36mo"],
            "drive_off": 3000.0,
            "implied_finance_60mo": rev["finance_purchase_from_otd"]["monthly_60mo"],
            "finance_monthly_60m": rev["finance_purchase_from_otd"]["monthly_60mo"],
            "implied_finance_72mo": rev["finance_purchase_from_otd"]["monthly_72mo"],
            "implied_lease_36mo": rev["lease_from_otd_cap_cost"]["monthly_lease_payment_with_fees_upfront"],
            "lease_monthly_36m": rev["lease_from_otd_cap_cost"]["monthly_lease_payment_with_fees_upfront"],
            "implied_sign_and_drive_lease_36mo": rev["lease_from_otd_cap_cost"]["sign_and_drive_zero_due_monthly"],
            "recommended_counter_selling_price": rec_selling,
            "recommended_counter_otd": rec_otd,
            "inventory_status": status,
            "stock_status": status,
            "eta_delivery": eta,
            "stage": "INVENTORY_AVAILABLE",
            "negotiation_status": "AVAILABLE",
            "deflection_strikes": 0,
            "active_operating_mode": "MODE_1_INITIAL_OUTREACH",
            "negotiation_stage": "STAGE_2_LOT_RAID" if status == "ON_LOT" else "STAGE_1_RESERVE",
            "round": 1,
            "round_Number": 1,
            "red_flags": nj_pay.get("forensic_flags", []),
            "source_url": str(snap.get("source_url") or dealer_meta["inventory_urls"][0]),
            "data_source": str(snap.get("data_source") or "LIVE_DEALER_SITE"),
            "in_active_campaign": False,
        }

    items = list(inventory_by_vin.values())

    # Apply optional dealer filter
    if filter_dealer and filter_dealer.strip().upper() not in ("ALL", "ALL_DEALERS", ""):
        f_dlr = filter_dealer.strip().lower()
        items = [
            v
            for v in items
            if f_dlr in str(v.get("base_dealer_name") or v.get("dealer_name", "")).lower()
            or f_dlr in str(v.get("display_name", "")).lower()
            or f_dlr == str(v.get("base_dealer_id") or v.get("id", "")).lower()
        ]

    # Apply optional trim filter
    if filter_trim and filter_trim.strip().upper() not in ("ALL", "ALL_TRIMS", ""):
        f_trim = filter_trim.strip().lower()
        items = [
            v
            for v in items
            if f_trim == str(v.get("trim_level", "")).lower()
            or (f_trim == "sx x-line" and v.get("trim_priority_rank") == 1)
            or (f_trim == "sx prestige" and v.get("trim_priority_rank") == 2)
            or (f_trim == "sx prestige x-line" and v.get("trim_priority_rank") == 3)
        ]

    # Apply optional interior filter (ALL / NON_BLACK / BLACK)
    if filter_interior and filter_interior.strip().upper() not in ("ALL", "ALL_INTERIORS", ""):
        f_int = filter_interior.strip().upper()
        if f_int in ("NON_BLACK", "PRIORITY", "PRIORITY_NON_BLACK"):
            items = [v for v in items if bool(v.get("is_non_black_interior", True))]
        elif f_int in ("BLACK", "ALL_BLACK"):
            items = [v for v in items if not bool(v.get("is_non_black_interior", True))]

    # Apply optional lot status filter (ALL / IN_TRANSIT / ON_LOT)
    if filter_status and filter_status.strip().upper() not in ("ALL", "ALL_STATUS", ""):
        f_stat = filter_status.strip().upper()
        items = [v for v in items if str(v.get("inventory_status", "")).upper() == f_stat]

    # Apply sorting
    s_key = (sort_by or "otd_asc").strip().lower()
    if s_key == "deal_score_asc":
        items.sort(
            key=lambda v: (
                float(v.get("true_deal_score") or 999999),
                0 if v.get("is_non_black_interior", True) else 1,
                float(v.get("otd_total") or 999999),
            )
        )
    elif s_key == "priority_non_black":
        items.sort(
            key=lambda v: (
                0 if v.get("is_non_black_interior", True) else 1,
                float(v.get("true_deal_score") or 999999),
                float(v.get("otd_total") or 999999),
            )
        )
    elif s_key == "otd_desc":
        items.sort(key=lambda v: -(float(v.get("otd_total") or 0)))
    elif s_key == "discount_desc":
        items.sort(key=lambda v: (-float(v.get("discount_pct") or 0), float(v.get("otd_total") or 999999)))
    elif s_key == "trim_asc":
        items.sort(key=lambda v: (int(v.get("trim_priority_rank") or 9), float(v.get("otd_total") or 999999)))
    elif s_key == "trim_desc":
        items.sort(key=lambda v: (-int(v.get("trim_priority_rank") or 0), float(v.get("otd_total") or 999999)))
    elif s_key == "dealer_asc":
        items.sort(
            key=lambda v: (
                str(v.get("base_dealer_name") or v.get("dealer_name", "")).lower(),
                int(v.get("trim_priority_rank") or 9),
                float(v.get("otd_total") or 999999),
            )
        )
    elif s_key == "dealer_desc":
        items.sort(
            key=lambda v: (
                str(v.get("base_dealer_name") or v.get("dealer_name", "")).lower(),
                -int(v.get("trim_priority_rank") or 0),
            ),
            reverse=True,
        )
    elif s_key == "lease_asc":
        items.sort(key=lambda v: float(v.get("lease_monthly_36mo") or v.get("implied_lease_36mo") or 99999))
    elif s_key == "msrp_asc":
        items.sort(key=lambda v: float(v.get("msrp") or 999999))
    elif s_key == "msrp_desc":
        items.sort(key=lambda v: -float(v.get("msrp") or 0))
    elif s_key == "status_in_transit":
        items.sort(
            key=lambda v: (
                0 if str(v.get("inventory_status", "")).upper() == "IN_TRANSIT" else 1,
                float(v.get("true_deal_score") or 999999),
                float(v.get("otd_total") or 999999),
            )
        )
    elif s_key == "status_on_lot":
        items.sort(
            key=lambda v: (
                0 if str(v.get("inventory_status", "")).upper() == "ON_LOT" else 1,
                float(v.get("true_deal_score") or 999999),
                float(v.get("otd_total") or 999999),
            )
        )
    else:
        # Default: otd_asc
        items.sort(
            key=lambda v: (
                float(v.get("otd_total") or 999999),
                int(v.get("trim_priority_rank") or 9),
            )
        )

    return items


@instrument_tool
def get_negotiation_dashboard() -> Dict[str, Any]:
    """Returns a complete snapshot of the active campaign, ranked NJ dealer quotes, 5-dealer tracker, full dealer inventory, and Copilot approval queue.

    Returns:
        Dict[str, Any]: Dashboard state snapshot containing `campaign`, `market_benchmark`, `dealers_ranked`,
        `five_dealer_tracker`, `dealer_inventory`, `inventory_summary`, `pending_approvals_count`,
        `queued_stealth_count`, `pending_approvals`, `queued_stealth_messages`, and `recent_messages`.
    """
    from .inventory_scraper import MONMOUTH_OCEAN_KIA_DEALERS

    state = load_state()
    camp_id = state.get("active_campaign_id")
    campaign = state.get("campaigns", {}).get(camp_id, {})
    deal_type = campaign.get("deal_type", "PURCHASE")

    dealers = list(state.get("dealer_leads", {}).values())
    if deal_type == "LEASE":
        dealers.sort(
            key=lambda d: (
                0 if d.get("monthly_payment", 0) > 0 else 1,
                d.get("county_priority_tier", 1),
                d.get("trim_priority_rank", 1),
                d.get("effective_monthly_cost") or d.get("monthly_payment") or 99999,
            )
        )
    else:
        dealers.sort(
            key=lambda d: (
                0 if d.get("otd_total", 0) > 0 else 1,
                d.get("county_priority_tier", 1),
                d.get("trim_priority_rank", 1),
                d.get("otd_total") or 999999,
            )
        )

    dealer_inventory = build_enriched_dealer_inventory(state)
    counts_by_dealer: Dict[str, int] = {}
    counts_by_trim: Dict[str, int] = {}
    counts_by_interior = {"priority_non_black": 0, "all_black": 0}
    counts_by_status = {"IN_TRANSIT": 0, "ON_LOT": 0}

    for item in dealer_inventory:
        d_name = str(item.get("base_dealer_name") or item.get("dealer_name") or "Other Dealer")
        t_name = str(item.get("trim_level") or "2027 Kia Telluride Hybrid SX X-Line")
        counts_by_dealer[d_name] = counts_by_dealer.get(d_name, 0) + 1
        counts_by_trim[t_name] = counts_by_trim.get(t_name, 0) + 1
        if item.get("is_non_black_interior", True):
            counts_by_interior["priority_non_black"] += 1
        else:
            counts_by_interior["all_black"] += 1
        stat_key = str(item.get("inventory_status", "IN_TRANSIT")).upper()
        counts_by_status[stat_key] = counts_by_status.get(stat_key, 0) + 1

    # Build the 5-Dealer Monmouth & Ocean County Tracker (Matt Blatt, Raceway, DiFeo, Manahawkin, Sansone Jr's [Neptune & Keyport])
    five_dealer_tracker: List[Dict[str, Any]] = []
    for meta in MONMOUTH_OCEAN_KIA_DEALERS:
        canonical_name = meta["dealer_name"]
        # Prefer an active campaign lead for this dealership if one exists, otherwise pick best True Deal Score from inventory
        active_for_dealer = [
            d for d in dealers
            if _normalize_dealer_group_name(d.get("base_dealer_name") or d.get("dealer_name", "")) == canonical_name
        ]
        if active_for_dealer:
            active_for_dealer.sort(key=lambda x: float(x.get("true_deal_score") or 999999))
            chosen = dict(active_for_dealer[0])
        else:
            inv_for_dealer = [
                v for v in dealer_inventory
                if _normalize_dealer_group_name(v.get("base_dealer_name") or v.get("dealer_name", "")) == canonical_name
            ]
            inv_for_dealer.sort(
                key=lambda x: (
                    0 if x.get("is_non_black_interior", True) else 1,
                    float(x.get("true_deal_score") or 999999),
                )
            )
            chosen = dict(inv_for_dealer[0]) if inv_for_dealer else {"dealer_name": canonical_name, "id": meta["dealer_id"]}

        chosen["base_dealer_name"] = canonical_name
        chosen["display_name"] = meta.get("display_name") or canonical_name
        chosen["doc_fee"] = float(meta["doc_fee"])
        chosen["quirk_note"] = meta.get("quirk_note", "")
        chosen["bidding_strategy"] = meta.get("bidding_strategy", "")
        chosen["total_dealer_units"] = counts_by_dealer.get(canonical_name, 0)
        five_dealer_tracker.append(chosen)

    five_dealer_tracker.sort(key=lambda x: float(x.get("true_deal_score") or 999999))

    messages = list(state.get("message_queue", {}).values())
    messages.sort(key=lambda m: m.get("created_at", ""), reverse=True)
    pending_approvals = [m for m in messages if m.get("status") == "PENDING_APPROVAL"]
    queued_stealth = [m for m in messages if m.get("status") == "APPROVED_QUEUED"]

    return {
        "campaign": campaign,
        "market_benchmark": campaign.get("market_benchmark") or DEFAULT_MARKET_BENCHMARK,
        "dealers_ranked": dealers,
        "five_dealer_tracker": five_dealer_tracker,
        "dealer_inventory": dealer_inventory,
        "inventory_summary": {
            "total_vehicles": len(dealer_inventory),
            "dealers_available": list(counts_by_dealer.keys()),
            "trims_available": TRIM_PRIORITY_ORDER,
            "counts_by_dealer": counts_by_dealer,
            "counts_by_trim": counts_by_trim,
            "counts_by_interior": counts_by_interior,
            "counts_by_status": counts_by_status,
        },
        "pending_approvals_count": len(pending_approvals),
        "queued_stealth_count": len(queued_stealth),
        "pending_approvals": pending_approvals,
        "queued_stealth_messages": queued_stealth,
        "recent_messages": messages[:20],
    }
