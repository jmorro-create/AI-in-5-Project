"""
Copilot Communication Layer with Anti-Bot Variable Wait Time (Stealth Jitter),
Strict Trade-In / Lease-Return Secrecy Guardrail, Human-in-the-Loop Confirmation Hooks,
Personal Mobile Number SMS Bridge (`sms:` URI + Webhook Gateway), Twilio SMS,
and Local Simulated Dealer Inbox.
"""

import base64
from datetime import datetime, timedelta, timezone
import json
import os
import random
import re
from typing import Any, Dict, List, Optional, Tuple
import urllib.parse
import urllib.request
import uuid

from .deal_tracker import _slugify, upsert_dealer_lead
from .dealer_simulator import simulate_dealer_reply
from .firestore_sync import load_state, upsert_document
from .guardrails import require_human_confirmation_hook
from .observability import instrument_tool, log_structured_event
from .schemas import QueueDealerMessageInputSchema, build_guided_error, validate_tool_input
from .secret_manager import get_secret

FORBIDDEN_PRE_LOCK_PATTERNS = [
    r"\btrade[-\s]?in\b",
    r"\btrading\s+in\b",
    r"\bmy\s+trade\b",
    r"\bcurrent\s+lease\b",
    r"\blease\s+is\s+up\b",
    r"\blease\s+expir",
]

LEASE_EXPIRY_PATTERNS = [
    r"\bcurrent\s+lease\b",
    r"\blease\s+is\s+up\b",
    r"\blease\s+expir",
]

DEALER_ACCOUNTING_BUZZWORD_PATTERNS = [
    r"\binvoice\b",
    r"\bholdback\b",
    r"\bhold\s+back\b",
    r"\bfloorplan\b",
    r"\bfloor\s+plan\b",
    r"\blosing\s+money\b",
    r"\bdead\s+cost\b",
    r"\bmoney\s+factor\b",
    r"\bbuy[-\s]?rate\b",
    r"\b0\.00[123]\d{2}\b",
]


@instrument_tool
def dealer_initiated_accounting_jargon(dealer_text: str) -> bool:
    """Returns True ONLY if the dealer's message initiated dealer-accounting or rate jargon first.

    Args:
        dealer_text (str): Inbound message or worksheet text received from the dealership.

    Returns:
        bool: True if the dealer mentioned 'invoice', 'holdback', 'floorplan', 'losing money', or 'money factor'; False otherwise.
    """
    if not dealer_text:
        return False
    for pat in DEALER_ACCOUNTING_BUZZWORD_PATTERNS:
        if re.search(pat, dealer_text, flags=re.IGNORECASE):
            return True
    return False


@instrument_tool
def generate_natural_buyer_counter(
    dealer_lead: Dict[str, Any] | None = None,
    target_otd: float = 54800.0,
    target_selling_price: float = 51842.0,
    competing_best_otd: float = 0.0,
    competing_otd: float = 0.0,
    competing_discount_pct: float = 4.5,
    buyer_name: str = "Alex",
    round_number: int = 2,
    round_num: int = 0,
    dealer_objection_text: str = "",
    dealer_inbound_text: str = "",
    dealer_name: str = "",
    contact_name: str = "",
    vin: str = "",
    trim_level: str = "",
    interior_color: str = "",
    stock_status: str = "IN_TRANSIT",
    competing_dealer_name: str = "",
    has_addons: bool = False,
    addon_descriptions: str = "",
    has_mf_markup: bool = False,
    quoted_mf: float = 0.00190,
    doc_fee: float = 499.0,
) -> Dict[str, Any]:
    """Generates a concise, natural 2-3 sentence buyer counter-offer message.

    Follows three core campaign communication rules:
    1. Zero-Buzzword Default: Pitches frictionless pre-sale certainty ('deposit down today, no lot prep or add-ons needed, pick up within 24 hours of December truck landing') with ZERO accounting buzzwords.
    2. Reactive Mirror Exception: If the dealer brought up invoice, holdback, floorplan, losing money, or money factor first, mirrors with exact insider math so the dealer knows the buyer understands their backend numbers.
    3. Non-Black Interior Zero Scarcity Tax: Frames Non-Black interior as a nice-to-have tiebreaker worth at most the $295 factory option (~$300 OTD), ready to pivot to a Black-interior unit if not matched.

    Args:
        dealer_lead (Optional[Dict[str, Any]]): Optional dealer lead record dictionary.
        target_otd (float): Buyer's target Out-The-Door price in USD.
        target_selling_price (float): Buyer's target selling price before tax/fees in USD.
        competing_best_otd (float): Best competing NJ dealer OTD offer in USD.
        competing_otd (float): Alias for `competing_best_otd` in USD.
        competing_discount_pct (float): Best competing discount percentage off MSRP.
        buyer_name (str): Buyer's first name used to sign the message.
        round_number (int): Current negotiation round (1 = initial outreach, 2+ = counter-offer).
        round_num (int): Optional alias for `round_number`.
        dealer_objection_text (str): Any objection text sent by the dealer.
        dealer_inbound_text (str): Raw inbound text from the dealer.
        dealer_name (str): Dealership name override.
        contact_name (str): Salesperson or Internet Manager name override.
        vin (str): 17-character vehicle VIN override.
        trim_level (str): 2027 Kia Telluride Hybrid trim name override.
        interior_color (str): Interior color description override.
        stock_status (str): 'IN_TRANSIT' or 'ON_LOT'.
        competing_dealer_name (str): Name of the competing NJ dealership holding the best offer.
        has_addons (bool): True if the dealer's quote included mandatory add-ons.
        addon_descriptions (str): Description of dealer add-ons.
        has_mf_markup (bool): True if the dealer marked up the lease money factor above 0.00190.
        quoted_mf (float): Dealer's quoted lease money factor.
        doc_fee (float): Dealer's documentation fee in USD.

    Returns:
        Dict[str, Any]: Generated message payload with `script`, `body`, `sentence_count`, `tone_mode`,
            `dealer_initiated_jargon`, and `objection_handled`.
    """
    lead = dealer_lead or {}
    contact_full = str(contact_name or lead.get("contact_name") or "there")
    first_name = contact_full.split()[0] if contact_full else "there"
    eff_vin = str(vin or lead.get("vin") or "incoming VIN")
    eff_trim = str(trim_level or lead.get("trim_level") or "2027 Telluride Hybrid")
    short_trim = eff_trim.replace("2027 Kia ", "")
    eff_interior = str(interior_color or lead.get("interior_color") or "Terracotta")
    short_int = eff_interior.split("(")[0].strip()
    is_non_black = (
        bool(lead.get("is_non_black_interior", True))
        if "is_non_black_interior" in lead
        else ("black" not in eff_interior.lower())
    )
    msrp = float(lead.get("msrp") or 53890.0)
    invoice_price = float(lead.get("invoice_price") or round(msrp * 0.962, 0))
    addons = float(lead.get("dealer_addons_total") or (995.0 if has_addons else 0.0))
    eff_round = int(round_num if round_num > 0 else round_number)
    eff_comp_otd = float(competing_otd if competing_otd > 0 else competing_best_otd)

    combined_dealer_text = (
        f"{dealer_inbound_text} {dealer_objection_text} {lead.get('last_dealer_message', '')}".strip()
    )
    use_insider_mirror = dealer_initiated_accounting_jargon(combined_dealer_text)
    obj_low = combined_dealer_text.lower()

    if any(p in obj_low for p in ["come in", "stop by", "showroom", "in person", "visit us"]):
        objection_type = "SHOWROOM_TRAP"
    elif any(p in obj_low for p in ["don't send", "cant send", "not in writing", "policy"]):
        objection_type = "NO_WRITTEN_QUOTE_TRAP"
    elif any(p in obj_low for p in ["fake", "impossible", "no way", "match that", "take that deal"]):
        objection_type = "FAKE_QUOTE_BLUFF"
    else:
        objection_type = "STANDARD_COUNTER"

    if eff_round <= 1 and not use_insider_mirror:
        script = (
            f"Hi {first_name}, I'm in Monmouth County (07724) and looking to put a deposit down this week to lock in your incoming December {short_trim} (VIN {eff_vin}). "
            f"I don't need a car off the lot today and want zero dealer add-ons put on when it comes off the truck—what is your best all-in Out-The-Door price including 6.625% NJ tax and MVC fees? -{buyer_name}"
        )
        return {
            "script": script,
            "body": script,
            "sentence_count": 2,
            "tone_mode": "ZERO_BUZZWORD_NATURAL",
            "dealer_initiated_jargon": False,
            "objection_handled": "INITIAL_KICKOFF",
        }

    if use_insider_mirror:
        script = (
            f"Hi {first_name}, I know ${invoice_price:,.0f} is right around invoice on the {short_trim}, and since VIN {eff_vin} is a pre-sold December incoming unit that never sits on your lot "
            f"($0 floorplan cost, dipping just ~1.2% into your 2% Kia holdback at the base 0.00190 KMF buy rate with $0 add-ons), ${target_otd:,.0f} OTD (${target_selling_price:,.0f} selling price) is a clean net deal. "
            f"If your GSM will lock in ${target_otd:,.0f} OTD in writing today, I'll give you my credit card deposit right now and pick it up within 24 hours of the truck landing. -{buyer_name}"
        )
        return {
            "script": script,
            "body": script,
            "sentence_count": 2,
            "tone_mode": "REACTIVE_ACCOUNTING_MIRROR",
            "dealer_initiated_jargon": True,
            "objection_handled": objection_type,
        }

    if objection_type == "SHOWROOM_TRAP":
        script = (
            f"Hi {first_name}, I'm tied up at work all week so I'm wrapping this up remotely before coming in to sign. "
            f"If we can confirm ${target_otd:,.0f} Out-The-Door on your incoming December {short_trim} (VIN {eff_vin}) with nothing extra added when it comes off the truck, I'll put a deposit on a card right now and pick it up the day it arrives. -{buyer_name}"
        )
        sentence_count = 2
    elif objection_type == "NO_WRITTEN_QUOTE_TRAP":
        script = (
            f"Hi {first_name}, no need for a formal PDF—a quick text confirming ${target_otd:,.0f} total Out-The-Door (selling price + doc + 6.625% NJ tax + MVC tags, no add-ons) on VIN {eff_vin} works for me. "
            f"As soon as you text that confirmation over, I'm ready to call in a deposit to hold the December delivery. -{buyer_name}"
        )
        sentence_count = 2
    elif objection_type == "FAKE_QUOTE_BLUFF":
        script = (
            f"Hi {first_name}, no worries at all—I'm just looking to make an easy deal on an incoming December {short_trim}. "
            f"If your manager can do ${target_otd:,.0f} OTD on VIN {eff_vin} with no add-ons put on when it lands, I'll place my deposit with you right now; otherwise I'll go ahead and wrap up with the other store. -{buyer_name}"
        )
        sentence_count = 2
    elif is_non_black and eff_comp_otd > 0:
        black_anchor = round(target_otd - 300.0, 0)
        script = (
            f"Hi {first_name}, thanks for sending the numbers on your incoming December {short_trim} (VIN {eff_vin}). "
            f"I'm totally fine taking an incoming Black-interior unit at another local store for ${black_anchor:,.0f} OTD, though I like your {short_int} interior slightly better as a tiebreaker. "
            f"If you can do ${target_otd:,.0f} OTD (just covering the $295 factory interior option with no dealer add-ons put on when it comes off the truck), I'll put a deposit down today and pick it up within 24 hours of arrival. -{buyer_name}"
        )
        sentence_count = 3
    else:
        addon_phrase = (
            "take off the dealer add-ons and "
            if addons > 0
            else "keep it clean with no add-ons when it comes off the truck and "
        )
        script = (
            f"Hi {first_name}, thanks for the quote on your incoming December {short_trim} (VIN {eff_vin}). "
            f"I have a stronger local offer on the table, but if you can {addon_phrase}lock in ${target_otd:,.0f} Out-The-Door in writing, I'll put down a deposit today and pick it up within 24 hours of the truck landing in December. -{buyer_name}"
        )
        sentence_count = 2

    return {
        "script": script,
        "body": script,
        "sentence_count": sentence_count,
        "tone_mode": "ZERO_BUZZWORD_NATURAL",
        "dealer_initiated_jargon": False,
        "objection_handled": objection_type,
    }


def enforce_trade_in_secrecy(
    body: str, dealer_stage: str, otd_locked_confirmed: bool = False
) -> Tuple[str, Optional[str]]:
    """Ensures no outbound message mentions a trade-in before OTD is locked (Gate #2), and NEVER leaks lease expiration.

    Args:
        body (str): Candidate outbound message text.
        dealer_stage (str): Current negotiation stage for the dealership.
        otd_locked_confirmed (bool): True if Gate #2 (written OTD lock) has been confirmed by the buyer.

    Returns:
        Tuple[str, Optional[str]]: `(sanitized_body, guardrail_warning_or_none)`.
    """
    active_patterns = (
        LEASE_EXPIRY_PATTERNS
        if (dealer_stage == "DEAL_SECURED" or otd_locked_confirmed)
        else FORBIDDEN_PRE_LOCK_PATTERNS
    )

    for pat in active_patterns:
        if re.search(pat, body, flags=re.IGNORECASE):
            sentences = re.split(r"(?<=[.!?])\s+", body)
            clean_sentences = [
                s
                for s in sentences
                if not any(
                    re.search(p, s, flags=re.IGNORECASE)
                    for p in active_patterns
                )
            ]
            cleaned = " ".join(clean_sentences).strip()
            warning = (
                "🔒 TRADE-IN SECRECY GUARDRAIL TRIGGERED: Removed mention of trade-in / expiring lease. "
                "Never reveal trade-in or current lease end date until the 2027 Kia Telluride OTD/Cap Cost is locked in writing."
            )
            return cleaned or body, warning
    return body, None


def calculate_human_delay_seconds(
    round_number: int, message_body: str, channel: str = "SMS_PERSONAL"
) -> Tuple[int, str]:
    """Computes a realistic, non-robotic variable wait time before replying to a dealer.

    Args:
        round_number (int): Current negotiation round (1 = initial outreach, 2 = counter, 3+ = final leverage).
        message_body (str): Text of the outbound message.
        channel (str): 'EMAIL', 'SMS_PERSONAL', or 'SMS_TWILIO'.

    Returns:
        Tuple[int, str]: `(delay_seconds, human_readable_explanation)`.
    """
    rng = random.Random(f"v136:{round_number}:{channel}:{message_body}")
    word_count = max(10, len(message_body.split()))
    typing_and_reading_sec = int(word_count * rng.uniform(1.1, 1.9))
    odd_second_jitter = rng.randint(11, 57)

    if round_number <= 1:
        base_minutes = rng.randint(9, 22)
        reason = "Initial inquiry pacing (avoids instant bot-like form follow-up)"
    elif round_number == 2:
        base_minutes = rng.randint(21, 48)
        reason = "Simulates buyer auditing lease/OTD numbers on a spreadsheet before countering"
    else:
        base_minutes = rng.randint(33, 74)
        reason = "Simulates buyer comparing competing dealer quotes & consulting partner"

    if channel.upper() == "EMAIL":
        base_minutes += rng.randint(8, 19)

    total_seconds = (base_minutes * 60) + typing_and_reading_sec + odd_second_jitter
    mins, secs = divmod(total_seconds, 60)
    explanation = f"{mins}m {secs}s stealth wait — {reason}"
    return total_seconds, explanation


def build_personal_sms_deep_link(phone: str, body: str) -> str:
    """Builds a native `sms:` URI link so the user can send the text from their own mobile number.

    Args:
        phone (str): Target recipient phone number in E.164 or standard format.
        body (str): Text message body to pre-populate.

    Returns:
        str: Formatted `sms:<phone>?&body=<encoded_body>` URI string.
    """
    clean_phone = "".join(c for c in phone if c.isdigit() or c == "+")
    encoded_body = urllib.parse.quote(body)
    return f"sms:{clean_phone}?&body={encoded_body}"


def _send_via_twilio(to_phone: str, body: str) -> Dict[str, Any]:
    """Dispatches an SMS via Twilio REST API using credentials from Secret Manager / environment."""
    account_sid = get_secret("TWILIO_ACCOUNT_SID", default="")
    auth_token = get_secret("TWILIO_AUTH_TOKEN", default="")
    from_number = get_secret("TWILIO_FROM_NUMBER", default="")

    if not (account_sid and auth_token and from_number):
        return {
            "live_dispatched": False,
            "provider": "twilio_sandbox_fallback",
            "note": "Twilio credentials not configured in Secret Manager; delivered to Local Simulated Dealer Inbox.",
        }

    url = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"
    payload = urllib.parse.urlencode(
        {"To": to_phone, "From": from_number, "Body": body}
    ).encode("utf-8")
    creds = base64.b64encode(f"{account_sid}:{auth_token}".encode("utf-8")).decode(
        "ascii"
    )
    req = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Authorization": f"Basic {creds}",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5.0) as resp:
            resp_data = json.loads(resp.read().decode("utf-8"))
            return {
                "live_dispatched": True,
                "provider": "twilio_live",
                "sid": resp_data.get("sid"),
            }
    except Exception as e:
        log_structured_event(
            event_type="TWILIO_DISPATCH_FALLBACK",
            message=f"Twilio send failed, falling back to simulator: {e}",
            severity="WARNING",
            component="comms_tools",
        )
        return {
            "live_dispatched": False,
            "provider": "twilio_error_fallback",
            "error": str(e),
        }


def _send_via_personal_mobile_gateway(to_phone: str, body: str) -> Dict[str, Any]:
    """Sends SMS through the user's personal mobile number via Android/iOS Webhook Gateway or Native `sms:` URI bridge."""
    webhook_url = (
        get_secret("PERSONAL_SMS_GATEWAY_URL", default="")
        or get_secret("PERSONAL_SMS_WEBHOOK_URL", default="")
    ).strip()
    gateway_token = get_secret("PERSONAL_SMS_GATEWAY_TOKEN", default="").strip()
    user_mobile = (
        get_secret("BUYER_PERSONAL_PHONE", default="")
        or get_secret("USER_MOBILE_NUMBER", default="My Personal Mobile")
    ).strip()
    sms_uri = build_personal_sms_deep_link(to_phone, body)

    if webhook_url:
        # Supports both Android SMS Gateway (capcom6/android-sms-gateway: phoneNumbers + textMessage)
        # and generic iOS Shortcuts / Tasker webhooks (to + from + message + body)
        payload = json.dumps(
            {
                "to": to_phone,
                "from": user_mobile,
                "message": body,
                "body": body,
                "phoneNumbers": [to_phone],
                "textMessage": {"text": body},
            }
        ).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if gateway_token:
            headers["Authorization"] = f"Bearer {gateway_token}"
        req = urllib.request.Request(
            webhook_url,
            data=payload,
            headers=headers,
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=5.0) as resp:
                return {
                    "live_dispatched": 200 <= resp.status < 300,
                    "provider": "personal_mobile_webhook",
                    "from_number": user_mobile,
                    "to": to_phone,
                    "sms_deep_link": sms_uri,
                }
        except Exception as e:
            log_structured_event(
                event_type="PERSONAL_SMS_WEBHOOK_FALLBACK",
                message=f"Personal SMS webhook fallback: {e}",
                severity="WARNING",
                component="comms_tools",
            )
            return {
                "live_dispatched": False,
                "provider": "personal_mobile_bridge",
                "from_number": user_mobile,
                "to": to_phone,
                "sms_deep_link": sms_uri,
                "error": str(e),
            }

    return {
        "live_dispatched": False,
        "provider": "personal_mobile_bridge_and_simulator",
        "from_number": user_mobile,
        "to": to_phone,
        "sms_deep_link": sms_uri,
        "note": "Ready for 1-Tap Send from your personal phone via `sms:` link on the dashboard.",
    }


@instrument_tool
def queue_dealer_message(
    dealer_id: str,
    body: str,
    channel: str = "SMS_PERSONAL",
    subject: str = "",
    auto_dispatch: bool = False,
) -> Dict[str, Any]:
    """Drafts a negotiation email or SMS into the Copilot Approval Queue with a calculated anti-bot wait timer.

    IMPORTANT:
    1. In Copilot Mode (`auto_dispatch=False`, the default), this tool enforces a Human-in-the-Loop stop
       by saving the draft as 'PENDING_APPROVAL' until the human buyer approves it via `approve_queued_message`.
    2. Automatically enforces the Trade-In Secrecy Guardrail: strips any premature mention of a trade-in or
       expiring lease unless the dealer's quote is already locked (`DEAL_SECURED` / `otd_locked_in_writing=True`).
    3. Preserves RFC 5322 email thread continuity (`In-Reply-To`, `References`, `thread_id`, and `Re:` subject)
       so all emails with a dealership stay in a single continuous Gmail thread.

    Args:
        dealer_id (str): Target dealership identifier (e.g. 'dlr-raceway-kia-of-freehold').
        body (str): Outbound SMS or email text to queue.
        channel (str): Communication channel ('SMS_PERSONAL', 'EMAIL', or 'SMS_TWILIO').
        subject (str): Optional email subject line.
        auto_dispatch (bool): If False (default Copilot mode), pauses in PENDING_APPROVAL for human confirmation.

    Returns:
        Dict[str, Any]: Queued or dispatched message document including `id`, `status`, `body`,
            `guardrail_warning`, `delay_seconds`, `sms_deep_link`, `email_deep_link`, and `hitl_gate`.
    """
    from .live_comms_connector import build_personal_email_deep_link, ensure_reply_subject

    _, guided_err = validate_tool_input(
        schema_cls=QueueDealerMessageInputSchema,
        raw_kwargs={
            "dealer_id": dealer_id,
            "body": body,
            "channel": channel,
            "subject": subject,
            "auto_dispatch": auto_dispatch,
        },
        tool_name="queue_dealer_message",
        recovery_hint=(
            "Provide a non-empty `dealer_id` (e.g. 'dlr-raceway-kia-of-freehold'), a `body` string of at least "
            "5 characters, and `channel` set to 'SMS_PERSONAL', 'EMAIL', or 'SMS_TWILIO'."
        ),
    )
    if guided_err is not None:
        return guided_err

    state = load_state()
    if not dealer_id.startswith("dlr-"):
        dealer_id = f"dlr-{_slugify(dealer_id)}"

    lead = state.get("dealer_leads", {}).get(dealer_id)
    if not lead:
        lead = upsert_dealer_lead(
            dealer_name=dealer_id.replace("dlr-", "").replace("-", " ").title(),
            preferred_channel=channel,
        )
        state = load_state()

    camp_id = (
        lead.get("campaign_id") or state.get("active_campaign_id") or "camp-default"
    )
    campaign = state.get("campaigns", {}).get(camp_id, {})
    vehicle = campaign.get("vehicle", "2027 Kia Telluride SX Prestige X-Line")

    channel_norm = channel.strip().upper()
    if channel_norm not in ("EMAIL", "SMS_PERSONAL", "SMS_TWILIO"):
        channel_norm = "SMS_PERSONAL"

    otd_locked_flag = bool(lead.get("otd_locked_in_writing", False))
    sanitized_body, guardrail_warning = enforce_trade_in_secrecy(
        body, lead.get("stage", "NEW_LEAD"), otd_locked_confirmed=otd_locked_flag
    )

    next_round = int(lead.get("round", 0)) + 1
    delay_sec, delay_reason = calculate_human_delay_seconds(
        round_number=next_round, message_body=sanitized_body, channel=channel_norm
    )

    existing_draft = next(
        (
            m
            for m in state.get("message_queue", {}).values()
            if m.get("dealer_id") == dealer_id
            and m.get("status") == "PENDING_APPROVAL"
            and m.get("body") == sanitized_body
        ),
        None,
    )
    msg_id = existing_draft["id"] if existing_draft else f"msg-{uuid.uuid4().hex[:10]}"
    now_iso = (
        existing_draft["created_at"]
        if existing_draft and existing_draft.get("created_at")
        else datetime.now(timezone.utc).isoformat()
    )
    if existing_draft:
        delay_sec = existing_draft.get("delay_seconds", delay_sec)
        delay_reason = existing_draft.get("delay_explanation", delay_reason)

    to_phone = lead.get("contact_phone", "+15550101001")
    to_email = lead.get("contact_email", "sales@dealer.example.com")

    default_subj = f"Incoming Dec Allocation - {vehicle} (VIN {lead.get('vin', 'Incoming')})"
    existing_thread_subj = str(lead.get("email_thread_subject", "")).strip()
    eff_subject = ensure_reply_subject(subject or existing_thread_subj or default_subj, existing_thread_subj)

    hitl_gate = require_human_confirmation_hook(
        action_name="dispatch_dealer_message",
        action_details={"dealer_id": dealer_id, "channel": channel_norm, "round": next_round},
        autonomy_mode="FULL_AUTOPILOT" if auto_dispatch else "COPILOT",
        explicitly_confirmed=bool(auto_dispatch),
    )

    msg_doc = {
        "id": msg_id,
        "campaign_id": camp_id,
        "dealer_id": dealer_id,
        "dealer_name": lead.get("dealer_name", dealer_id),
        "to_contact": to_email if channel_norm == "EMAIL" else to_phone,
        "direction": "OUTBOUND",
        "channel": channel_norm,
        "status": "PENDING_APPROVAL",
        "round": next_round,
        "subject": eff_subject,
        "thread_id": str(lead.get("email_thread_id", "")),
        "in_reply_to": str(lead.get("last_email_message_id", "")),
        "references": str(lead.get("email_references", "")),
        "body": sanitized_body,
        "guardrail_warning": guardrail_warning or "",
        "delay_seconds": delay_sec,
        "delay_explanation": delay_reason,
        "sms_deep_link": build_personal_sms_deep_link(to_phone, sanitized_body),
        "email_deep_link": build_personal_email_deep_link(to_email, eff_subject, sanitized_body),
        "hitl_gate": hitl_gate,
        "scheduled_send_at": "",
        "sent_at": "",
        "created_at": now_iso,
    }

    lead["stage"] = "DRAFT_PENDING_APPROVAL"
    upsert_document("dealer_leads", dealer_id, lead)
    saved_msg = upsert_document("message_queue", msg_id, msg_doc)

    if auto_dispatch and hitl_gate["allowed_to_proceed"]:
        approve_queued_message(msg_id, send_immediately_override=True)
        return load_state().get("message_queue", {}).get(msg_id, saved_msg)

    return saved_msg


@instrument_tool
def approve_queued_message(
    message_id: str,
    send_immediately_override: bool = False,
    edited_body: str = "",
) -> Dict[str, Any]:
    """Approves a Copilot draft message in the Human-in-the-Loop approval queue.

    By default (`send_immediately_override=False`), schedules the message with its variable human-like
    wait timer (`APPROVED_QUEUED`) so the dealer doesn't suspect an automated agent.
    If `send_immediately_override=True`, dispatches the message immediately (and triggers the simulated
    dealer reply only when `transport_mode == 'SIMULATION'`).

    Args:
        message_id (str): Message ID to approve (e.g., 'msg-1a2b3c4d5e') or 'ALL' to approve all pending drafts.
        send_immediately_override (bool): If True, bypasses the stealth wait countdown and dispatches immediately.
        edited_body (str): Optional human-edited message text replacing the draft body before approval.

    Returns:
        Dict[str, Any]: Approval summary including `approved_count`, `mode`, `approved_messages`, and `dispatched_results`.
    """
    from .live_comms_connector import build_personal_email_deep_link

    state = load_state()
    queue = state.get("message_queue", {})

    if message_id.strip().upper() == "ALL":
        target_ids = [
            m_id
            for m_id, m in queue.items()
            if m.get("status") == "PENDING_APPROVAL"
        ]
    else:
        target_ids = [message_id] if message_id in queue else []

    if not target_ids:
        pending_ids = [
            m_id for m_id, m in queue.items() if m.get("status") == "PENDING_APPROVAL"
        ]
        return build_guided_error(
            error_code="MESSAGE_NOT_FOUND",
            message=f"No pending message found matching '{message_id}'.",
            recovery_instructions=(
                f"Call `get_negotiation_dashboard()` to view `pending_approvals` (currently pending IDs: {pending_ids}), "
                f"or pass `message_id='ALL'` to approve all pending drafts, or call `queue_dealer_message(...)` to create a draft first."
            ),
            invalid_fields={"message_id": message_id},
            extra_context={"approved_count": 0},
        )

    now = datetime.now(timezone.utc)
    approved_items = []
    dispatched_results = []

    for m_id in target_ids:
        msg = queue[m_id]
        dealer_id = msg.get("dealer_id")
        lead = state.get("dealer_leads", {}).get(dealer_id) or {}
        if edited_body.strip():
            clean_body, warning = enforce_trade_in_secrecy(edited_body.strip(), "ACTIVE")
            msg["body"] = clean_body
            if warning:
                msg["guardrail_warning"] = warning
            phone = lead.get("contact_phone") or msg.get("to_contact", "+15550101001")
            email_addr = lead.get("contact_email") or msg.get("to_contact", "sales@dealer.example.com")
            msg["sms_deep_link"] = build_personal_sms_deep_link(phone, msg["body"])
            msg["email_deep_link"] = build_personal_email_deep_link(
                email_addr, msg.get("subject", ""), msg["body"]
            )

        delay_sec = int(msg.get("delay_seconds") or 900)
        scheduled_dt = now + timedelta(seconds=delay_sec)
        msg["status"] = "APPROVED_QUEUED"
        msg["approved_at"] = now.isoformat()
        msg["scheduled_send_at"] = scheduled_dt.isoformat()
        upsert_document("message_queue", m_id, msg)

        if lead:
            lead["stage"] = "STEALTH_TIMER_ACTIVE"
            upsert_document("dealer_leads", dealer_id, lead)

        approved_items.append(msg)

        if send_immediately_override:
            dispatch_res = _execute_message_dispatch(m_id)
            dispatched_results.append(dispatch_res)

    return {
        "approved_count": len(approved_items),
        "mode": "DISPATCHED_IMMEDIATELY"
        if send_immediately_override
        else "STEALTH_TIMER_QUEUED",
        "approved_messages": approved_items,
        "dispatched_results": dispatched_results,
    }


def _execute_message_dispatch(message_id: str) -> Dict[str, Any]:
    """Internal helper that transitions an approved message to SENT, calls SMS/Gmail adapter, and respects SIMULATION vs LIVE mode."""
    from .live_comms_connector import (
        ensure_reply_subject,
        get_transport_mode,
        is_placeholder_contact,
        send_via_personal_gmail,
    )

    state = load_state()
    msg = state.get("message_queue", {}).get(message_id)
    if not msg:
        return build_guided_error(
            error_code="DISPATCH_MESSAGE_NOT_FOUND",
            message=f"Message {message_id} not found in message_queue.",
            recovery_instructions="Call `get_negotiation_dashboard()` to inspect valid message IDs in `message_queue`.",
            invalid_fields={"message_id": message_id},
        )

    dealer_id = msg.get("dealer_id", "")
    lead = state.get("dealer_leads", {}).get(dealer_id) or {}
    channel = str(msg.get("channel", "SMS_PERSONAL")).upper()
    to_contact = (
        lead.get("contact_email", msg.get("to_contact", "sales@dealer.example.com"))
        if channel == "EMAIL"
        else lead.get("contact_phone", msg.get("to_contact", "+15550101001"))
    )
    msg["to_contact"] = to_contact
    body = msg.get("body", "")
    transport_mode = get_transport_mode()

    # In LIVE mode, block accidental dispatch to 555 / .example.com demo placeholder contacts
    if transport_mode == "LIVE" and is_placeholder_contact(to_contact, channel):
        return build_guided_error(
            error_code="PLACEHOLDER_CONTACT_IN_LIVE_MODE",
            message=(
                f"LIVE mode is active, but dealer '{lead.get('dealer_name', dealer_id)}' still has a demo placeholder "
                f"contact ({to_contact})."
            ),
            recovery_instructions=(
                f"Update the real salesperson's phone number or email address using `update_dealer_contact_info("
                f"dealer_id='{dealer_id}', contact_name='...', contact_phone='...', contact_email='...')` "
                f"(or the inline Salesperson Contact Editor in the dashboard), or switch back to `SIMULATION` mode."
            ),
            invalid_fields={"to_contact": to_contact, "dealer_id": dealer_id},
        )

    existing_thread_id = str(lead.get("email_thread_id") or msg.get("thread_id") or "")
    existing_in_reply_to = str(lead.get("last_email_message_id") or msg.get("in_reply_to") or "")
    existing_refs = str(lead.get("email_references") or msg.get("references") or "")
    existing_thread_subj = str(lead.get("email_thread_subject") or "")
    eff_subject = ensure_reply_subject(msg.get("subject", ""), existing_thread_subj)

    if channel == "SMS_TWILIO":
        transport_info = _send_via_twilio(to_contact, body)
    elif channel == "SMS_PERSONAL":
        transport_info = _send_via_personal_mobile_gateway(to_contact, body)
    else:
        if transport_mode == "LIVE" or os.environ.get("GMAIL_APP_PASSWORD") or os.environ.get("GMAIL_OAUTH_REFRESH_TOKEN"):
            transport_info = send_via_personal_gmail(
                to_email=to_contact,
                subject=eff_subject,
                body=body,
                thread_id=existing_thread_id,
                in_reply_to=existing_in_reply_to,
                references=existing_refs,
            )
        else:
            gen_msg_id = f"<sim-email-{uuid.uuid4().hex[:10]}@gmail.com>"
            eff_refs = f"{existing_refs} {existing_in_reply_to} {gen_msg_id}".strip()
            transport_info = {
                "live_dispatched": False,
                "provider": "local_simulated_email_inbox",
                "to": to_contact,
                "subject": eff_subject,
                "message_id": gen_msg_id,
                "thread_id": existing_thread_id or gen_msg_id.strip("<>"),
                "in_reply_to": existing_in_reply_to,
                "references": eff_refs,
            }

    now_iso = datetime.now(timezone.utc).isoformat()
    msg["status"] = "SENT"
    msg["sent_at"] = now_iso
    msg["subject"] = eff_subject
    msg["external_message_id"] = transport_info.get("message_id", "")
    msg["thread_id"] = transport_info.get("thread_id", existing_thread_id)
    msg["in_reply_to"] = transport_info.get("in_reply_to", existing_in_reply_to)
    msg["references"] = transport_info.get("references", existing_refs)
    msg["transport_info"] = transport_info
    upsert_document("message_queue", message_id, msg)

    lead = load_state().get("dealer_leads", {}).get(dealer_id)
    if lead:
        lead["stage"] = "AWAITING_DEALER_REPLY"
        if channel == "EMAIL":
            lead["email_thread_id"] = msg["thread_id"]
            lead["last_email_message_id"] = msg["external_message_id"]
            lead["email_references"] = msg["references"]
            if not lead.get("email_thread_subject"):
                lead["email_thread_subject"] = eff_subject
        upsert_document("dealer_leads", dealer_id, lead)

    if transport_mode == "LIVE":
        return {
            "sent_message": msg,
            "transport_info": transport_info,
            "transport_mode": "LIVE",
            "simulated_dealer_reply": None,
        }

    sim_reply = simulate_dealer_reply(dealer_id=dealer_id, buyer_message=body)
    return {
        "sent_message": msg,
        "transport_info": transport_info,
        "transport_mode": "SIMULATION",
        "simulated_dealer_reply": sim_reply,
    }


@instrument_tool
def dispatch_ready_messages(force_send_all_queued: bool = False) -> Dict[str, Any]:
    """Checks the stealth timer queue and dispatches any approved messages whose variable wait time has elapsed.

    Args:
        force_send_all_queued (bool): If True, immediately dispatches all `APPROVED_QUEUED` messages
            regardless of remaining stealth countdown time.

    Returns:
        Dict[str, Any]: Dictionary containing `dispatched_count`, `dispatched_results`, and `still_waiting_in_stealth_queue`.
    """
    state = load_state()
    queue = state.get("message_queue", {})
    now = datetime.now(timezone.utc)

    ready_ids = []
    still_waiting = []

    for m_id, msg in queue.items():
        if msg.get("status") != "APPROVED_QUEUED":
            continue
        sched_str = msg.get("scheduled_send_at", "")
        if force_send_all_queued or not sched_str:
            ready_ids.append(m_id)
            continue
        try:
            sched_dt = datetime.fromisoformat(sched_str)
            if sched_dt <= now:
                ready_ids.append(m_id)
            else:
                remaining_sec = int((sched_dt - now).total_seconds())
                still_waiting.append(
                    {
                        "message_id": m_id,
                        "dealer_name": msg.get("dealer_name"),
                        "remaining_seconds": remaining_sec,
                        "scheduled_send_at": sched_str,
                    }
                )
        except Exception:
            ready_ids.append(m_id)

    results = [_execute_message_dispatch(m_id) for m_id in ready_ids]
    return {
        "dispatched_count": len(results),
        "dispatched_results": results,
        "still_waiting_in_stealth_queue": still_waiting,
    }
