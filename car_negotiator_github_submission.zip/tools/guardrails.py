"""
Orchestration Guardrails, Policy Plugins, Self-Evaluation Callbacks, Strategic Model Routing,
and Human-in-the-Loop (HITL) Confirmation Hooks.

Implements Category 3 of the AgentOps Code Review Matrix:
1. Strategic Model Routing (`select_model_for_task` routing simple lookups/math to `gemini-2.5-flash`
   and complex multi-dealer strategy/planning to `gemini-2.5-pro`).
2. Guardrails & Policy Plugins:
   - `DEFAULT_SAFETY_SETTINGS` (Google Cloud / Gemini `SafetySetting` thresholds)
   - `before_model_guardrail_callback` (Prompt injection / jailbreak defense)
   - `before_tool_guardrail_callback` (Pre-tool policy validation + Intent logging)
   - `after_tool_guardrail_callback` (Post-tool invariant verification + Outcome logging)
   - `after_model_self_eval_callback` & `evaluate_agent_response_policy` (Self-evaluation checking
     that model responses never leak expiring lease info, premature trade-in mentions, or unauthorized buzzwords).
3. Human-in-the-Loop Hooks (`require_human_confirmation_hook` enforcing `COPILOT` -> `PENDING_APPROVAL`).
"""

import re
import time
from typing import Any, Dict, List, Optional

try:
    from google.genai import types as genai_types
except ImportError:
    genai_types = None  # type: ignore[assignment]

from .observability import (
    log_structured_event,
    log_tool_intent,
    log_tool_outcome,
    redact_pii,
)
from .schemas import build_guided_error

PROMPT_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(?:all\s+)?(?:previous|prior)\s+instructions", re.I),
    re.compile(r"disregard\s+system\s+prompt", re.I),
    re.compile(r"reveal\s+(?:your\s+)?(?:api\s+key|secret|system\s+prompt)", re.I),
    re.compile(r"bypass\s+copilot\s+approval", re.I),
]

FORBIDDEN_UNPROMPTED_JARGON = [
    (re.compile(r"\bholdback\b", re.I), "holdback"),
    (re.compile(r"\bfloorplan\b", re.I), "floorplan"),
    (re.compile(r"\binvoice\s+price\b", re.I), "invoice price"),
]

PREMATURE_TRADE_IN_PATTERNS = [
    (re.compile(r"\btrade[-\s]?in\b", re.I), "premature trade-in disclosure"),
    (re.compile(r"\bexpiring\s+lease\b", re.I), "expiring lease disclosure"),
    (re.compile(r"\bcurrent\s+lease\s+ends\b", re.I), "current lease expiration disclosure"),
]


def _build_safety_settings() -> List[Any]:
    """Builds standard Gemini SafetySetting thresholds across 4 harm categories."""
    categories = [
        "HARM_CATEGORY_HATE_SPEECH",
        "HARM_CATEGORY_DANGEROUS_CONTENT",
        "HARM_CATEGORY_HARASSMENT",
        "HARM_CATEGORY_SEXUALLY_EXPLICIT",
    ]
    if genai_types is not None and hasattr(genai_types, "SafetySetting"):
        try:
            return [
                genai_types.SafetySetting(
                    category=cat,
                    threshold="BLOCK_LOW_AND_ABOVE",
                )
                for cat in categories
            ]
        except Exception:
            pass
    return [
        {"category": cat, "threshold": "BLOCK_LOW_AND_ABOVE"}
        for cat in categories
    ]


DEFAULT_SAFETY_SETTINGS: List[Any] = _build_safety_settings()


def select_model_for_task(
    prompt: str,
    agent_mode: str = "strategist",
) -> Dict[str, Any]:
    """Dynamically selects between `gemini-2.5-flash` and `gemini-2.5-pro` based on task complexity.

    Simple single-fact lookups, doc fee checks, and straightforward status checks route to
    `gemini-2.5-flash` for low latency and cost efficiency. Complex multi-dealer strategy,
    side-by-side trim comparisons, lease-vs-buy modeling, and forensic worksheet audits route
    to `gemini-2.5-pro`.

    Args:
        prompt (str): User prompt or task description.
        agent_mode (str): Active persona mode ('strategist', 'auditor', 'drafter', 'researcher').

    Returns:
        Dict[str, Any]: Dictionary with `selected_model`, `task_complexity`, and `rationale`.
    """
    text = (prompt or "").strip().lower()
    mode = (agent_mode or "strategist").strip().lower()

    complex_signals = [
        "compare",
        "side by side",
        "side-by-side",
        "lease vs",
        "lease or buy",
        "trade-in",
        "trade in",
        "all 3",
        "all three",
        "5 dealers",
        "five dealers",
        "squeeze",
        "strategy",
        "audit",
        "worksheet",
        "money factor",
        "residual",
        "counter",
    ]
    matched_signals = [sig for sig in complex_signals if sig in text]
    is_complex = (
        len(matched_signals) >= 2
        or len(text) > 160
        or (mode == "strategist" and len(matched_signals) >= 1)
    )

    selected_model = "gemini-2.5-pro" if is_complex else "gemini-2.5-flash"
    result = {
        "selected_model": selected_model,
        "task_complexity": "HIGH_COMPLEXITY_REASONING" if is_complex else "FAST_LOOKUP_OR_SINGLE_STEP",
        "agent_mode": mode,
        "matched_signals": matched_signals,
        "rationale": (
            f"Routed to {selected_model} due to multi-factor reasoning signals {matched_signals}"
            if is_complex
            else f"Routed to {selected_model} for low-latency lookup/calculation"
        ),
    }
    log_structured_event(
        event_type="MODEL_ROUTING_DECISION",
        message=f"Selected {selected_model} ({result['task_complexity']})",
        component="model_router",
        metadata=result,
    )
    return result


def evaluate_agent_response_policy(
    response_text: str,
    dealer_initiated_jargon: bool = False,
    otd_locked_in_writing: bool = False,
) -> Dict[str, Any]:
    """Evaluates an agent response or outbound draft against negotiation policy guardrails.

    Verifies that:
    1. Dealer accounting jargon ('holdback', 'floorplan', 'invoice price') is not introduced
       unprompted when `dealer_initiated_jargon=False`.
    2. Trade-in vehicles or expiring leases are never disclosed before `otd_locked_in_writing=True`.
    3. Any accidental PII in the response is scrubbed.

    Args:
        response_text (str): Candidate agent response or dealer draft text.
        dealer_initiated_jargon (bool): True if the dealer brought up invoice/holdback first.
        otd_locked_in_writing (bool): True if the OTD price is already locked in writing.

    Returns:
        Dict[str, Any]: Policy check report containing `passed` (bool), `violations` (List[str]),
            and `sanitized_text` (str).
    """
    text = str(response_text or "")
    violations: List[str] = []
    sanitized = text

    if not dealer_initiated_jargon:
        for pattern, label in FORBIDDEN_UNPROMPTED_JARGON:
            if pattern.search(text):
                violations.append(f"UNPROMPTED_ACCOUNTING_JARGON:{label}")
                sanitized = pattern.sub("market OTD comp", sanitized)

    if not otd_locked_in_writing:
        for pattern, label in PREMATURE_TRADE_IN_PATTERNS:
            if pattern.search(text):
                violations.append(f"PREMATURE_CONTINGENCY_LEAK:{label}")

    passed = len(violations) == 0
    report = {
        "passed": passed,
        "violations": violations,
        "dealer_initiated_jargon": dealer_initiated_jargon,
        "otd_locked_in_writing": otd_locked_in_writing,
        "sanitized_text": sanitized,
    }
    if not passed:
        log_structured_event(
            event_type="POLICY_SELF_EVAL_VIOLATION",
            message=f"Policy guardrail flagged {len(violations)} violation(s): {violations}",
            severity="WARNING",
            component="policy_guardrail",
            metadata=report,
        )
    return report


def before_model_guardrail_callback(
    callback_context: Any = None,
    llm_request: Any = None,
) -> Optional[Any]:
    """Google ADK `before_model_callback` hook that inspects prompts for injection attempts.

    Args:
        callback_context (Any): ADK callback context.
        llm_request (Any): Outbound LLM request payload.

    Returns:
        Optional[Any]: None to allow execution, or a blocked response if injection is detected.
    """
    raw_str = str(llm_request or "")
    for pat in PROMPT_INJECTION_PATTERNS:
        if pat.search(raw_str):
            log_structured_event(
                event_type="PROMPT_INJECTION_BLOCKED",
                message="Blocked prompt injection attempt in before_model_guardrail_callback",
                severity="WARNING",
                component="model_guardrail",
            )
            return build_guided_error(
                error_code="PROMPT_INJECTION_BLOCKED",
                message="Request blocked by security guardrail policy.",
                recovery_suggestion="Rephrase your question focusing on 2027 Kia Telluride Hybrid pricing, OTD math, or dealer quotes.",
            )
    return None


def after_model_self_eval_callback(
    callback_context: Any = None,
    llm_response: Any = None,
) -> Optional[Any]:
    """Google ADK `after_model_callback` hook that runs policy self-evaluation on model outputs.

    Args:
        callback_context (Any): ADK callback context.
        llm_response (Any): Model response object.

    Returns:
        Optional[Any]: None after logging policy verification.
    """
    text = str(getattr(llm_response, "text", "") or llm_response or "")
    if text:
        evaluate_agent_response_policy(
            response_text=text,
            dealer_initiated_jargon=False,
            otd_locked_in_writing=True,
        )
    return None


def before_tool_guardrail_callback(
    tool: Any = None,
    args: Optional[Dict[str, Any]] = None,
    tool_context: Any = None,
) -> Optional[Dict[str, Any]]:
    """Google ADK `before_tool_callback` hook that validates tool arguments and logs tool intent.

    Args:
        tool (Any): Tool function or ADK BaseTool instance.
        args (Optional[Dict[str, Any]]): Arguments supplied to the tool.
        tool_context (Any): ADK ToolContext instance.

    Returns:
        Optional[Dict[str, Any]]: None to proceed with tool execution, or guided error dict if blocked.
    """
    tool_name = getattr(tool, "name", None) or getattr(tool, "__name__", str(tool))
    safe_args = dict(args or {})
    if tool_context is not None and hasattr(tool_context, "state"):
        try:
            tool_context.state["_tool_start_ts"] = time.perf_counter()
        except Exception:
            pass
    log_tool_intent(tool_name=str(tool_name), arguments=safe_args)
    return None


def after_tool_guardrail_callback(
    tool: Any = None,
    args: Optional[Dict[str, Any]] = None,
    tool_context: Any = None,
    tool_response: Any = None,
) -> Optional[Dict[str, Any]]:
    """Google ADK `after_tool_callback` hook that verifies post-tool invariants and logs outcomes.

    Args:
        tool (Any): Executed tool function or ADK BaseTool instance.
        args (Optional[Dict[str, Any]]): Arguments passed to the tool.
        tool_context (Any): ADK ToolContext instance.
        tool_response (Any): Result returned by the tool.

    Returns:
        Optional[Dict[str, Any]]: None to preserve original `tool_response`.
    """
    tool_name = getattr(tool, "name", None) or getattr(tool, "__name__", str(tool))
    elapsed_ms = 0.0
    if tool_context is not None and hasattr(tool_context, "state"):
        try:
            start_ts = tool_context.state.get("_tool_start_ts")
            if start_ts:
                elapsed_ms = (time.perf_counter() - float(start_ts)) * 1000.0
        except Exception:
            pass
    log_tool_outcome(
        tool_name=str(tool_name),
        outcome=tool_response,
        latency_ms=elapsed_ms,
    )
    return None


def require_human_confirmation_hook(
    action_name: str,
    action_payload: Optional[Dict[str, Any]] = None,
    action_details: Optional[Dict[str, Any]] = None,
    autonomy_mode: str = "COPILOT",
    explicit_auto_dispatch: bool = False,
    explicitly_confirmed: bool = False,
    tool_context: Any = None,
) -> Dict[str, Any]:
    """Enforces Human-in-the-Loop (HITL) confirmation before dispatching live dealer communications.

    In `COPILOT` mode (the default), outbound dealer messages are placed in `PENDING_APPROVAL`
    until the buyer explicitly approves them via `approve_queued_message` or sets explicit confirmation.

    Args:
        action_name (str): Name of the high-stakes action (e.g., 'queue_dealer_message').
        action_payload (Optional[Dict[str, Any]]): Payload describing the outbound action.
        action_details (Optional[Dict[str, Any]]): Alias for `action_payload`.
        autonomy_mode (str): Campaign autonomy setting ('COPILOT', 'SEMI_AUTO', 'FULL_AUTOPILOT').
        explicit_auto_dispatch (bool): Whether auto-dispatch was explicitly authorized.
        explicitly_confirmed (bool): Alias indicating explicit human confirmation.
        tool_context (Any): Optional ADK `ToolContext` for native ADK confirmation signaling.

    Returns:
        Dict[str, Any]: Gate status dictionary containing `approved`, `allowed_to_proceed`,
            `requires_human_confirmation`, `recommended_status`, and `confirmation_prompt`.
    """
    mode_norm = (autonomy_mode or "COPILOT").strip().upper()
    details = action_payload if action_payload is not None else (action_details or {})
    allowed = bool(
        explicit_auto_dispatch
        or explicitly_confirmed
        or mode_norm in ("FULL_AUTOPILOT", "SEMI_AUTO")
    )

    if not allowed and tool_context is not None:
        try:
            actions_obj = getattr(tool_context, "actions", None)
            if actions_obj is not None and hasattr(actions_obj, "request_confirmation"):
                actions_obj.request_confirmation(
                    hint=f"Human confirmation required for {action_name}",
                    payload=redact_pii(details),
                )
        except Exception:
            pass

    result = {
        "action_name": action_name,
        "autonomy_mode": mode_norm,
        "approved": allowed,
        "allowed_to_proceed": allowed,
        "requires_human_confirmation": not allowed,
        "explicitly_confirmed": bool(explicit_auto_dispatch or explicitly_confirmed),
        "recommended_status": "APPROVED_QUEUED" if allowed else "PENDING_APPROVAL",
        "status": "CONFIRMED_PROCEED" if allowed else "PAUSED_AWAITING_HUMAN_CONFIRMATION",
        "confirmation_prompt": (
            f"✋ HUMAN-IN-THE-LOOP CONFIRMATION REQUIRED for `{action_name}`: "
            f"Review and call `approve_queued_message` before dispatching to dealership."
            if not allowed
            else f"Action `{action_name}` authorized ({mode_norm})."
        ),
        "details": redact_pii(details),
    }
    log_structured_event(
        event_type="HITL_CONFIRMATION_CHECK",
        message=f"HITL check for '{action_name}': status={result['recommended_status']}",
        component="hitl_guardrail",
        metadata=result,
    )
    return result
